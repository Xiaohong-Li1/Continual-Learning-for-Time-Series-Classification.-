# baseline_arima_features.py

import numpy as np
from sklearn.linear_model import LogisticRegression
# Or, if you want to classify ARIMA features using RandomForest:
# from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tools.sm_exceptions import ConvergenceWarning, ValueWarning
import warnings
import traceback

# Not directly loaded by this file, data is passed by the caller
# import os # No longer needed

# Suppress warnings during ARIMA fitting process for cleaner batch processing output
warnings.simplefilter('ignore', ConvergenceWarning)
warnings.simplefilter('ignore', ValueWarning)
warnings.simplefilter('ignore', UserWarning) # Often from statsmodels warnings about frequency
warnings.simplefilter('ignore', RuntimeWarning) # E.g., warnings from residual statistics calculations

def extract_arima_residual_features(X, arima_order=(1,1,0)):
    """
    Extract features from the ARIMA model residuals of a set of time series.
    For each time series, fit an ARIMA model and calculate the mean/standard deviation of the residuals.
    Assumes X is a 2D numpy array (n_samples, sequence_length).
    """
    n_samples = X.shape[0]
    arima_features = []
    min_len_for_arima = np.sum(arima_order) + 3 # Minimum length required for ARIMA fitting (heuristic)

    for i in range(n_samples):
        ts = X[i, :]
        ts_clean = ts[~np.isnan(ts)] # Remove NaN

        if ts_clean.size < min_len_for_arima:
            # print(f"Skipping ARIMA for sequence {i} due to NaN or insufficient length.")
            arima_features.append([0.0, 1.0]) # Default features (e.g., mean 0, std dev 1)
            continue

        try:
            # Force simple order. For better results, auto_arima or order selection is needed.
            model = ARIMA(ts_clean, order=arima_order, enforce_stationarity=False, enforce_invertibility=False)
            model_fit = model.fit()
            residuals = model_fit.resid

            if residuals.size == 0 or np.all(np.isnan(residuals)):
                res_mean = 0.0
                res_std = 1.0
            else:
                res_mean = np.mean(residuals[~np.isnan(residuals)])
                res_std = np.std(residuals[~np.isnan(residuals)])
                if np.isnan(res_std) or res_std == 0: # If standard deviation is 0 or NaN (e.g., constant residuals)
                    res_std = 1.0 # Avoid division by zero or invalid standard deviation

            arima_features.append([res_mean, res_std])
        except Exception as e:
            # print(f"Warning: ARIMA fit failed for sequence {i}. Error: {e}. Using default features.")
            arima_features.append([0.0, 1.0]) # Default features on error

    return np.array(arima_features)

def run_arima_baseline_for_dataset(X_train, y_train, X_test, y_test, dataset_name, class_names=None, arima_order=(1,1,0), random_state=42):
    """
    Trains and evaluates a Logistic Regression classifier on ARIMA residual features.
    X_train, X_test: (n_samples, sequence_length) or (n_samples, 1, sequence_length)
    Returns a dictionary containing evaluation results.
    """
    print(f"Running ARIMA features + Classifier baseline for {dataset_name}...")

    # Ensure X_train and X_test are 2D
    if X_train.ndim == 3 and X_train.shape[1] == 1:
        X_train_2d = X_train.squeeze(axis=1)
    elif X_train.ndim == 2:
        X_train_2d = X_train
    else:
        raise ValueError(f"Incorrect number of dimensions for X_train: {X_train.ndim}. Expected 2 or 3 (single channel).")

    if X_test.ndim == 3 and X_test.shape[1] == 1:
        X_test_2d = X_test.squeeze(axis=1)
    elif X_test.ndim == 2:
        X_test_2d = X_test
    else:
        raise ValueError(f"Incorrect number of dimensions for X_test: {X_test.ndim}. Expected 2 or 3 (single channel).")

    # Check sequence length
    min_len_for_arima_check = np.sum(arima_order) + 5
    if X_train_2d.shape[1] < min_len_for_arima_check:
        print(f"Sequence length ({X_train_2d.shape[1]}) for dataset {dataset_name} might be too short for ARIMA order {arima_order}. Skipping ARIMA baseline.")
        return {
            'Dataset': dataset_name,
            'Model': 'ARIMA',
            'Test Accuracy': np.nan, # Or 0.0, or None
            'Test Loss': np.nan, # ARIMA typically does not directly optimize a loss function
            'Classes': len(class_names) if class_names else len(np.unique(y_train)),
            'Training Samples': len(X_train),
            'Testing Samples': len(X_test),
            'Error': 'Sequence too short'
        }

    print(f"Extracting ARIMA (order {arima_order}) residual features for {dataset_name}...")
    X_train_arima_features = extract_arima_residual_features(X_train_2d, arima_order=arima_order)
    X_test_arima_features = extract_arima_residual_features(X_test_2d, arima_order=arima_order)

    X_train_arima_features = np.nan_to_num(X_train_arima_features, nan=0.0, posinf=0.0, neginf=0.0)
    X_test_arima_features = np.nan_to_num(X_test_arima_features, nan=0.0, posinf=0.0, neginf=0.0)

    classifier = LogisticRegression(random_state=random_state, solver='liblinear', max_iter=200)

    print(f"Training classifier on ARIMA features for {dataset_name}...")
    try:
        classifier.fit(X_train_arima_features, y_train)
        y_pred = classifier.predict(X_test_arima_features)
        accuracy = accuracy_score(y_test, y_pred)
        # report_str = classification_report(y_test, y_pred, target_names=class_names, zero_division=0) # Report can be printed elsewhere
        print(f"ARIMA Features + Classifier ({dataset_name}) - Test Accuracy: {accuracy:.4f}")

        # Corrected logic for calculating Classes
        num_classes = len(class_names) if class_names is not None and class_names.size > 0 else len(np.unique(y_train))

        return {
            'Dataset': dataset_name,
            'Model': 'ARIMA',
            'Test Accuracy': accuracy,
            'Test Loss': np.nan,
            'Classes': num_classes, # Use corrected value
            'Training Samples': len(X_train),
            'Testing Samples': len(X_test)
        }
    except Exception as e:
        print(f"ARIMA baseline for {dataset_name} failed: {e}")
        traceback.print_exc()
        # Corrected logic for calculating Classes (Error case)
        num_classes_err = len(class_names) if class_names is not None and class_names.size > 0 else (len(np.unique(y_train)) if y_train is not None and y_train.size > 0 else np.nan)
        return {
            'Dataset': dataset_name,
            'Model': 'ARIMA',
            'Test Accuracy': np.nan,
            'Test Loss': np.nan,
            'Classes': num_classes_err, # Use corrected value
            'Training Samples': len(X_train) if X_train is not None else 0,
            'Testing Samples': len(X_test) if X_test is not None else 0,
            'Error': str(e)
        }

# Removed if __name__ == '__main__': section