# -*- coding: utf-8 -*-
import torch
import torch.nn as nn
import torch.nn.functional as F

class StandardConvLayer(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size):
        super(StandardConvLayer, self).__init__()
        # Added 'same' padding to accommodate odd kernel sizes
        self.conv = nn.Conv1d(in_channels, out_channels, kernel_size, padding=kernel_size // 2)
        self.bn = nn.BatchNorm1d(out_channels)
        # Changed MaxPool1d kernel_size to 3, stride to 2 to reduce downsampling intensity.
        # Note: Output length may vary depending on input length and stride.
        # If fixed output size is needed, consider using adaptive pooling or adjusting layers.
        self.pool = nn.MaxPool1d(kernel_size=3, stride=2, padding=1) # Also added padding here

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = F.relu(x)
        x = self.pool(x)
        return x

class MultiScaleFeatureExtraction(nn.Module):
    def __init__(self, in_channels, out_channels=32, num_paths=3):
        super(MultiScaleFeatureExtraction, self).__init__()
        self.num_paths = num_paths
        self.conv_paths = nn.ModuleList()
        # Use different kernel sizes for multi-scale analysis
        # Path 1: kernel_size=3
        # Path 2: kernel_size=5
        # Path 3: kernel_size=7
        # Path 4: kernel_size=9 (if num_paths >= 4)
        # More paths can be dynamically created based on num_paths. For this report, if num_paths=4, we have specific kernel sizes.
        
        kernel_sizes = [3, 5, 7, 9, 11] # List of expandable kernel sizes

        if num_paths > len(kernel_sizes):
            print(f"Warning: Requested number of parallel paths ({num_paths}) is greater than the number of predefined kernel sizes ({len(kernel_sizes)}). All predefined paths will be used.")
            self.num_paths = len(kernel_sizes)

        for i in range(self.num_paths):
            self.conv_paths.append(StandardConvLayer(in_channels, out_channels, kernel_sizes[i]))

    def forward(self, x):
        path_outputs = []
        min_len = -1
        for conv_layer in self.conv_paths:
            out = conv_layer(x)
            path_outputs.append(out)
            if min_len == -1 or out.size(2) < min_len:
                min_len = out.size(2)
        
        # Crop outputs of all paths to the minimum length
        processed_outputs = []
        for out in path_outputs:
            processed_outputs.append(out[:, :, :min_len])
            
        return torch.cat(processed_outputs, dim=1) # Concatenate along channel dimension

class AttentionBlock(nn.Module):
    # Uses CBAM-like attention (Channel + Spatial)
    def __init__(self, channels):
        super(AttentionBlock, self).__init__()
        self.channel_attention = nn.Sequential(
            nn.AdaptiveAvgPool1d(1),
            # Use Conv1d for MLP of channel attention instead of Linear
            nn.Conv1d(channels, channels // 8, 1, bias=False),
            nn.ReLU(),
            nn.Conv1d(channels // 8, channels, 1, bias=False),
            # Removed final Sigmoid from channel attention path based on some CBAM variants
        )
        # Add sigmoid here, applied element-wise after broadcasting
        self.sigmoid_channel = nn.Sigmoid()

        self.spatial_attention = nn.Sequential(
            # Use a larger kernel for spatial attention context
            nn.Conv1d(2, 1, kernel_size=7, padding=3, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x, return_attention_weights=False):
        # Channel Attention
        # Note: In the original CBAM paper, the MLP was shared. This is implemented here as two separate MLP paths that are then summed.
        # For simplicity and to match some implementations, we can pool before applying the MLP.
        # Current code: Pool first, then each pooled result goes through a separate MLP (because channel_attention is Sequential).
        # If sharing MLP is desired, channel_attention needs to act on concatenated or summed pooled features first.
        # Let's keep the current structure, which processes avg and max pool separately and then combines their outputs (weights).

        pooled_avg = F.adaptive_avg_pool1d(x, 1)
        pooled_max = F.adaptive_max_pool1d(x, 1)
        
        avg_pool_ca_out = self.channel_attention(pooled_avg) 
        max_pool_ca_out = self.channel_attention(pooled_max) 
        
        channel_weights = self.sigmoid_channel(avg_pool_ca_out + max_pool_ca_out) 
        x_channel_att = x * channel_weights  # Apply channel attention

        # Spatial Attention
        avg_pool_spatial = torch.mean(x_channel_att, dim=1, keepdim=True)
        max_pool_spatial, _ = torch.max(x_channel_att, dim=1, keepdim=True)
        spatial_cat = torch.cat([avg_pool_spatial, max_pool_spatial], dim=1) 
        spatial_weights = self.spatial_attention(spatial_cat) 
        x_spatial_att = x_channel_att * spatial_weights 

        if return_attention_weights:
            return x_spatial_att, channel_weights, spatial_weights
        else:
            return x_spatial_att

class CNN_BiGRU_Attention(nn.Module):
    def __init__(self, input_channels, sequence_length, num_classes_initial, 
                 num_multiscale_paths=3, final_dropout_rate=0.5, gru_hidden_size=128, num_gru_layers=2, adaptive_pool_output_size=50):
        super(CNN_BiGRU_Attention, self).__init__()
        self.input_channels = input_channels # Expected input shape (batch, channels, sequence_length)
        self.current_task_id = 0 # Initialize current_task_id attribute

        # Initial feature extraction (adjust input channels)
        initial_conv_out_channels = 64
        self.initial_conv = nn.Sequential(
            nn.Conv1d(input_channels, initial_conv_out_channels, kernel_size=7, padding=3, bias=False), # Increase filter count, increase kernel size
            nn.BatchNorm1d(initial_conv_out_channels),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=3, stride=2, padding=1)
        )
        current_channels = initial_conv_out_channels

        # Multi-scale feature extraction
        multiscale_out_channels_per_path = 64 # Output channels per path
        self.multi_scale = MultiScaleFeatureExtraction(current_channels, 
                                                   out_channels=multiscale_out_channels_per_path, 
                                                   num_paths=num_multiscale_paths)
        # Calculate output channels after multi-scale (num_multiscale_paths * multiscale_out_channels_per_path)
        current_channels = multiscale_out_channels_per_path * num_multiscale_paths

        # Attention mechanism
        self.attention = AttentionBlock(current_channels)
        # Channel count remains the same after attention mechanism

        # Adaptive pooling
        self.adaptive_pool_output_size = adaptive_pool_output_size
        self.adaptive_pool = nn.AdaptiveAvgPool1d(output_size=self.adaptive_pool_output_size)

        # Temporal feature extraction (GRU)
        self.gru_input_size = current_channels 
        self.gru_hidden_size = gru_hidden_size 
        self.num_gru_layers = num_gru_layers
        self.gru1 = nn.GRU(self.gru_input_size, self.gru_hidden_size, num_layers=self.num_gru_layers,
                           bidirectional=True, batch_first=True, dropout=0.2 if self.num_gru_layers > 1 else 0) # GRU dropout is only effective for num_layers > 1

        # Classifier
        self.classifier_input_features = self.gru_hidden_size * 2 # Bidirectional
        self.dropout = nn.Dropout(final_dropout_rate) # Use configurable dropout rate
        
        self.task_classifiers = nn.ModuleList([
            nn.Linear(self.classifier_input_features, num_classes_initial)
        ])

    def add_task_classifier(self, num_new_classes, device):
        """Add a new task-specific classifier"""
        new_classifier = nn.Linear(self.classifier_input_features, num_new_classes).to(device)
        self.task_classifiers.append(new_classifier)
        print(f"Added new classifier head for task {len(self.task_classifiers) - 1} with {num_new_classes} classes.")
        return len(self.task_classifiers) - 1 # Return index of the new classifier

    def forward(self, x, task_labels=None, return_attention_weights=False):
        # Input x: (batch_size, sequence_length)
        # Model expects input (batch, channels, sequence_length)
        if x.dim() == 2:  # If (batch, sequence_length)
            x = x.unsqueeze(1)  # Add channel dimension (batch, channel, sequence_length)
        # Check if channel count matches input_channels during model initialization
        # This check should be done after unsqueeze(1) if initial dimension was 2D,
        # or at the beginning if input is always expected to be 3D.
        # Current implementation: If input is 2D, it's assumed to be single-channel and unsqueezed. If input is 3D, channel count is checked.
        if x.shape[1] != self.input_channels:
            # If original was 2D and input_channels=1, the unsqueeze(1) above already handled it.
            # This error primarily targets cases where input is already 3D but channel count doesn't match.
            if not (x.dim() == 3 and self.input_channels == 1 and x.shape[1] != 1 ): # Corrected condition, allow x.shape[1] to be 1 after expansion if input_channels=1
                 # In fact, if x.dim() == 2 and self.input_channels == 1, then after x.unsqueeze(1), x.shape[1] == 1, so the error below won't be triggered.
                 # If x.dim() == 3, then x.shape[1] must be equal to self.input_channels.
                 if not (x.dim() == 2 and self.input_channels == 1): # If not the case of 2D->3D with input_channel=1
                    if x.shape[1] != self.input_channels: # Re-check to ensure logic is correct
                        raise ValueError(f"Input tensor channel dimension mismatch. Model expected {self.input_channels} channels, but got {x.shape[1]} in shape {x.shape}")
        
        # Initial convolution -> Multi-scale -> Attention
        x_conv = self.initial_conv(x)
        x_multiscale = self.multi_scale(x_conv)
        
        att_output = self.attention(x_multiscale, return_attention_weights=return_attention_weights)
        if return_attention_weights:
            x_attention, channel_weights, spatial_weights = att_output
        else:
            x_attention = att_output
            channel_weights, spatial_weights = None, None # Ensure these are None when not returning

        # Adaptive pooling to fix sequence length before GRU
        x_pooled = self.adaptive_pool(x_attention) 

        # Prepare for GRU
        x_gru_input = x_pooled.permute(0, 2, 1) 

        # GRU Layer
        x_gru_out, _ = self.gru1(x_gru_input) 

        # Use the output of the last time step for classification
        x_features = x_gru_out[:, -1, :] 

        x_dropped = self.dropout(x_features)

        # Multi-head classification logic - using self.current_task_id (set by plugin)
        # print(f"[MODEL FORWARD DEBUG] task_labels param: {task_labels}") # Debugging passed task_labels
        # print(f"[MODEL FORWARD DEBUG] self.current_task_id attr: {getattr(self, 'current_task_id', 'NOT SET')}")
        
        # Prioritize using current_task_id set by plugin
        print(f"[MODEL FORWARD] Top: Accessed model.current_task_id: {getattr(self, 'current_task_id', 'NOT SET (will default to 0 if task_labels not provided)')}")
        if hasattr(self, 'current_task_id'):
            # This current_task_id should be set by the Avalanche plugin (SetTaskLabelPlugin) at the beginning of each experience
            task_id_to_use = self.current_task_id
            # print(f"[MODEL FORWARD DEBUG] Using task_id from self.current_task_id: {task_id_to_use}")
        elif task_labels is not None:
            # If plugin is not set, but forward is called directly with task_labels (e.g., testing model independently)
            # Ensure task_labels is a single integer or a tensor that can be converted to a single integer
            if isinstance(task_labels, torch.Tensor):
                if task_labels.numel() == 1:
                    task_id_to_use = task_labels.item()
                else: # If task_labels is a batch of labels, the logic here needs adjustment. Typically, the model expects a uniform task_id.
                    print(f"[MODEL FORWARD] Warning: task_labels provided as a batch, using first element: {task_labels[0].item()}")
                    task_id_to_use = task_labels[0].item() # Or raise an error, depending on desired behavior
            elif isinstance(task_labels, int):
                task_id_to_use = task_labels
            else:
                raise ValueError("task_labels must be an int or a single-element tensor if self.current_task_id is not set.")
            # print(f"[MODEL FORWARD DEBUG] Using task_id from task_labels argument: {task_id_to_use}")
        else:
            # print("[MODEL FORWARD DEBUG] Neither self.current_task_id set nor task_labels provided. Defaulting task_id to 0.")
            task_id_to_use = 0 # Final default value

        print(f"[MODEL FORWARD] Middle: Effective task_id to use: {task_id_to_use} for a model with {len(self.task_classifiers)} heads.")

        if task_id_to_use < len(self.task_classifiers):
            final_output = self.task_classifiers[task_id_to_use](x_dropped)
            # print(f"[MODEL FORWARD DEBUG] Selected head {task_id_to_use} with output shape: {final_output.shape}")
        else:
            print(f"[MODEL FORWARD] ERROR! task_id {task_id_to_use} is out of bounds for {len(self.task_classifiers)} classifiers.")
            raise IndexError(f"Error in forward: task_id {task_id_to_use} is out of bounds. "
                             f"Model only has {len(self.task_classifiers)} classifiers (up to task {len(self.task_classifiers)-1}). "
                             f"Attempted to access head for task {task_id_to_use}.")

        if return_attention_weights:
            return final_output, channel_weights, spatial_weights
        else:
            return final_output

class MultiHeadMLP(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, num_initial_classes):
        super(MultiHeadMLP, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        
        # 共享的特征提取层
        self.feature_extractor = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(hidden_size, output_size),
            nn.ReLU(),
            nn.Dropout(0.5)
        )
        
        # 任务特定的分类器头
        self.task_classifiers = nn.ModuleList([
            nn.Linear(output_size, num_initial_classes)
        ])
        
    def add_task_classifier(self, num_new_classes, device):
        """添加一个新的任务特定分类器"""
        new_classifier = nn.Linear(self.output_size, num_new_classes).to(device)
        self.task_classifiers.append(new_classifier)
        print(f"为任务 {len(self.task_classifiers) - 1} 添加了新的分类器头，包含 {num_new_classes} 个类。")
        return len(self.task_classifiers) - 1
        
    def forward(self, x, task_labels=None):
        # 提取共享特征
        features = self.feature_extractor(x)
        
        # 如果没有提供 task_labels，使用默认分类器
        if task_labels is None:
            return self.task_classifiers[0](features)
            
        # 使用任务特定的分类器
        task_id = int(task_labels[0].item())  # 假设批次是同质的
        if task_id < len(self.task_classifiers):
            return self.task_classifiers[task_id](features)
        else:
            print(f"警告: 任务 ID {task_id} 超出可用分类器范围 ({len(self.task_classifiers)})。使用分类器 0。")
            return self.task_classifiers[0](features)

# --- Standard LSTM Model --- 
class StandardLSTM(nn.Module):
    def __init__(self, input_channels, hidden_size, num_layers, num_classes, 
                 bidirectional=False, dropout_rate=0.5):
        super(StandardLSTM, self).__init__()
        self.input_channels = input_channels
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.bidirectional = bidirectional
        
        # LSTM 层
        # batch_first=True 使输入/输出张量的形状为 (batch, seq, feature)
        self.lstm = nn.LSTM(input_size=input_channels, 
                            hidden_size=hidden_size, 
                            num_layers=num_layers, 
                            batch_first=True, 
                            bidirectional=bidirectional,
                            # dropout只在num_layers > 1时应用在层之间
                            dropout=dropout_rate if num_layers > 1 else 0)
        
        # 分类器层
        # 如果是双向，则最终特征维度是 hidden_size * 2
        classifier_input_features = hidden_size * 2 if bidirectional else hidden_size
        self.classifier = nn.Sequential(
            nn.Dropout(dropout_rate),
            nn.Linear(classifier_input_features, num_classes)
        )

    def forward(self, x):
        # 输入 x: (batch, channels, seq_len)
        # LSTM 期望: (batch, seq_len, channels/features)
        if x.dim() == 2:
            x = x.unsqueeze(1) # -> (batch, 1, seq_len)
        
        # 检查通道维度
        if x.shape[1] != self.input_channels:
             if not (x.dim() == 3 and self.input_channels == 1 and x.shape[1] == 1): # 允许从 (B, S) -> (B, 1, S) 转换
                raise ValueError(f"Input tensor channel mismatch. Expected {self.input_channels}, got {x.shape[1]}")

        x = x.permute(0, 2, 1) # (batch, seq_len, channels)
        
        # 初始化隐藏状态和细胞状态 (默认为0)
        # h0 = torch.zeros(self.num_layers * (2 if self.bidirectional else 1), x.size(0), self.hidden_size).to(x.device)
        # c0 = torch.zeros(self.num_layers * (2 if self.bidirectional else 1), x.size(0), self.hidden_size).to(x.device)
        
        # LSTM 前向传播
        # output: (batch, seq_len, hidden_size * num_directions)
        # hn: (num_layers * num_directions, batch, hidden_size) - 最后时间步的隐藏状态
        # cn: (num_layers * num_directions, batch, hidden_size) - 最后时间步的细胞状态
        output, (hn, cn) = self.lstm(x) #, (h0, c0))
        
        # 使用最后一个时间步的输出进行分类
        # output[:, -1, :] 形状为 (batch, hidden_size * num_directions)
        features = output[:, -1, :]
        
        # 或者使用最后一层的最后一个隐藏状态 hn
        # 需要正确处理双向和多层的情况来获取用于分类的特征
        # 例如，对于双向单层: torch.cat((hn[0,:,:], hn[1,:,:]), dim=1)
        # 使用 output[:, -1, :] 更简单
        
        # 分类
        out = self.classifier(features)
        return out

class StandardGRU(nn.Module):
    def __init__(self, input_channels, hidden_size, num_layers, num_classes,
                 bidirectional=False, dropout_rate=0.5):
        super(StandardGRU, self).__init__()
        self.input_channels = input_channels
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.bidirectional = bidirectional
        
        self.gru = nn.GRU(input_size=input_channels,
                          hidden_size=hidden_size,
                          num_layers=num_layers,
                          batch_first=True,
                          bidirectional=bidirectional,
                          dropout=dropout_rate if num_layers > 1 else 0)
        
        classifier_input_features = hidden_size * 2 if bidirectional else hidden_size
        self.classifier = nn.Sequential(
            nn.Dropout(dropout_rate),
            nn.Linear(classifier_input_features, num_classes)
        )

    def forward(self, x):
        if x.dim() == 2:
            x = x.unsqueeze(1) 
            
        if x.shape[1] != self.input_channels:
             if not (x.dim() == 3 and self.input_channels == 1 and x.shape[1] == 1):
                raise ValueError(f"Input tensor channel mismatch. Expected {self.input_channels}, got {x.shape[1]}")

        x = x.permute(0, 2, 1) 
        
        output, hn = self.gru(x)
        features = output[:, -1, :]
        out = self.classifier(features)
        return out