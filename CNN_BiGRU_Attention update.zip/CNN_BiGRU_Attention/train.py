# -*- coding: utf-8 -*-
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset
import numpy as np
from sklearn.preprocessing import StandardScaler # Removed LabelEncoder
from model import CNN_BiGRU_Attention, MultiHeadMLP
import os
import argparse
from torch.nn.utils.rnn import pad_sequence
from tqdm import tqdm # Import tqdm
import matplotlib
matplotlib.use('Agg') # Use a non-interactive backend for saving plots
import matplotlib.pyplot as plt
import json # Added for saving results
import sys # Added for checking sys.argv
from datetime import datetime # Added for timestamp

# Avalanche Imports
from avalanche.benchmarks.classic import SplitMNIST
from avalanche.benchmarks.scenarios.dataset_scenario import benchmark_from_datasets
from avalanche.benchmarks.utils.data import AvalancheDataset
from avalanche.benchmarks.utils.data_attribute import DataAttribute
from avalanche.benchmarks import with_classes_timeline
from load_timeseries_data import load_ucr_dataset 

# Correct import for Naive strategy
from avalanche.training.supervised import Naive, Cumulative, EWC, GEM, AGEM, Replay, ER_ACE, LFL, SynapticIntelligence
from avalanche.training.plugins import EarlyStoppingPlugin, LRSchedulerPlugin, ReplayPlugin, EWCPlugin
from torch.optim.lr_scheduler import ReduceLROnPlateau
from model import CNN_BiGRU_Attention # Ensure model is imported

# Import the correct storage policy class from the storage_policy submodule
from avalanche.training.storage_policy import ExperienceBalancedBuffer

from avalanche.evaluation.metrics import accuracy_metrics, loss_metrics, forgetting_metrics, cpu_usage_metrics, timing_metrics, ram_usage_metrics
from avalanche.logging import InteractiveLogger, TextLogger, TensorboardLogger
from avalanche.training.plugins import EvaluationPlugin
from torchvision import transforms

# --- New: Define Plugin ---
from avalanche.core import SupervisedPlugin
torch.backends.cudnn.enabled = False
# Custom plugin to set the model's task_id at the start of each experience
class SetTaskLabelPlugin(SupervisedPlugin):
    def _get_task_id_from_experience(self, experience):
        # Try to get task_label directly (added by with_classes_timeline)
        if hasattr(experience, 'task_label'):
            return experience.task_label
        elif hasattr(experience, 'dataset') and hasattr(experience.dataset, 'targets_task_labels'):
            task_labels_attr = experience.dataset.targets_task_labels
            if isinstance(task_labels_attr, DataAttribute) and hasattr(task_labels_attr, 'data') and task_labels_attr.data:
                return task_labels_attr.data[0] 
            elif isinstance(task_labels_attr, (list, tuple)) and len(task_labels_attr) > 0:
                return task_labels_attr[0]
        elif hasattr(experience, 'dataset') and hasattr(experience.dataset, 'task_labels'):
            task_labels_attr_fallback = experience.dataset.task_labels
            if isinstance(task_labels_attr_fallback, DataAttribute) and hasattr(task_labels_attr_fallback, 'data') and task_labels_attr_fallback.data:
                return task_labels_attr_fallback.data[0]
            elif isinstance(task_labels_attr_fallback, (list, tuple)) and len(task_labels_attr_fallback) > 0:
                return task_labels_attr_fallback[0]
        return 0 

    def before_training_exp(self, strategy: 'BaseStrategy', **kwargs):
        current_exp_id = strategy.experience.current_experience
        task_id = self._get_task_id_from_experience(strategy.experience)
        if hasattr(strategy.model, 'current_task_id'):
            strategy.model.current_task_id = task_id
        # print(f"[PLUGIN] Set strategy.model.current_task_id to: {task_id} for Exp {current_exp_id}")

    def before_eval_exp(self, strategy: 'BaseStrategy', **kwargs):
        current_exp_id = strategy.experience.current_experience
        task_id = self._get_task_id_from_experience(strategy.experience)
        if hasattr(strategy.model, 'current_task_id'):
            strategy.model.current_task_id = task_id
        # print(f"[PLUGIN-EVAL] Set strategy.model.current_task_id to: {task_id} for Exp {current_exp_id}")

# --- New: Custom Collate Function ---
def pad_collate_fn(batch):
    # batch: a list of tuples -> [(feature_tensor_1, label_tensor_1, task_label_1), ...]
    # feature_tensor shape: (C, L_i), where L_i can vary
    # label_tensor shape: () (scalar tensor)
    # task_label shape: () (scalar tensor or int)

    features = [item[0] for item in batch]
    labels = [item[1] for item in batch]
    task_ids = [item[2] for item in batch] # Extract task_ids

    # Check if features have channel dimension C=1. Expected shape (1, L)
    # pad_sequence expects (L, *) or (L, B, *) if batch_first=False
    # We need (B, C, L_max). Let's pad the sequence dim L.
    # Permute features to (L, C) first if C is the first dim
    features_permuted = [f.permute(1, 0) for f in features] # Now list of (L_i, C)

    # Pad the sequence dimension (L)
    features_padded = pad_sequence(features_permuted, batch_first=True, padding_value=0.0) # -> (B, L_max, C)

    # Permute back to (B, C, L_max)
    features_padded = features_padded.permute(0, 2, 1)

    labels = torch.stack(labels, dim=0)
    task_ids = torch.tensor(task_ids, dtype=torch.long) # Stack task_ids into a tensor

    return features_padded, labels, task_ids # Return task_ids as the third element
# --- End of Collate Function Definition ---

# UCR Dataset List
UCR_DATASET_NAMES = [
    "ArrowHead", "AtrialFibrillation", "BasicMotions", "Beef", "BeetleFly",
    "BirdChicken", "BME", "Coffee", "DodgerLoopDay", "DodgerLoopGame"
]

def create_benchmark(benchmark_name="ucr_timeseries", n_experiences_mnist=5, seed=42, data_dir='dataset'):
    """
    Creates a continual learning benchmark.
    :param benchmark_name: The name of the benchmark to create ('ucr_timeseries' or 'split_mnist').
    :param seed: Random seed.
    :param data_dir: The directory where UCR datasets are located.
    :return: (benchmark, input_channels, sequence_length, n_initial_classes)
    """
    if benchmark_name == "split_mnist":
        print("Preparing SplitMNIST benchmark...")
        # Define transforms for MNIST
        mnist_transform = transforms.Compose([
            transforms.ToTensor(), # Convert to tensor first
            transforms.Lambda(lambda x: x.float()),
            transforms.Lambda(lambda x: x.squeeze(0)), # Remove channel dimension
            transforms.Lambda(lambda x: x.view(28*28))   # Flatten into 1D sequence (28x28=784)
        ])
        
        benchmark = SplitMNIST(
            n_experiences=n_experiences_mnist,
            seed=seed,
            return_task_id=True, # Important for multi-head
            train_transform=mnist_transform,
            eval_transform=mnist_transform,
            class_ids_from_zero_in_each_exp=True # Class IDs start from 0 in each experience
        )
        # For MNIST, channels=1, sequence_length=28x28=784 (after flattening)
        # If not flattened, sequence_length might be 28 (rows), input_channels might be 28 (columns)
        # But our model MQCCAF_TimeSeries expects (batch, features, seq_len) or (batch, seq_len, features)
        # Based on the original model design, it accepts (batch, input_channels, sequence_length)
        # If MNIST image is (1, 28, 28), flattened is (784),
        # If the model treats 784 as sequence_length, then input_channels = 1
        # If the model treats 28 as sequence_length, then input_channels = 28 (more like an image)
        # From the model perspective, input_channels is the feature dimension, sequence_length is the number of time steps.
        # For flattened MNIST, sequence_length=784, input_channels=1
        input_channels = 1
        sequence_length = 784 
        n_initial_classes = len(benchmark.train_stream[0].dataset.targets.unique())
        print(f"SplitMNIST: input_channels={input_channels}, sequence_length={sequence_length}, n_initial_classes={n_initial_classes}")
        return benchmark, input_channels, sequence_length, n_initial_classes

    elif benchmark_name == "ucr_timeseries":
        print(f"Preparing UCR Time Series benchmark with datasets: {UCR_DATASET_NAMES}")
        train_datasets = []
        test_datasets = []
        first_dataset = True
        input_channels = -1 
        sequence_length = -1
        n_initial_classes = -1

        for i, dataset_name in enumerate(UCR_DATASET_NAMES):
            print(f"Loading UCR dataset: {dataset_name} (Task {i})")
            try:
                X_train, y_train, X_test, y_test, classes = load_ucr_dataset(dataset_name, data_dir=data_dir)
            except Exception as e:
                print(f"Error: Could not load dataset {dataset_name}. Skipping. Error message: {e}")
                continue

            if X_train.ndim == 2:
                X_train = np.expand_dims(X_train, axis=1)
                X_test = np.expand_dims(X_test, axis=1)

            current_n_features = X_train.shape[1]
            current_seq_len = X_train.shape[2]
            num_classes_in_task = len(classes)

            print(f"Dataset {dataset_name}: X_train shape {X_train.shape}, y_train shape {y_train.shape}, n_classes {num_classes_in_task}")

            if first_dataset:
                input_channels = current_n_features
                sequence_length = current_seq_len
                n_initial_classes = num_classes_in_task
                first_dataset = False
            else:
                if current_n_features != input_channels:
                    print(f"Warning: Number of features ({current_n_features}) for dataset {dataset_name} differs from the first dataset ({input_channels}). This might cause issues.")
                if current_seq_len != sequence_length:
                    print(f"Warning: Sequence length ({current_seq_len}) for dataset {dataset_name} differs from the first dataset ({sequence_length}). This might cause issues.")

            X_train_tensor = torch.FloatTensor(X_train)
            y_train_tensor = torch.LongTensor(y_train)
            X_test_tensor = torch.FloatTensor(X_test)
            y_test_tensor = torch.LongTensor(y_test)

            # 1. Create PyTorch TensorDataset
            pytorch_train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
            pytorch_test_dataset = TensorDataset(X_test_tensor, y_test_tensor)

            # 2. Use make_classification_dataset following the doc example
            # train_task_dataset = make_classification_dataset(pytorch_train_dataset, task_labels=i)
            # test_task_dataset = make_classification_dataset(pytorch_test_dataset, task_labels=i)

            # Modification: Use AvalancheDataset and DataAttribute
            train_task_dataset = AvalancheDataset(
                [pytorch_train_dataset], # Pass as a list of datasets
                data_attributes=[
                    DataAttribute(y_train_tensor.tolist(), name='targets'),
                    DataAttribute([i] * len(y_train_tensor), name='targets_task_labels', use_in_getitem=True)
                ]
            )
            test_task_dataset = AvalancheDataset(
                [pytorch_test_dataset], # Pass as a list of datasets
                data_attributes=[
                    DataAttribute(y_test_tensor.tolist(), name='targets'),
                    DataAttribute([i] * len(y_test_tensor), name='targets_task_labels', use_in_getitem=True)
                ]
            )

            # --- New: Attach custom collate_fn to dataset ---
            train_task_dataset.collate_fn = pad_collate_fn
            test_task_dataset.collate_fn = pad_collate_fn
            # ----------------------------------------------

            train_datasets.append(train_task_dataset)
            test_datasets.append(test_task_dataset)

        if not train_datasets:
            raise ValueError("Failed to load any UCR dataset, cannot create benchmark.")

        # MODIFIED: Correctly call benchmark_from_datasets
        benchmark = benchmark_from_datasets(
            train_stream=train_datasets, # Use 'train_stream' as the keyword
            test_stream=test_datasets   # Use 'test_stream' as the keyword
        )
        # Apply decorator to add classification-related attributes to the experience
        benchmark = with_classes_timeline(benchmark)

        print(f"UCR benchmark creation complete. Input channels: {input_channels}, Sequence length: {sequence_length}, Initial classes: {n_initial_classes}")
        return benchmark, input_channels, sequence_length, n_initial_classes

    else:
        raise ValueError(f"Unknown benchmark name: {benchmark_name}")

# Avalanche strategies dictionary
avalanche_strategies = {
    "Naive": Naive,
    "Cumulative": Cumulative,
    "EWC": EWC,
    "GEM": GEM,
    "AGEM": AGEM,
    "Replay": Replay,
    "ER_ACE": ER_ACE,
    "LFL": LFL,
    "SI": SynapticIntelligence
}

class PatchedCumulative(Cumulative):
    def __init__(self, model_ref, **kwargs):
        super().__init__(**kwargs)
        self.model_ref = model_ref # Store a reference to the model

    def criterion(self):
        """
        Only compute loss for samples belonging to the current task.
        """
        if not hasattr(self.model_ref, 'current_task_id') or self.model_ref.current_task_id is None:
            # Fallback to default behavior if current_task_id is not set
            return super().criterion()

        try:
            # Ensure mb_task_id is a tensor and on the same device as mb_y
            # self.mb_task_id is populated by _unpack_minibatch if available in self.mbatch[2]
            # It should be a tensor of task IDs for each sample in the batch.
            if not isinstance(self.mb_task_id, torch.Tensor):
                # This case should ideally not happen if data is prepared correctly by Avalanche
                # Or if the replay buffer correctly stores and yields task IDs.
                # If mb_task_id is not a tensor, we cannot reliably filter.
                # print("[PatchedCumulative CRITERION] mb_task_id is not a tensor. Falling back to super().criterion()")
                return super().criterion()

            # Ensure model_ref.current_task_id is an int for comparison
            current_task_id_val = int(self.model_ref.current_task_id)
            
            # Create a boolean mask for samples belonging to the current task
            # Ensure mb_task_id is on the same device as mb_y for comparison and masking
            mask = (self.mb_task_id.to(self.mb_y.device) == current_task_id_val)

            if not mask.any():
                # No samples for the current task in this batch (e.g., batch is purely replay from other tasks)
                # In this case, loss should be zero as current head is not trained.
                return torch.tensor(0.0, device=self.device, requires_grad=True)

            masked_mb_output = self.mb_output[mask]
            masked_mb_y = self.mb_y[mask]

            if masked_mb_output.size(0) == 0:
                # This should be caught by 'not mask.any()' but as a safeguard.
                return torch.tensor(0.0, device=self.device, requires_grad=True)
            
            # print(f"[PatchedCumulative CRITERION] Current task: {current_task_id_val}, "
            #       f"Original batch size: {self.mb_y.size(0)}, "
            #       f"Masked batch size: {masked_mb_y.size(0)}")
            # print(f"mb_task_id unique: {torch.unique(self.mb_task_id)}")
            # print(f"mb_y unique before mask: {torch.unique(self.mb_y)}")
            # if masked_mb_y.numel() > 0:
            #    print(f"masked_mb_y unique: {torch.unique(masked_mb_y)}")


            return self._criterion(masked_mb_output, masked_mb_y)
        
        except Exception as e:
            # print(f"[PatchedCumulative CRITERION] Error during patched criterion: {e}. Falling back.")
            # import traceback
            # traceback.print_exc()
            return super().criterion()

class PatchedNaiveForReplay(Naive): # New: Patched Naive version for Replay
    def __init__(self, model_ref, **kwargs):
        super().__init__(**kwargs)
        self.model_ref = model_ref

    def criterion(self):
        if not hasattr(self.model_ref, 'current_task_id') or self.model_ref.current_task_id is None:
            return super().criterion()
        try:
            if not isinstance(self.mb_task_id, torch.Tensor):
                return super().criterion()
            current_task_id_val = int(self.model_ref.current_task_id)
            mask = (self.mb_task_id.to(self.mb_y.device) == current_task_id_val)
            if not mask.any():
                return torch.tensor(0.0, device=self.device, requires_grad=True)
            masked_mb_output = self.mb_output[mask]
            masked_mb_y = self.mb_y[mask]
            if masked_mb_output.size(0) == 0:
                return torch.tensor(0.0, device=self.device, requires_grad=True)
            return self._criterion(masked_mb_output, masked_mb_y)
        except Exception as e:
            return super().criterion()

# --- New: Custom EWC Plugin ---
class CustomEWCPlugin(EWCPlugin):
    def after_training_exp(self, strategy: 'BaseStrategy', **kwargs):
        # Save the model's current state (train or eval)
        was_training = strategy.model.training
        # Force train mode before computing importances
        strategy.model.train()
        # print("[CustomEWCPlugin] Set model to TRAIN mode before computing importances.")

        # Save the original cuDNN state and disable it during importance calculation
        cudnn_enabled_before = torch.backends.cudnn.enabled
        torch.backends.cudnn.enabled = False
        # print("[CustomEWCPlugin] Temporarily disabled cuDNN for EWC importance calculation.")
        
        try:
            # Call the parent class's after_training_exp to perform the actual importance calculation
            super().after_training_exp(strategy, **kwargs)
        finally:
            # Ensure cuDNN state is always restored, even if an error occurred above
            torch.backends.cudnn.enabled = cudnn_enabled_before
            # print(f"[CustomEWCPlugin] Restored cuDNN enabled state to: {cudnn_enabled_before}.")

            # Restore the model's previous state
            if not was_training:
                strategy.model.eval()
                # print("[CustomEWCPlugin] Restored model to EVAL mode after computing importances.")
            # else:
                # print("[CustomEWCPlugin] Model was already in TRAIN mode, kept it that way.")
# --- End of Custom EWC Plugin ---

def run_experiment(strategy_name, benchmark, model, optimizer, criterion, device, args):
    """Runs the CL experiment with the specified strategy"""
    loggers = [InteractiveLogger()]
    if args.log_text:
        loggers.append(TextLogger(open(os.path.join(args.results_log_dir, f'{strategy_name}_log.txt'), 'a', encoding='utf-8')))
    if args.log_tb:
        loggers.append(TensorboardLogger(tb_log_dir=os.path.join(args.results_log_dir, f'tb_logs/{strategy_name}')))

    eval_plugin = EvaluationPlugin(
        accuracy_metrics(minibatch=False, epoch=True, experience=True, stream=True),
        loss_metrics(minibatch=False, epoch=True, experience=True, stream=True),
        forgetting_metrics(experience=True, stream=True),
        cpu_usage_metrics(experience=True),
        timing_metrics(epoch=True, experience=True),
        ram_usage_metrics(experience=True),
        loggers=loggers
    )

    # Instantiate plugins and add to base list
    task_label_plugin = SetTaskLabelPlugin()
    base_plugins = [task_label_plugin]

    cl_strategy = None

    if strategy_name == 'Naive':
        current_plugins = base_plugins
        cl_strategy = Naive(
            model=model,
            optimizer=optimizer,
            criterion=criterion,
            train_mb_size=args.batch_size,
            train_epochs=args.epochs,
            eval_mb_size=args.batch_size,
            device=device,
            evaluator=eval_plugin,
            plugins=current_plugins # Pass plugins
        )
    elif strategy_name == 'EWC':
        current_plugins = base_plugins + [CustomEWCPlugin(ewc_lambda=args.ewc_lambda)]
        cl_strategy = Naive( # EWC is usually added as a plugin to Naive
            model=model,
            optimizer=optimizer,
            criterion=criterion,
            train_mb_size=args.batch_size,
            train_epochs=args.epochs,
            eval_mb_size=args.batch_size,
            device=device,
            evaluator=eval_plugin,
            plugins=current_plugins # Pass plugins
        )
    elif strategy_name == 'Replay':
        print("Using PatchedNaiveForReplay strategy for 'Replay' to handle replay loss.") # Modified log
        storage_policy = ExperienceBalancedBuffer(max_size=args.memory_size)
        current_plugins = base_plugins + [ReplayPlugin(mem_size=args.memory_size, storage_policy=storage_policy)]
        cl_strategy = PatchedNaiveForReplay( # Use PatchedNaiveForReplay
            model_ref=model,        # Pass model_ref
            model=model,
            optimizer=optimizer,
            criterion=criterion,
            train_mb_size=args.batch_size,
            train_epochs=args.epochs,
            eval_mb_size=args.batch_size,
            device=device,
            evaluator=eval_plugin,
            plugins=current_plugins
        )
    elif strategy_name == 'Cumulative':
        print("Using PatchedCumulative strategy for 'Cumulative' to handle replay loss.")
        # Ensure all necessary parameters for Cumulative are passed.
        # Cumulative might take specific args like `repla_mem_size`.
        # Check Avalanche's Cumulative signature.
        # From Avalanche: Cumulative(model, optimizer, criterion, train_mb_size=1, train_epochs=1, eval_mb_size=None, device=None, plugins=None, evaluator=None, eval_every=-1, **base_kwargs)
        cl_strategy = PatchedCumulative(
            model_ref=model, # Pass the model reference for the patch
            model=model, 
            optimizer=optimizer, 
            criterion=criterion, 
            train_mb_size=args.batch_size, 
            train_epochs=args.epochs, 
            device=device, 
            plugins=base_plugins,
            evaluator=eval_plugin, # Assuming evaluation_plugin() is defined
            eval_every=1 # Evaluate after each experience
        )
    else:
        raise ValueError(f"Unknown strategy: {strategy_name}")

    print(f"\n--- Starting Training: {strategy_name} ---")
    results = []

    for experience in benchmark.streams['train_stream']:
        print(f">>> Experience Start: {experience.current_experience} <<<")
        print(f"Classes in current experience: {experience.classes_in_this_experience}")

        # Dynamically add classifier head - get task_id directly from current experience
        current_exp_task_id = -1 # Initialize just in case
        if hasattr(experience, 'task_label'): # Should be set by with_classes_timeline
            current_exp_task_id = experience.task_label
        elif hasattr(experience, 'dataset') and hasattr(experience.dataset, 'targets_task_labels'):
            task_labels_attr = experience.dataset.targets_task_labels
            # Ensure task_labels_attr is DataAttribute and its .data attribute is not empty
            if isinstance(task_labels_attr, DataAttribute) and hasattr(task_labels_attr, 'data') and task_labels_attr.data:
                current_exp_task_id = task_labels_attr.data[0] # Access the first element of the .data attribute
                print(f"[RUN_EXPERIMENT] Info: Used fallback to experience.dataset.targets_task_labels.data[0] to get task_id: {current_exp_task_id} for exp {experience.current_experience}")
            else:
                print(f"[RUN_EXPERIMENT] CRITICAL WARNING: 'targets_task_labels' found but not a valid/non-empty DataAttribute for exp {experience.current_experience}. Defaulting to 0.")
                current_exp_task_id = 0 
        else:
            # This case theoretically shouldn't happen because we explicitly assigned task_labels when creating the UCR benchmark and applied with_classes_timeline
            print(f"[RUN_EXPERIMENT] CRITICAL WARNING: Could not determine task_id for exp {experience.current_experience}. Defaulting to 0. This may lead to errors.")
            current_exp_task_id = 0 

        print(f"[RUN_EXPERIMENT] Before head check for training exp {experience.current_experience}: model has {len(model.task_classifiers)} heads. Determined task_id for this exp: {current_exp_task_id}")

        # Check if a new head needs to be added for the current task ID
        if current_exp_task_id >= len(model.task_classifiers): 
            num_classes_in_task = len(experience.classes_in_this_experience)
            if current_exp_task_id == len(model.task_classifiers):
                print(f"[RUN_EXPERIMENT] Adding new head for task {current_exp_task_id} with {num_classes_in_task} classes, as model has {len(model.task_classifiers)} heads.")
                model.add_task_classifier(num_classes_in_task, device)
                print(f"[RUN_EXPERIMENT] Added head for task {current_exp_task_id}. Model now has {len(model.task_classifiers)} heads.")
                print("[RUN_EXPERIMENT] Re-creating optimizer for the strategy to include new head parameters.")
                optimizer = optim.Adam(model.parameters(), lr=args.lr) 
                cl_strategy.optimizer = optimizer 
            else:
                print(f"[RUN_EXPERIMENT] Warning/Error: Task ID {current_exp_task_id} seems to be out of sequence or head already exists. Current heads: {len(model.task_classifiers)}.")

        # SetTaskLabelPlugin will set model.current_task_id inside cl_strategy.train() during the before_training_exp callback
        # using experience.task_label (or fallback logic)
        
        # The model.current_task_id will be used by model.forward()
        print(f"-- >> Training on exp {experience.current_experience} for task {current_exp_task_id} (model.current_task_id will be set by plugin inside strategy.train) << --")
        cl_strategy.train(experience)
        print(f"<<< Experience End: {experience.current_experience} >>>")

    print(f"--- All training experiences finished: {strategy_name} ---")

    # After all training experiences are completed, perform a final evaluation
    print(f"--- Starting final evaluation for strategy {strategy_name} (after all training experiences) ---")
    final_evaluation_results = cl_strategy.eval(benchmark.streams['test_stream'])
    
    # --- New: Print detailed final evaluation results --- 
    print(f"--- [DEBUG] Detailed final evaluation results for strategy: {strategy_name} ---")
    import pprint
    pp = pprint.PrettyPrinter(indent=2)
    pp.pprint(final_evaluation_results)
    print(f"--- [END DEBUG] Detailed final evaluation results for strategy: {strategy_name} ---")
    # -------------------------------------

    # The results list now contains only the results of this final evaluation
    # If evaluation after each experience is needed, a different structure is required
    results.append(final_evaluation_results) 

    # --- New: Print final metric summary --- (This logic is now based on the last (and only) element in results)
    if results:
        print(f"\n--- Final Summary for Strategy: {strategy_name} ---")
        final_metrics = results[-1] # Get metrics from the last evaluation

        # 1. Accuracy and Forgetting
        print("\n  Performance Metrics:") 
        # Try to match the actual key names in the log
        final_avg_acc_metric_key_actual = 'Top1_Acc_Stream/eval_phase/test_stream_stream' 
        if final_avg_acc_metric_key_actual in final_metrics:
            print(f"  Final Average Accuracy (all tasks): {final_metrics[final_avg_acc_metric_key_actual]:.4f}")
        else:
            # If the above key is not found, try the key from previous code (in case of config or version changes)
            original_acc_key = 'Top1_Acc_Stream/eval_phase/test_stream/'
            if original_acc_key in final_metrics:
                print(f"  Final Average Accuracy (all tasks): {final_metrics[original_acc_key]:.4f}")
            else:
                print(f"  Final Average Accuracy (all tasks): Metric not found (checked {final_avg_acc_metric_key_actual} and {original_acc_key})")

        # Average Forgetting (BWT)
        # Try to match the actual key names in the log
        avg_forgetting_metric_key_actual = 'StreamForgetting/eval_phase/test_stream_stream' 
        if avg_forgetting_metric_key_actual in final_metrics:
            print(f"  Average Forgetting (BWT): {final_metrics[avg_forgetting_metric_key_actual]:.4f}")
        else:
            original_forgetting_key = 'StreamForgetting/eval_phase/test_stream' # Avalanche 0.5+
            compat_forgetting_key_old = 'Forgetting_Stream/eval_phase/test_stream/'
            if original_forgetting_key in final_metrics:
                 print(f"  Average Forgetting (BWT): {final_metrics[original_forgetting_key]:.4f}")
            elif compat_forgetting_key_old in final_metrics:
                print(f"  Average Forgetting (BWT): {final_metrics[compat_forgetting_key_old]:.4f}")
            else:
                print(f"  Average Forgetting (BWT): Metric not found (checked {avg_forgetting_metric_key_actual}, {original_forgetting_key}, {compat_forgetting_key_old})")

        print("  Final Per-Task Accuracies (after all experiences):")
        num_experiences = len(benchmark.streams['train_stream']) # MODIFIED HERE
        for task_id in range(num_experiences):
            # Metric key for per-task accuracy after all experiences
            # The last ExpXXX in the key refers to the evaluation point (after which training experience)
            # Since we evaluate once after all training, it should be num_experiences - 1
            # Example: Task000/Exp009 if there are 10 experiences (0-9)
            metric_name = f'Top1_Acc_Exp/eval_phase/test_stream_stream/Task{task_id:03d}/Exp{num_experiences-1:03d}'
            if metric_name in final_metrics:
                print(f"    Task {task_id} Accuracy: {final_metrics[metric_name]:.4f}")
            else:
                print(f"    Task {task_id} Accuracy: Metric not found ({metric_name})")
        
        # 2. Computation Efficiency Metrics
        print("\n  Efficiency Metrics:")
        num_experiences = len(benchmark.streams['train_stream']) # MODIFIED HERE

        # CPU Usage
        # Avalanche v0.5+ typically uses 'CPUUsage_Experience/eval_phase/test_stream' 
        # when metric is set to experience=True in EvaluationPlugin (stream=True is also a common combination)
        cpu_usage_key = 'CPUUsage_Experience/eval_phase/test_stream' 
        if cpu_usage_key in final_metrics:
            print(f"  CPU Usage (at final evaluation): {final_metrics[cpu_usage_key]}%")
        else:
            # Alternative key in case metric name is slightly different or from older version
            alt_cpu_key = f'CPUUsage_Exp/eval_phase/test_stream/Exp{num_experiences-1:03d}'
            if alt_cpu_key in final_metrics:
                print(f"  CPU Usage (at final evaluation): {final_metrics[alt_cpu_key]}%")
            else:
                print(f"  CPU Usage (at final evaluation): Metric not found (e.g., {cpu_usage_key} or {alt_cpu_key})")

        # RAM Usage
        ram_usage_key = 'RAMUsage_Experience/eval_phase/test_stream'
        if ram_usage_key in final_metrics:
            print(f"  RAM Usage (at final evaluation): {final_metrics[ram_usage_key]} MB")
        else:
            alt_ram_key = f'RAMUsage_Exp/eval_phase/test_stream/Exp{num_experiences-1:03d}'
            if alt_ram_key in final_metrics:
                 print(f"  RAM Usage (at final evaluation): {final_metrics[alt_ram_key]} MB")
            else:
                print(f"  RAM Usage (at final evaluation): Metric not found (e.g., {ram_usage_key} or {alt_ram_key})")
        
        print("  (Detailed timing, CPU, and RAM usage metrics over all experiences are available in the log files and TensorBoard.)")
        print("--- End of Summary ---\n")
    # --- End of Summary ---
    
    return results

def main(args):
    # Set seed
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(args.seed)

    # Set device
    device = torch.device(f"cuda:{args.cuda}" if torch.cuda.is_available() and args.cuda >= 0 else "cpu")
    print(f"Using device: {device}")

    # Create benchmark
    # Modify here to allow selecting benchmark and getting dimensions during creation
    print(f"Preparing {args.benchmark_name} benchmark...")
    benchmark, input_channels, sequence_length, n_initial_classes = create_benchmark(
        benchmark_name=args.benchmark_name, 
        n_experiences_mnist=args.mnist_experiences, # Need to add this argparse argument
        seed=args.seed,
        data_dir=args.data_dir # Need to add this argparse argument
    )
    print("Benchmark preparation complete.")
    
    # n_initial_classes is already returned from create_benchmark
    print(f"Initial classes obtained from benchmark: {n_initial_classes}")
    print(f"Input channels obtained from benchmark: {input_channels}")
    print(f"Sequence length obtained from benchmark: {sequence_length}")

    # Removed the Non-CL Baseline Computation Loop
    # baseline_accuracies_map is no longer computed here
    baseline_accuracies_map = {} # Keep empty map for plot function compatibility, but it won't be filled
    task_names_for_plotting = []

    # Determine task names based on benchmark type
    if args.benchmark_name == "ucr_timeseries":
        task_names_for_plotting = UCR_DATASET_NAMES[:len(benchmark.streams['train_stream'])]
    elif args.benchmark_name == "split_mnist":
        task_names_for_plotting = [f"MNIST Exp {i}" for i in range(len(benchmark.streams['train_stream']))]
    else:
        task_names_for_plotting = [f"Task {i}" for i in range(len(benchmark.streams['train_stream']))]

    all_cl_results = {}
    criterion = nn.CrossEntropyLoss()
    for strategy_name in args.strategies:
        print(f"\nResetting model and optimizer to run strategy: {strategy_name}")
        # Re-initialize the model each time a strategy is run to ensure a clean state
        cl_model = CNN_BiGRU_Attention(
            input_channels=input_channels, 
            sequence_length=sequence_length, 
            num_classes_initial=n_initial_classes, # Use n_initial_classes from benchmark
            num_multiscale_paths=args.num_multiscale_paths,
            final_dropout_rate=args.final_dropout_rate,
            gru_hidden_size=args.gru_hidden_size,
            num_gru_layers=args.num_gru_layers,
            adaptive_pool_output_size=args.adaptive_pool_output_size
        ).to(device)
        cl_optimizer = optim.Adam(cl_model.parameters(), lr=args.lr)
        results = run_experiment(strategy_name, benchmark, cl_model, cl_optimizer, criterion, device, args)
        all_cl_results[strategy_name] = results

    print("\n--- All CL experiments finished ---")

    # --- Save final results for all strategies ---
    # Create results saving directory (if it doesn't exist)
    # Use timestamp naming to avoid overwriting
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    # Ensure experiment_results directory exists
    os.makedirs('experiment_results', exist_ok=True)
    args.results_log_dir = os.path.join('experiment_results', f'cl_results_{timestamp}')
    os.makedirs(args.results_log_dir, exist_ok=True)
    print(f"Continual learning experiment results will be saved to: {args.results_log_dir}")

    # Create plots output directory (if it doesn't exist)
    # Ensure plots_from_results directory exists
    os.makedirs('plots_from_results', exist_ok=True)
    args.plots_output_dir = os.path.join('plots_from_results', f'cl_plots_{timestamp}')
    os.makedirs(args.plots_output_dir, exist_ok=True)
    print(f"Continual learning plots will be saved to: {args.plots_output_dir}")

    cl_results_file = os.path.join(args.results_log_dir, "cl_strategies_summary.json")
    try:
        with open(cl_results_file, 'w', encoding='utf-8') as f:
            json.dump(all_cl_results, f, indent=4)
        print(f"Summary results for all continual learning strategies saved to: {cl_results_file}")
    except Exception as e:
        print(f"Error: Could not save continual learning results to '{cl_results_file}': {e}")
        # import traceback # Moved import to the function where it's used
        # traceback.print_exc()

    # --- Load baseline results and plot comparison (optional, visualization_all.py also does this) ---
    num_experiences_in_benchmark = len(benchmark.streams['train_stream'])

    if not all_cl_results:
        print("No CL results to plot.")
    else:
        print(f"Preparing to plot comparison charts for {len(all_cl_results)} strategies. Plots will be saved to: {args.plots_output_dir}")
        plot_comparison_results(
            all_cl_results, 
            num_experiences_in_benchmark, 
            task_names_for_plotting,
            baseline_accuracies_map, # Pass the empty map
            args.plots_output_dir
        )

    print("\n--- Script execution finished ---")

def train_model(model, X_train, y_train, X_val=None, y_val=None, batch_size=32, num_epochs=100, learning_rate=0.001):
    """Trains the model and returns training history, showing progress with tqdm"""
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)
    X_train_tensor = torch.FloatTensor(X_train)
    y_train_tensor = torch.LongTensor(y_train)
    train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
    train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    criterion = nn.CrossEntropyLoss()
    history = {'train_loss': [], 'train_acc': [], 'val_loss': [], 'val_acc': []}
    
    epoch_pbar = tqdm(range(num_epochs), desc="Epochs", leave=True) # Simplified desc
    for epoch in epoch_pbar:
        model.train()
        running_loss = 0.0; correct_predictions = 0; total_samples = 0
        train_pbar = tqdm(train_loader, desc=f"Epoch {epoch+1}/{num_epochs} [Train]", leave=False) # Simplified desc
        for batch_X, batch_y in train_pbar:
            batch_X, batch_y = batch_X.to(device), batch_y.to(device)
            optimizer.zero_grad()
            # Simplified model call - assumes model handles single/multi-head internally or is only used in non-CL context here
            outputs = model(batch_X) 
            loss = criterion(outputs, batch_y)
            loss.backward(); optimizer.step()
            running_loss += loss.item() * batch_X.size(0)
            _, predicted = torch.max(outputs.data, 1)
            total_samples += batch_y.size(0)
            correct_predictions += (predicted == batch_y).sum().item()
            train_pbar.set_postfix({'loss': f'{running_loss / total_samples:.4f}', 'acc': f'{correct_predictions / total_samples:.4f}'})
        epoch_train_loss = running_loss / total_samples
        epoch_train_acc = correct_predictions / total_samples
        history['train_loss'].append(epoch_train_loss); history['train_acc'].append(epoch_train_acc)

        if X_val is not None and y_val is not None:
            X_val_tensor = torch.FloatTensor(X_val)
            y_val_tensor = torch.LongTensor(y_val)
            val_dataset = TensorDataset(X_val_tensor, y_val_tensor)
            val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=batch_size)
            model.eval(); val_loss = 0.0; val_correct = 0; val_total = 0
            val_pbar = tqdm(val_loader, desc=f"Epoch {epoch+1}/{num_epochs} [Val]", leave=False) # Simplified desc
            with torch.no_grad():
                for batch_X_val, batch_y_val in val_pbar:
                    batch_X_val, batch_y_val = batch_X_val.to(device), batch_y_val.to(device)
                    # Simplified model call
                    outputs_val = model(batch_X_val)
                    loss_val = criterion(outputs_val, batch_y_val)
                    val_loss += loss_val.item() * batch_X_val.size(0)
                    _, predicted_val = torch.max(outputs_val.data, 1)
                    val_total += batch_y_val.size(0)
                    val_correct += (predicted_val == batch_y_val).sum().item()
                    val_pbar.set_postfix({'val_loss': f'{val_loss / val_total:.4f}', 'val_acc': f'{val_correct / val_total:.4f}'})
            epoch_val_loss = val_loss / val_total; epoch_val_acc = val_correct / val_total
            history['val_loss'].append(epoch_val_loss); history['val_acc'].append(epoch_val_acc)
            epoch_pbar.set_postfix({'Train Loss': f'{epoch_train_loss:.4f}', 'Train Acc': f'{epoch_train_acc:.4f}', 'Val Loss': f'{epoch_val_loss:.4f}', 'Val Acc': f'{epoch_val_acc:.4f}'})
        else: 
            epoch_pbar.set_postfix({'Train Loss': f'{epoch_train_loss:.4f}', 'Train Acc': f'{epoch_train_acc:.4f}'})
            history['val_loss'].append(None) 
            history['val_acc'].append(None) # Also append None for val_acc

    return history # Return training history

def evaluate_model(model, X_test, y_test, batch_size=32):
    """
    Evaluates the model and returns test loss, accuracy, and predictions, showing progress with tqdm.
    X_test should be a numpy array.
    """
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device); model.eval()
    X_test_tensor = torch.FloatTensor(X_test); y_test_tensor = torch.LongTensor(y_test)
    test_dataset = TensorDataset(X_test_tensor, y_test_tensor)
    test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=batch_size)
    criterion = nn.CrossEntropyLoss()
    test_loss = 0.0; test_correct = 0; test_total = 0; all_predictions = []
    eval_pbar = tqdm(test_loader, desc="Evaluating", leave=False) # Simplified desc
    with torch.no_grad():
        for batch_X, batch_y in eval_pbar:
            batch_X, batch_y = batch_X.to(device), batch_y.to(device)
            # Simplified model call
            outputs = model(batch_X)
            loss = criterion(outputs, batch_y)
            test_loss += loss.item() * batch_X.size(0)
            _, predicted = torch.max(outputs.data, 1)
            test_total += batch_y.size(0)
            test_correct += (predicted == batch_y).sum().item()
            all_predictions.extend(predicted.cpu().numpy())
            # Update postfix with current batch metrics
            eval_pbar.set_postfix({'loss': f'{test_loss / test_total:.4f}', 'acc': f'{test_correct / test_total:.4f}'})

    final_test_loss = test_loss / test_total
    final_test_acc = test_correct / test_total
    
    # Print final test loss and accuracy
    print(f"Final Test Loss: {final_test_loss:.4f}, Final Test Accuracy: {final_test_acc:.4f}")

    return final_test_loss, final_test_acc, all_predictions

def plot_comparison_results(cl_results_dict, num_tasks_in_benchmark, task_names_for_x_axis, 
                             baseline_task_accuracies_map, # Still accepts map, but won't use it if empty
                             output_plot_dir):
    """
    Plots comparison results for Continual Learning strategies.
    Includes per-task accuracy heatmap.
    """
    os.makedirs(output_plot_dir, exist_ok=True)
    strategies = list(cl_results_dict.keys())
    
    # --- 1. Plot Average Accuracy (CL Strategies Only) ---
    # Average accuracy over the entire test stream after all experiences.
    # We need the metric from the final evaluation results for each strategy.
    avg_accuracies_cl = []
    valid_strategies_avg = []
    
    for strategy in strategies:
        # Check if strategy has results from the final evaluation
        if strategy not in cl_results_dict or not cl_results_dict[strategy] or not cl_results_dict[strategy][-1]:
             print(f"Warning: Strategy {strategy} has no final evaluation results, skipping average accuracy plot.")
             continue
             
        final_metrics = cl_results_dict[strategy][-1][0] # Metrics from the last evaluation (first element of the list)

        # Attempt to find the average stream accuracy metric key
        # Common keys for average stream accuracy after the final evaluation
        avg_acc_keys_to_check = [
            f'Top1_Acc_Stream/eval_phase/test_stream_stream',
            f'Top1_Acc_Stream/eval_phase/test_stream/',
            # Add other potential keys based on Avalanche version or config if needed
        ]
        
        found_acc = None
        for key in avg_acc_keys_to_check:
            if key in final_metrics:
                found_acc = final_metrics[key]
                break

        if found_acc is not None:
             avg_accuracies_cl.append(found_acc)
             valid_strategies_avg.append(strategy)
        else: 
             print(f"Warning: No matching average accuracy metric key found for strategy {strategy} in final evaluation results. Checked keys: {avg_acc_keys_to_check}. Skipping average accuracy plot for this strategy.")

    if not valid_strategies_avg: 
        print("No valid average CL accuracy data available for plotting.")
        # continue to per-task plot
    else:
        plt.figure(figsize=(max(6, len(valid_strategies_avg) * 1.5), 5))
        bars = plt.bar(valid_strategies_avg, avg_accuracies_cl, color=['skyblue', 'lightgreen', 'salmon', 'gold', 'lightcoral'][:len(valid_strategies_avg)])
        plt.ylabel('Average Accuracy (All Tasks)')
        plt.title('Average Accuracy Comparison (CL Strategies)')
        plt.ylim(0, 1.05)
        for bar in bars:
            yval = bar.get_height()
            plt.text(bar.get_x() + bar.get_width()/2.0, yval + 0.01, f'{yval:.3f}', ha='center', va='bottom')
        plt.xticks(rotation=15, ha="right")
        plt.tight_layout()
        avg_plot_path = os.path.join(output_plot_dir, 'average_accuracy_comparison_cl.png') # Changed filename to differentiate
        plt.savefig(avg_plot_path)
        print(f"Average CL accuracy comparison plot saved to: {avg_plot_path}"); plt.close()

    # --- 2. Plot Per-Task Accuracy Heatmap (CL Strategies Only) ---
    # This plot shows the accuracy on each task after training on all tasks.
    per_task_accuracies_cl = {strategy: [0.0] * num_tasks_in_benchmark for strategy in strategies}
    has_per_task_data = False
    num_experiences = num_tasks_in_benchmark # Assuming 1 task per experience

    for strategy in strategies:
        # Get metrics from the final evaluation results for this strategy
        if strategy not in cl_results_dict or not cl_results_dict[strategy] or not cl_results_dict[strategy][-1]:
             print(f"Warning: Strategy {strategy} has no final evaluation results, skipping per-task heatmap.")
             continue
        
        metrics_from_final_eval = cl_results_dict[strategy][-1][0] # Metrics after the last training experience

        for task_id in range(num_tasks_in_benchmark):
            # Metric key for per-task accuracy after all experiences
            # This key typically includes the evaluation stream (test_stream), the task ID being evaluated (TaskXXX),
            # and the experience during which the evaluation happened (ExpYYY).
            # Since we evaluate ONCE after ALL training experiences, YYY should be num_experiences - 1.
            metric_name_to_check = [
                 f'Top1_Acc_Exp/eval_phase/test_stream_stream/Task{task_id:03d}/Exp{num_experiences-1:03d}',
                 f'Top1_Acc_Exp/eval_phase/test_stream/Task{task_id:03d}/Exp{num_experiences-1:03d}',
                 # Add other potential keys
            ]
            
            found_acc = None
            for key in metric_name_to_check:
                 if key in metrics_from_final_eval:
                      found_acc = metrics_from_final_eval[key]
                      break

            if found_acc is not None:
                 per_task_accuracies_cl[strategy][task_id] = found_acc
                 has_per_task_data = True
            else:
                 # print(f"Warning: Strategy {strategy} did not find metric key for Task {task_id} in final eval. Checked keys: {metric_name_to_check}")
                 pass # Keep default 0.0

    if not has_per_task_data:
        print("No valid continual learning per-task accuracy data available for plotting heatmap.")
        return

    # Create DataFrame for heatmap
    # Rows: Strategies, Columns: Tasks
    per_task_acc_df = pd.DataFrame(per_task_accuracies_cl).T # Transpose to have strategies as rows

    # Rename columns to task names if available
    if task_names_for_x_axis and len(task_names_for_x_axis) == num_tasks_in_benchmark:
         per_task_acc_df.columns = task_names_for_x_axis
    else:
         per_task_acc_df.columns = [f'Task {i}' for i in range(num_tasks_in_benchmark)]
         print("Warning: Task name list length does not match number of tasks. Using default task indices as column names.")

    plt.figure(figsize=(max(12, num_tasks_in_benchmark * 1.0), max(6, len(strategies) * 0.7)))
    sns.heatmap(per_task_acc_df, annot=True, fmt='.3f', cmap='viridis', linewidths=.5)
    plt.title('Per-Task Accuracy Heatmap After All Tasks (CL Strategies)')
    plt.xlabel('Task')
    plt.ylabel('Continual Learning Strategy')
    plt.tight_layout()
    per_task_heatmap_path = os.path.join(output_plot_dir, 'cl_per_task_accuracy_heatmap.png') # Changed filename
    plt.savefig(per_task_heatmap_path)
    print(f"Continual learning per-task accuracy heatmap saved to: {per_task_heatmap_path}"); plt.close()

    # --- 3. Plot Forgetting Matrix (CL Strategies Only) ---
    # This shows the forgetting on each task after each subsequent task.
    # We need the forgetting metrics calculated by Avalanche.
    # The metric key is typically 'Forgetting_Exp/eval_phase/test_stream/TaskXXX/ExpYYY'
    # YYY is the experience after which evaluation happened.
    # To get the forgetting matrix, we need evaluation results after each experience.
    # The 'results' list in run_experiment contained evaluation results *after* each training experience.
    # However, I modified run_experiment to only store the final evaluation result in the 'results' list.
    # To plot the forgetting matrix, we would need to save evaluation results after *each* experience training.
    # Let's modify run_experiment to return ALL eval results, not just the final one.

    # MODIFICATION NEEDED IN run_experiment: Capture results after EACH exp training
    # Let's assume for now that the `all_cl_results` dictionary, as saved to JSON,
    # contains evaluation results after EACH experience. The original code structure suggested this.
    # Let's revisit `run_experiment` to ensure it does this.

    # Assuming all_cl_results structure is {strategy_name: [eval_results_exp0, eval_results_exp1, ..., eval_results_exp_last]}
    # where each eval_results_expX is a dictionary of metrics.
    
    forgetting_matrix_data = {strategy: np.zeros((num_tasks_in_benchmark, num_tasks_in_benchmark)) for strategy in strategies}
    has_forgetting_data = False

    for strategy in strategies:
        if strategy not in all_cl_results or not all_cl_results[strategy]:
            print(f"Warning: Strategy {strategy} has no CL results, skipping forgetting matrix.")
            continue

        eval_results_list = all_cl_results[strategy] # List of eval results after each training experience

        for trained_exp_idx in range(len(eval_results_list)):
            # Get metrics from evaluation after training `trained_exp_idx`
            metrics_after_trained_exp = eval_results_list[trained_exp_idx][0] # First element is the metrics dict

            for evaluated_task_id in range(num_tasks_in_benchmark):
                # Forgetting metric key: evaluated task ID and the experience AFTER which training occurred.
                # Example: Forgetting_Exp/eval_phase/test_stream/Task000/Exp009 (Forgetting on Task 0 after training Exp 9)
                forgetting_key = f'Forgetting_Exp/eval_phase/test_stream_stream/Task{evaluated_task_id:03d}/Exp{trained_exp_idx:03d}'
                # Alternative key format
                forgetting_key_alt = f'Forgetting_Exp/eval_phase/test_stream/Task{evaluated_task_id:03d}/Exp{trained_exp_idx:03d}'

                found_forgetting = None
                if forgetting_key in metrics_after_trained_exp:
                    found_forgetting = metrics_after_trained_exp[forgetting_key]
                elif forgetting_key_alt in metrics_after_trained_exp:
                     found_forgetting = metrics_after_trained_exp[forgetting_key_alt]

                if found_forgetting is not None:
                    # The matrix shows forgetting on Task i after training Task j.
                    # Row index = Task being evaluated (evaluated_task_id)
                    # Column index = Task *after* which the evaluation occurred (trained_exp_idx)
                    forgetting_matrix_data[strategy][evaluated_task_id, trained_exp_idx] = found_forgetting
                    has_forgetting_data = True
                # else:
                    # print(f"Warning: Strategy {strategy} did not find forgetting key for Task {evaluated_task_id} after training Exp {trained_exp_idx}. Checked keys: {forgetting_key}, {forgetting_key_alt}")
                    # Value remains 0.0

    if not has_forgetting_data:
        print("No valid continual learning forgetting data available for plotting matrix.")
    else:
        for strategy in strategies:
             if strategy not in forgetting_matrix_data or not np.any(forgetting_matrix_data[strategy] != 0): # Check if there is any non-zero forgetting data
                 print(f"Warning: Strategy {strategy} has no forgetting data to plot.")
                 continue

             plt.figure(figsize=(max(8, num_tasks_in_benchmark * 0.8), max(7, num_tasks_in_benchmark * 0.7)))
             sns.heatmap(
                 forgetting_matrix_data[strategy],
                 annot=True, 
                 fmt='.3f', 
                 cmap='Reds', # Typically use a color map showing 'badness' like Reds
                 linewidths=.5,
                 xticklabels=[f'After Task {i}' for i in range(num_tasks_in_benchmark)],
                 yticklabels=[f'On Task {i}' for i in range(num_tasks_in_benchmark)]
             )
             plt.title(f'Forgetting Matrix for {strategy}')
             plt.xlabel('Training Experience (Task Trained After)')
             plt.ylabel('Task Evaluated On')
             plt.tight_layout()
             forgetting_matrix_path = os.path.join(output_plot_dir, f'{strategy}_forgetting_matrix.png')
             plt.savefig(forgetting_matrix_path)
             print(f"Forgetting matrix for {strategy} saved to: {forgetting_matrix_path}"); plt.close()

    # --- 4. Plot Backward Transfer (BWT) --- (This can be calculated from the per-task accuracy)
    # BWT measures the average improvement on previous tasks after learning a new task.
    # A positive BWT means learning new tasks helps performance on old tasks.
    # BWT = Avg(Accuracy_on_Task_i_after_Task_j) - Accuracy_on_Task_i_after_Task_i, for j > i
    # Avalanche already provides a BWT metric (StreamBWT/eval_phase/test_stream_stream or similar)
    # We can extract this directly from the final evaluation metrics.

    bwt_scores = []
    valid_strategies_bwt = []

    for strategy in strategies:
        if strategy not in cl_results_dict or not cl_results_dict[strategy] or not cl_results_dict[strategy][-1]:
             print(f"Warning: Strategy {strategy} has no final evaluation results, skipping BWT plot.")
             continue
             
        final_metrics = cl_results_dict[strategy][-1][0] # Metrics from the last evaluation

        # Attempt to find the BWT metric key
        bwt_keys_to_check = [
            f'StreamBWT/eval_phase/test_stream_stream',
            f'StreamBWT/eval_phase/test_stream/',
            # Add other potential keys
        ]
        
        found_bwt = None
        for key in bwt_keys_to_check:
            if key in final_metrics:
                found_bwt = final_metrics[key]
                break

        if found_bwt is not None:
             bwt_scores.append(found_bwt)
             valid_strategies_bwt.append(strategy)
        else: 
             print(f"Warning: No matching BWT metric key found for strategy {strategy} in final evaluation results. Checked keys: {bwt_keys_to_check}. Skipping BWT plot for this strategy.")

    if not valid_strategies_bwt:
        print("No valid CL BWT data available for plotting.")
    else:
        plt.figure(figsize=(max(6, len(valid_strategies_bwt) * 1.5), 5))
        bars = plt.bar(valid_strategies_bwt, bwt_scores, color=['skyblue', 'lightgreen', 'salmon', 'gold', 'lightcoral'][:len(valid_strategies_bwt)])
        plt.ylabel('Backward Transfer (BWT)')
        plt.title('Backward Transfer (BWT) Comparison (CL Strategies)')
        # BWT can be negative, so y limit should accommodate this.
        # Find minimum BWT to set appropriate lower limit.
        min_bwt = min(0, min(bwt_scores)) - 0.05 # Add some padding
        plt.ylim(min_bwt, max(0, max(bwt_scores)) + 0.05)

        for bar in bars:
            yval = bar.get_height()
            # Adjust text position based on positive/negative BWT
            va = 'bottom' if yval >= 0 else 'top'
            plt.text(bar.get_x() + bar.get_width()/2.0, yval + (0.01 if yval >= 0 else -0.01), f'{yval:.3f}', ha='center', va=va)

        plt.xticks(rotation=15, ha="right")
        plt.tight_layout()
        bwt_plot_path = os.path.join(output_plot_dir, 'cl_bwt_comparison.png')
        plt.savefig(bwt_plot_path)
        print(f"CL BWT comparison plot saved to: {bwt_plot_path}"); plt.close()


def autolabel(rects_group):
    """Attach a text label above each bar in *rects*, displaying its height."""
    for rects in rects_group:
        for rect in rects:
            height = rect.get_height()
            # Add check for isnan
            if not np.isnan(height):
                 plt.text(rect.get_x() + rect.get_width()/2., height, 
                         '%.3f' % height, ha='center', va='bottom')

if __name__ == "__main__":
    # For debugging, check if running interactively or as script
    # if len(sys.argv) > 1:
    #     print("--- Script execution started in __main__ block ---")
    # else:
    #      print("--- Running interactively in __main__ block ---")

    parser = argparse.ArgumentParser(description='Run Continual Learning experiments on Time Series data.')
    # Benchmark Selection
    parser.add_argument('--benchmark_name', type=str, default='ucr_timeseries', 
                        choices=['ucr_timeseries', 'split_mnist'], help='Name of the benchmark to use.')
    parser.add_argument('--data_dir', type=str, default='dataset', 
                        help='Directory where datasets are stored.')
    parser.add_argument('--mnist_experiences', type=int, default=5,
                        help='Number of experiences for Split MNIST benchmark.') # Only relevant for split_mnist

    # Continual Learning Strategy Selection
    parser.add_argument('--strategies', nargs='+', type=str, 
                        default=['Naive', 'EWC', 'Replay', 'LwF'], 
                        choices=['Naive', 'EWC', 'Replay', 'LwF', 'GEM', 'AGEM', 'ER_ACE', 'LFL', 'SI', 'Cumulative'], 
                        help='List of CL strategies to run.')

    # Logging and Visualization
    parser.add_argument('--log_text', action='store_true', help='Log results to a text file.')
    parser.add_argument('--log_tb', action='store_true', help='Log results to Tensorboard.')
    # Removed direct plot args, plots are generated by visualization_all.py or within train.py now

    # Training Hyperparameters (Adjust as needed)
    parser.add_argument('--lr', type=float, default=0.001, help='Learning rate.')
    parser.add_argument('--epochs', type=int, default=10, help='Number of training epochs per experience.') # Number of training epochs per task
    parser.add_argument('--batch_size', type=int, default=32, help='Batch size.')

    # Model Specific Hyperparameters (CNN_BiGRU_Attention)
    parser.add_argument('--num_multiscale_paths', type=int, default=4,
                        help='Number of parallel convolutional paths in MultiScaleFeatureExtraction.')
    parser.add_argument('--final_dropout_rate', type=float, default=0.4,
                        help='Dropout rate before the final classifier.')
    parser.add_argument('--gru_hidden_size', type=int, default=128, help='Hidden size of GRU layers.')
    parser.add_argument('--num_gru_layers', type=int, default=2, help='Number of GRU layers.')
    parser.add_argument('--adaptive_pool_output_size', type=int, default=50,
                        help='Output size of AdaptiveAvgPool1d before GRU.')

    # Continual Learning Strategy Hyperparameters (Adjust as needed)
    parser.add_argument('--ewc_lambda', type=float, default=0.4, help='EWC lambda parameter.')
    parser.add_argument('--memory_size', type=int, default=200, help='Replay buffer size.') # For Replay strategy
    parser.add_argument('--lwf_alpha', type=float, default=1.0, help='LwF alpha parameter.')
    parser.add_argument('--lwf_temperature', type=float, default=2.0, help='LwF temperature parameter.')
    # Add args for other strategies if needed (e.g., GEM_alpha, AGEM_sample_size, LFL_lambda, SI_lambda)

    # Other Settings
    parser.add_argument('--cuda', type=int, default=0, 
                        help='cuda device id to use. Use -1 for CPU') # Which GPU to use
    parser.add_argument('--seed', type=int, default=42, help='Random seed.')

    args = parser.parse_args()
    
    # Add results_log_dir and plots_output_dir to args here if they are not set by argparse (they are set in main now)
    # This prevents potential AttributeError if main is not called.
    if not hasattr(args, 'results_log_dir'):
         timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
         args.results_log_dir = os.path.join('experiment_results', f'cl_results_{timestamp}')
    if not hasattr(args, 'plots_output_dir'):
         timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
         args.plots_output_dir = os.path.join('plots_from_results', f'cl_plots_{timestamp}')

    main(args)

    # --- Add the final print statement ---
    print("--- Script execution finished __main__ block ---")