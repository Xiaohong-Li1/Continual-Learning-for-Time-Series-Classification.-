import os
import numpy as np
import torch
import matplotlib.pyplot as plt
from load_timeseries_data import load_ucr_dataset
from model import CNN_BiGRU_Attention, StandardLSTM, StandardGRU
from train import train_model, evaluate_model
import seaborn as sns
from sklearn.metrics import confusion_matrix, classification_report
import pandas as pd
from datetime import datetime

# Import baseline running functions
from baseline_arima_features import run_arima_baseline_for_dataset
from baseline_random_forest import run_rf_baseline_for_dataset

def train_and_evaluate_all_datasets():
    """Train and evaluate all datasets for PyTorch models and baselines, save results to CSV."""
    # List of datasets
    datasets = [
        'ArrowHead', 'AtrialFibrillation', 'BasicMotions', 'Beef',
        'BeetleFly', 'BirdChicken', 'BME', 'Coffee',
        'DodgerLoopDay', 'DodgerLoopGame'
        # Add or remove datasets as needed
    ]
    
    # Configure all models and baselines
    # type: 'pytorch' or 'baseline'
    # runner: For baseline, it's the directly callable function
    # config: Contains parameters needed for instantiation or running
    model_configs = {
        'CNN_BiGRU': {
            'type': 'pytorch', 
            'class': CNN_BiGRU_Attention, 
            'config': {'num_classes_param': 'num_classes_initial'}
        },
        'LSTM': {
            'type': 'pytorch', 
            'class': StandardLSTM, 
            'config': {'num_classes_param': 'num_classes', 'hidden_size': 128, 'num_layers': 2}
        },
        'GRU': {
            'type': 'pytorch', 
            'class': StandardGRU, 
            'config': {'num_classes_param': 'num_classes', 'hidden_size': 128, 'num_layers': 2}
        },
        'ARIMA': {
            'type': 'baseline', 
            'runner': run_arima_baseline_for_dataset, 
            'config': {'arima_order': (1,1,0)} # Can adjust ARIMA order
        },
        'RandomForest': {
            'type': 'baseline', 
            'runner': run_rf_baseline_for_dataset, 
            'config': {'n_estimators': 100} # Can adjust number of estimators for RF
        }
    }
    
    # Create results directory
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    results_dir = f'results_{timestamp}'
    os.makedirs(results_dir, exist_ok=True)
    print(f"Results will be saved in: {results_dir}")
    
    all_results = []
    
    for dataset_name in datasets:
        print(f"\n{'='*10} Processing dataset: {dataset_name} {'='*10}")
        
        try:
            # Load data (all models use the same data loading)
            X_train, y_train, X_test, y_test, classes = load_ucr_dataset(dataset_name)
            print(f"Dataset {dataset_name} loaded successfully. Classes: {classes}")
            num_classes = len(classes)
            sequence_length = X_train.shape[-1] # Assuming the last dimension is sequence length
            
            # Train and evaluate each model/baseline
            for model_name, model_info in model_configs.items():
                print(f"\n--- Starting processing for model: {model_name} ---")
                result = None # Initialize result for current model

                if model_info['type'] == 'pytorch':
                    # --- PyTorch Model Processing ---
                    try:
                        model_class = model_info['class']
                        config = model_info['config']
                        num_classes_param = config['num_classes_param']

                        model_kwargs = {
                            'input_channels': 1, # Assuming UCR data is single-channel after loading
                            num_classes_param: num_classes
                        }
                        # Add model-specific parameters
                        if model_name == 'LSTM' or model_name == 'GRU':
                            model_kwargs['hidden_size'] = config.get('hidden_size', 128)
                            model_kwargs['num_layers'] = config.get('num_layers', 2)
                        elif model_name == 'CNN_BiGRU':
                            model_kwargs['sequence_length'] = sequence_length
                            # Can get more CNN_BiGRU hyperparameters from config

                        model = model_class(**model_kwargs)
                        
                        # Train (using function from train.py)
                        # Note: train_model might need modification to handle different model input expectations and return values
                        # Assuming train_model can be used directly here
                        history = train_model(
                            model=model,
                            X_train=X_train,
                            y_train=y_train,
                            X_val=X_test, # Using test set as validation set for plotting
                            y_val=y_test,
                            batch_size=32,
                            num_epochs=100, # Epochs might need adjustment
                            learning_rate=0.001
                        )
                        
                        # Evaluate (using function from train.py)
                        test_loss, test_acc, y_pred = evaluate_model(
                            model=model,
                            X_test=X_test,
                            y_test=y_test
                        )
                        
                        # --- Plot Learning Curves ---
                        if history and ('train_loss' in history and 'val_loss' in history and 'train_acc' in history and 'val_acc' in history):
                             print(f"Plotting learning curves for {model_name} on {dataset_name}...")
                             try:
                                 plt.figure(figsize=(15, 5))

                                 # Plot loss curves
                                 plt.subplot(1, 2, 1)
                                 plt.plot(history['train_loss'], label='Train Loss')
                                 plt.plot(history['val_loss'], label='Validation Loss')
                                 plt.title(f'{model_name} Loss on {dataset_name}')
                                 plt.xlabel('Epochs')
                                 plt.ylabel('Loss')
                                 plt.legend()
                                 plt.grid(True)

                                 # Plot accuracy curves
                                 plt.subplot(1, 2, 2)
                                 plt.plot(history['train_acc'], label='Train Accuracy')
                                 plt.plot(history['val_acc'], label='Validation Accuracy')
                                 plt.title(f'{model_name} Accuracy on {dataset_name}')
                                 plt.xlabel('Epochs')
                                 plt.ylabel('Accuracy')
                                 plt.legend()
                                 plt.grid(True)
                                 plt.ylim(0, 1.05) # Accuracy range is typically 0-1

                                 plt.tight_layout()
                                 # Save plot
                                 lc_plot_path = os.path.join(results_dir, f'learning_curves_{model_name}_{dataset_name}.png')
                                 plt.savefig(lc_plot_path)
                                 print(f"Learning curves plot saved to: {lc_plot_path}")
                                 plt.close() # Close figure to free memory
                             except Exception as e_lc:
                                 print(f"Error plotting learning curves for {model_name} on {dataset_name}: {e_lc}")
                        else:
                            print(f"Warning: Learning curve data not found for {model_name} on {dataset_name}, skipping plotting.")
                        # ---------------------------

                        # --- If it's CNN_BiGRU model, generate confusion matrix ---
                        if model_name == 'CNN_BiGRU':
                            # List of datasets for which to generate confusion matrix (modify as needed)
                            datasets_to_plot_cm = ['ArrowHead', 'BasicMotions', 'Coffee', 'Beef'] # Example datasets
                            
                            if dataset_name in datasets_to_plot_cm:
                                print(f"Generating confusion matrix for {model_name} on {dataset_name}...")
                                try:
                                    cm = confusion_matrix(y_test, y_pred)
                                    plt.figure(figsize=(8, 6))
                                    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                                                xticklabels=classes, yticklabels=classes)
                                    plt.xlabel('Predicted Label')
                                    plt.ylabel('True Label')
                                    plt.title(f'Confusion Matrix for {model_name} on {dataset_name}')
                                    
                                    # Save plot
                                    cm_plot_path = os.path.join(results_dir, f'confusion_matrix_{model_name}_{dataset_name}.png')
                                    plt.savefig(cm_plot_path)
                                    print(f"Confusion matrix plot saved to: {cm_plot_path}")
                                    plt.close() # Close figure to free memory
                                except Exception as e_cm:
                                    print(f"Error generating confusion matrix for {model_name} on {dataset_name}: {e_cm}")
                        # ----------------------------------------------

                        # Prepare result dictionary
                        result = {
                            'Dataset': dataset_name,
                            'Model': model_name,
                            'Test Accuracy': test_acc,
                            'Test Loss': test_loss,
                            'Classes': num_classes,
                            'Training Samples': len(X_train),
                            'Testing Samples': len(X_test)
                        }
                        print(f"PyTorch model {model_name} completed on {dataset_name}. Acc: {test_acc:.4f}, Loss: {test_loss:.4f}")

                    except Exception as e_pytorch:
                         print(f"Error processing PyTorch model {model_name} on {dataset_name}: {e_pytorch}")
                         result = {
                            'Dataset': dataset_name,
                            'Model': model_name,
                            'Test Accuracy': np.nan,
                            'Test Loss': np.nan,
                            'Classes': num_classes,
                            'Training Samples': len(X_train),
                            'Testing Samples': len(X_test),
                            'Error': str(e_pytorch)
                         }

                elif model_info['type'] == 'baseline':
                    # --- Baseline Model Processing ---
                    try:
                        runner_func = model_info['runner']
                        config = model_info['config']
                        
                        # Call baseline running function, pass data and config
                        # Ensure baseline function accepts these parameters
                        result = runner_func(
                            X_train=X_train,
                            y_train=y_train,
                            X_test=X_test,
                            y_test=y_test,
                            dataset_name=dataset_name,
                            class_names=classes,
                            **config # Unpack config dictionary as keyword arguments
                        )
                        # Baseline function should return a dictionary similar to the result structure above
                        if 'Test Accuracy' not in result:
                            print(f"Warning: Result returned by baseline {model_name} for {dataset_name} is missing 'Test Accuracy'.")
                            result['Test Accuracy'] = np.nan # Ensure field exists
                        
                        print(f"Baseline model {model_name} completed on {dataset_name}. Acc: {result.get('Test Accuracy', 'N/A'):.4f}")

                    except Exception as e_baseline:
                        print(f"Error running baseline model {model_name} on {dataset_name}: {e_baseline}")
                        result = {
                            'Dataset': dataset_name,
                            'Model': model_name,
                            'Test Accuracy': np.nan,
                            'Test Loss': np.nan,
                            'Classes': num_classes,
                            'Training Samples': len(X_train),
                            'Testing Samples': len(X_test),
                            'Error': str(e_baseline)
                        }
                else:
                    print(f"Warning: Unknown model type '{model_info['type']}' for {model_name}. Skipping.")

                # Add current model/baseline result (if created error entry in either case)
                if result:
                    all_results.append(result)
            
        except Exception as e_dataset:
            print(f"Error processing dataset {dataset_name}: {e_dataset}")
            import traceback
            traceback.print_exc()
            # Can choose to add error entry for all models of this dataset or skip
            continue
    
    # --- Result aggregation and saving ---
    if not all_results:
        print("\nError: No results collected. Please check previous errors.")
        return
        
    results_df = pd.DataFrame(all_results)
    # Can add error column processing or filtering here
    # results_df.fillna({'Error': ''}, inplace=True)
    csv_path = os.path.join(results_dir, 'all_unified_results.csv')
    results_df.to_csv(csv_path, index=False)
    print(f"\nAll results saved to: {csv_path}")
    
    print(f"\n{'='*10} All dataset and model processing completed! {'='*10}")
    print(f"Results saved in directory: {results_dir} (file: {os.path.basename(csv_path)})")

if __name__ == "__main__":
    # plt.rcParams['font.family'] = 'Arial' # Plotting separated, no need to set here
    train_and_evaluate_all_datasets() 