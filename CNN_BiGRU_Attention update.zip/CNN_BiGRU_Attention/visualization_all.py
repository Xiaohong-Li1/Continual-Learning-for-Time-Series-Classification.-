import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
# from sklearn.metrics import confusion_matrix # No longer needed unless confusion matrix plotting is restored later
import os
import argparse
import glob # Import glob
import json # New import for json library

# Define default save directory
save_directory = "plots_from_results"

# ---- Removed unused plotting functions ----
# def plot_training_history(...):
# def plot_confusion_matrix_heatmap(...):
# def plot_ablation_study(...):
# def plot_cl_strategy_comparison(...):

# ---- Keep and modify accuracy comparison function ----
def plot_accuracy_comparison(results_df, save_path=None):
    """Plot accuracy comparison bar chart across datasets and models"""
    if results_df.empty:
        print("Cannot plot: Input data is empty.")
        return
    
    # Filter out rows with invalid accuracy for plotting
    plot_df = results_df.dropna(subset=['Test Accuracy']).copy()
    
    if plot_df.empty:
        print("No valid accuracy results available for plotting.")
        return
        
    # Sort by dataset name for better plot organization (optional)
    plot_df['Dataset'] = pd.Categorical(plot_df['Dataset'], categories=sorted(plot_df['Dataset'].unique()), ordered=True)
    plot_df.sort_values('Dataset', inplace=True)

    num_datasets = plot_df['Dataset'].nunique()
    plt.figure(figsize=(max(15, num_datasets * 1.2), 8))

    sns.barplot(data=plot_df, x='Dataset', y='Test Accuracy', hue='Model', palette='viridis', errorbar=None)
    plt.title('Unified Test Accuracy Comparison Across Models and Datasets')
    plt.xlabel('Dataset')
    plt.ylabel('Test Accuracy')
    plt.xticks(rotation=45, ha='right')
    plt.ylim(0, 1.05)
    plt.legend(title='Model', bbox_to_anchor=(1.02, 1), loc='upper left')
    plt.grid(axis='y', linestyle='--')
    plt.tight_layout()
    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True) # Ensure directory exists
        plt.savefig(save_path)
        print(f"Accuracy comparison plot saved to: {save_path}")
    else:
        plt.show() # Show image if no save path is provided
    plt.close()

def find_latest_results_csv(base_dir='.'):
    """Find the all_unified_results.csv file in the latest results_* directory"""
    results_dirs = glob.glob(os.path.join(base_dir, 'results_*'))
    if not results_dirs:
        print("Error: No 'results_*' folders found in the directory.")
        return None
    
    # Sort by name, assuming the timestamp format guarantees the latest folder is last
    latest_dir = sorted(results_dirs)[-1]
    results_csv_path = os.path.join(latest_dir, 'all_unified_results.csv')
    
    if not os.path.exists(results_csv_path):
        print(f"Error: all_unified_results.csv not found in the latest results directory {latest_dir}.")
        return None
        
    return results_csv_path

def find_latest_cl_results_json(base_dir='.'):
    """Find the cl_strategies_summary.json file in the latest results_* directory"""
    abs_base_dir = os.path.abspath(base_dir)
    results_dirs = glob.glob(os.path.join(abs_base_dir, 'results_*'))
    
    if not results_dirs:
        # Try searching in the parent directory
        parent_dir = os.path.dirname(abs_base_dir)
        results_dirs_parent = glob.glob(os.path.join(parent_dir, 'results_*'))
        if results_dirs_parent:
            results_dirs = results_dirs_parent
            print(f"Found results folders in parent directory {parent_dir}.")
        else:
            print(f"Error: No 'results_*' folders found in directory {abs_base_dir} or its parent directory.")
            return None

    latest_dir = sorted(results_dirs)[-1]
    results_json_path = os.path.join(latest_dir, 'cl_strategies_summary.json')

    if not os.path.exists(results_json_path):
        print(f"Error: cl_strategies_summary.json not found in the latest results directory {latest_dir}.")
        return None

    return results_json_path

def plot_cl_metrics(cl_results_dict, output_plot_dir):
    """Plot continual learning related metrics, such as Backward Transfer (BWT) and final task accuracy heatmap."""
    os.makedirs(output_plot_dir, exist_ok=True)
    
    if not cl_results_dict:
        print("No continual learning results data available for plotting.")
        return

    strategies = list(cl_results_dict.keys())
    
    # --- 1. Backward Transfer (BWT) Comparison Plot ---
    bwt_values = []
    valid_strategies_bwt = []
    # Attempt to find the key name for the BWT metric
    bwt_key_patterns = [
        'StreamForgetting/eval_phase/test_stream_stream',
        'StreamForgetting/eval_phase/test_stream/'
        # Add other key names based on actual Avalanche version and configuration if needed
    ]
    
    for strategy in strategies:
        # Check if results for at least one experience are available (usually at index 0)
        if not cl_results_dict[strategy] or not cl_results_dict[strategy][0]: 
            print(f"Warning: No valid metric results found for strategy {strategy}, skipping BWT plotting.")
            continue
            
        metrics = cl_results_dict[strategy][0] # Assuming all metrics are in the results of the first experience
        found_bwt = False
        for key_pattern in bwt_key_patterns:
            if key_pattern in metrics:
                bwt_values.append(metrics[key_pattern])
                valid_strategies_bwt.append(strategy)
                found_bwt = True
                break # Stop once a matching key is found
        if not found_bwt:
             print(f"Warning: No matching BWT metric key name found in results for strategy {strategy}, skipping BWT plotting.")


    if not valid_strategies_bwt:
        print("No valid Backward Transfer (BWT) data available for plotting.")
    else:
        plt.figure(figsize=(max(6, len(valid_strategies_bwt) * 1.5), 5))
        bars = plt.bar(valid_strategies_bwt, bwt_values, color=['skyblue', 'lightgreen', 'salmon', 'gold', 'lightcoral'][:len(valid_strategies_bwt)])
        plt.ylabel('Backward Transfer (BWT)')
        plt.title('Backward Transfer Comparison Across CL Strategies')
        plt.ylim(min(bwt_values) - 0.05 if min(bwt_values) < 0 else 0, max(bwt_values) + 0.05 if max(bwt_values) > 0 else 0.1)
        plt.axhline(0, color='grey', linestyle='--', linewidth=0.8) # Add 0 line
        for bar in bars:
            yval = bar.get_height()
            plt.text(bar.get_x() + bar.get_width()/2.0, yval, f'{yval:.3f}', ha='center', va='bottom' if yval >= 0 else 'top')
        plt.xticks(rotation=15, ha="right")
        plt.tight_layout()
        bwt_plot_path = os.path.join(output_plot_dir, 'cl_forgetting_comparison.png')
        plt.savefig(bwt_plot_path)
        print(f"Backward Transfer (BWT) comparison plot saved to: {bwt_plot_path}")
        plt.close()
        
    # --- 2. Final Task Accuracy Heatmap ---
    # Collect final accuracy for each strategy on each task
    final_task_accuracies = {}
    task_names = set()
    
    final_acc_key_pattern_prefix = 'Top1_Acc_Exp/eval_phase/test_stream_stream/Exp'

    for strategy in strategies:
         # Check if results for at least one experience are available (usually at index 0)
        if not cl_results_dict[strategy] or not cl_results_dict[strategy][0]: 
            print(f"Warning: No valid metric results found for strategy {strategy}, skipping final task accuracy heatmap plotting.")
            continue
            
        metrics = cl_results_dict[strategy][0] # Assuming all metrics are in the results of the first experience
        strategy_task_acc = {}
        
        # Iterate through all metrics to find keys matching 'Top1_Acc_Exp/eval_phase/test_stream_stream/ExpXXX'
        for key, value in metrics.items():
            if key.startswith(final_acc_key_pattern_prefix):
                # Extract task index and task name from the key name (assuming task names are in the benchmark object)
                # Avalanche metrics key format is usually Top1_Acc_Exp/eval_phase/test_stream_stream/Exp000/task_label
                # or simpler Top1_Acc_Exp/eval_phase/test_stream_stream/Exp000
                # We need task_names_for_plotting from train.py
                # Currently visualization_all.py cannot directly access the benchmark object
                # Temporarily use ExpXXX as column name, or assume a fixed task naming convention
                # Assuming key name is Top1_Acc_Exp/eval_phase/test_stream_stream/ExpXXX
                parts = key.split('/')
                if len(parts) > 1 and parts[-2].startswith('Exp'):
                     task_name_or_idx = parts[-2] # e.g., 'Exp000'
                     strategy_task_acc[task_name_or_idx] = value
                     task_names.add(task_name_or_idx)

        if strategy_task_acc:
             final_task_accuracies[strategy] = strategy_task_acc
        else:
             print(f"Warning: No matching final task accuracy metric key names found in results for strategy {strategy}, skipping its heatmap row.")
             
    if not final_task_accuracies:
        print("No valid final task accuracy data available for plotting.")
        return
        
    # Create DataFrame
    task_names_list = sorted(list(task_names)) # Sort task names
    final_acc_df = pd.DataFrame(final_task_accuracies).T # Transpose to make strategies row index
    final_acc_df = final_acc_df[task_names_list] # Ensure column order is consistent
    
    # Fill missing values (e.g., if a strategy doesn't have results for a task)
    final_acc_df = final_acc_df.fillna(0.0) # Or use NaN, but filling with 0 might be more intuitive for heatmap

    plt.figure(figsize=(max(8, len(task_names_list) * 0.8), max(5, len(strategies) * 0.6)))
    sns.heatmap(final_acc_df, annot=True, fmt='.3f', cmap='viridis', linewidths=.5)
    plt.title('Final Task Accuracy Heatmap After All Tasks')
    plt.xlabel('Task')
    plt.ylabel('Continual Learning Strategy')
    plt.tight_layout()
    final_acc_heatmap_path = os.path.join(output_plot_dir, 'cl_final_accuracy_heatmap.png')
    plt.savefig(final_acc_heatmap_path)
    print(f"Final task accuracy heatmap saved to: {final_acc_heatmap_path}")
    plt.close()

def main():
    parser = argparse.ArgumentParser(description="Generate visualizations from the latest experiment results CSV and CL results JSON.")
    # Remove --results_csv argument
    # parser.add_argument('--results_csv', type=str, required=True, 
    #                     help='Path to the unified results CSV file generated by train_all_datasets.py.')
    parser.add_argument('--output_dir', type=str, default=save_directory,
                        help=f'Directory to save the generated plots (default: {save_directory})')

    args = parser.parse_args()

    # --- Automatically find the latest results file ---
    results_csv_path = find_latest_results_csv(base_dir='.') 
    
    if not results_csv_path:
        print("Cannot proceed with CSV plotting as the results file was not found.")
        # return # Do not return so we can attempt to plot CL data
    else:
        print(f"Automatically found and using the latest CSV results file: {results_csv_path}")
        print(f"Loading results from file: {results_csv_path}")
        try:
            results_df = pd.read_csv(results_csv_path)
            print(f"CSV results loaded successfully, {len(results_df)} records.")
            # Ensure output directory exists
            os.makedirs(args.output_dir, exist_ok=True)
            # Generate accuracy comparison plot (if CSV results loaded successfully)
            comparison_plot_path = os.path.join(args.output_dir, 'unified_accuracy_comparison.png')
            print(f"\nGenerating accuracy comparison plot...")
            plot_accuracy_comparison(results_df, save_path=comparison_plot_path)
        except FileNotFoundError: 
            print(f"Error: Results file {results_csv_path} not found (double check).")
        except Exception as e:
            print(f"Error reading CSV results file or plotting accuracy comparison: {e}")

    # --- Automatically find the latest continual learning results JSON file ---
    cl_results_json_path = find_latest_cl_results_json(base_dir='.')
    
    if not cl_results_json_path:
        print("Cannot proceed with CL plotting as the results file was not found.")
    else:
        print(f"Automatically found and using the latest CL results file: {cl_results_json_path}")
        print(f"Loading CL results from file: {cl_results_json_path}")
        try:
            with open(cl_results_json_path, 'r', encoding='utf-8') as f:
                cl_results_dict = json.load(f)
            print(f"CL results loaded successfully, {len(cl_results_dict)} strategy records.")
            # Ensure output directory exists
            os.makedirs(args.output_dir, exist_ok=True)
            # Generate CL related plots
            print(f"\nGenerating CL related plots...")
            plot_cl_metrics(cl_results_dict, output_plot_dir=args.output_dir)
        except FileNotFoundError:
             print(f"Error: CL results file {cl_results_json_path} not found (double check).")
        except json.JSONDecodeError as e:
            print(f"Error: Error parsing CL results JSON file {cl_results_json_path}: {e}")
        except Exception as e:
            print(f"Error reading CL results JSON file or plotting CL plots: {e}")

    print("\nPlotting completed!")

if __name__ == '__main__':
    # 可以保留字体设置
    # plt.rcParams['font.family'] = 'Arial' 
    main()