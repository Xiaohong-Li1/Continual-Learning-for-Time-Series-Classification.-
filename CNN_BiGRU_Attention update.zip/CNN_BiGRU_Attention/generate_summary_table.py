import pandas as pd
import numpy as np
import os
import glob

def find_latest_results_csv(base_dir='.'):
    """Find all_unified_results.csv file in the latest results_* directory"""
    # Adjusted to handle potential relative paths more robustly
    abs_base_dir = os.path.abspath(base_dir)
    results_dirs = glob.glob(os.path.join(abs_base_dir, 'results_*'))
    
    if not results_dirs:
        # Also try searching one level up
        parent_dir = os.path.dirname(abs_base_dir)
        results_dirs_parent = glob.glob(os.path.join(parent_dir, 'results_*'))
        if results_dirs_parent:
            results_dirs = results_dirs_parent
            print(f"Found results folders in parent directory {parent_dir}.")
        else:
            print(f"Error: No 'results_*' folders found in directory {abs_base_dir} or its parent directory.")
            return None

    # Sort by modification time (or other more reliable timestamp)
    # Assuming directory names themselves contain timestamps and the format guarantees correct sorting
    latest_dir = sorted(results_dirs)[-1]
    results_csv_path = os.path.join(latest_dir, 'all_unified_results.csv')

    if not os.path.exists(results_csv_path):
        print(f"Error: all_unified_results.csv not found in the latest results directory {latest_dir}.")
        return None

    return results_csv_path

def highlight_max(s):
    """Bold the largest numerical value in a Series (LaTeX)"""
    is_max = s == s.max()
    # Format as a string with three decimal places
    formatted_s = s.apply(lambda x: f'{x:.3f}' if pd.notna(x) else 'N/A')
    
    # Apply bolding
    for col, value in formatted_s.items():
         if pd.notna(s[col]) and s[col] == s.max():
             formatted_s[col] = f'\\textbf{{{value}}}'
             
    return formatted_s

def generate_latex_summary_table():
    # 1. Find the latest results file
    results_csv_path = find_latest_results_csv()

    if not results_csv_path:
        print("Cannot generate table as results file was not found.")
        return

    print(f"Loading results file: {results_csv_path}")
    try:
        # 2. Load data
        results_df = pd.read_csv(results_csv_path)
    except FileNotFoundError:
         print(f"Error: Results file {results_csv_path} not found") # Double check, just in case
         return
    except Exception as e:
         print(f"Error reading results file: {e}")
         return
         
    # Filter out rows with no accuracy (e.g., ARIMA skipped for too short sequences)
    results_df_filtered = results_df.dropna(subset=['Test Accuracy']).copy()

    if results_df_filtered.empty:
        print("No rows with valid accuracy data after filtering, cannot generate table.")
        return
        
    # 3. Create pivot table
    # Use aggfunc='first' because there should only be one row of results for each Dataset-Model pair
    pivot_table = results_df_filtered.pivot_table(
        index='Dataset',
        columns='Model',
        values='Test Accuracy',
        aggfunc='first' 
    )
    
    # Sort column names so the model order in the table is fixed and reasonable (e.g., baselines first, then models)
    # Adjust the order here based on your paper's requirements
    desired_model_order = ['ARIMA', 'RandomForest', 'LSTM', 'GRU', 'CNN_BiGRU']
    # Filter out columns not present in pivot_table
    ordered_columns = [model for model in desired_model_order if model in pivot_table.columns]
    # Add columns present in pivot_table but not in desired_model_order (if needed)
    other_columns = [model for model in pivot_table.columns if model not in desired_model_order]
    pivot_table = pivot_table[ordered_columns + other_columns]

    # 4. Identify and bold the best performance (apply highlight_max row-wise)
    # Apply needs to be applied to a subset of the DataFrame containing only numerical values
    styled_df = pivot_table.apply(highlight_max, axis=1)
    
    # 5. Generate LaTeX code
    # Use floatfmt=None to avoid to_latex reformatting values again
    latex_string = styled_df.to_latex(
        escape=False, 
        na_rep='N/A', # Handle NaN in the original pivot_table
        column_format='l' + 'c' * len(styled_df.columns), # Dataset name left-aligned, others centered
        caption='Comparison of Test Accuracy of Different Models on Various UCR Datasets', # Table caption
        label='tab:accuracy_comparison' # LaTeX label
    )

    print("\n" + "="*20 + " LaTeX Summary Table " + "="*20)
    print(latex_string)
    print("="*20 + " End LaTeX Summary Table " + "="*20 + "\n")

if __name__ == '__main__':
    generate_latex_summary_table() 