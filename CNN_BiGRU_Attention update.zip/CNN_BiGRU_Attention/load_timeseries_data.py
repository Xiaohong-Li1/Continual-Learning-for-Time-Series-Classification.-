# load_timeseries_data.py
import numpy as np
import os
from sklearn.preprocessing import StandardScaler, LabelEncoder
import torch
from torch.utils.data import TensorDataset, DataLoader
import arff

def preprocess_arff(content):
    lines = content.split('\n')
    processed_lines = []
    in_data_section = False
    current_data_line = []
    
    for line in lines:
        line = line.strip()
        if not line or line.startswith('%'):
            continue
            
        if line.lower().startswith('@data'):
            in_data_section = True
            processed_lines.append(line)
            continue
            
        if in_data_section:
            # Process data lines
            if line.startswith("'") and line.endswith("'"):
                # Handle multi-line data
                values = line.strip("'").split(',')
                # Remove all newlines and extra spaces
                values = [v.strip().replace('\n', '') for v in values]
                # Remove 'n' character from the last value
                if values and values[-1].endswith('n'):
                    values[-1] = values[-1][:-1]
                # Remove 'Standing' character from the last value
                if values and values[-1].endswith('Standing'):
                    values[-1] = values[-1][:-8]
                # Remove 'Standing\n' character from the last value
                if values and values[-1].endswith('Standing\n'):
                    values[-1] = values[-1][:-9]
                processed_line = ','.join(values)
                processed_lines.append(processed_line)
            else:
                # Handle regular data lines
                line = line.replace('\n', '').strip()
                if line:  # Only add non-empty lines
                    # Remove 'n' character from the end of the line
                    if line.endswith('n'):
                        line = line[:-1]
                    # Remove 'Standing' character from the end of the line
                    if line.endswith('Standing'):
                        line = line[:-8]
                    # Remove 'Standing\n' character from the end of the line
                    if line.endswith('Standing\n'):
                        line = line[:-9]
                    processed_lines.append(line)
        else:
            # Process attribute definitions
            if not line.lower().startswith('@attribute') or 'relational' not in line.lower():
                processed_lines.append(line)
    
    return '\n'.join(processed_lines)

def process_data(data):
    """
    Helper function to process a single dataset.
    """
    features = []
    labels = []
    first_row_length = None
    
    for row in data['data']:
        # Initialize feature list
        row_features = []
        
        # Process features
        for i, value in enumerate(row[:-1]):  # All values except the last one (label)
            if isinstance(value, str):
                if value.startswith("'") and value.endswith("'"):
                    # Handle relational data
                    values = value.strip("'").split(',')
                    # Ensure all values are valid numbers
                    valid_values = []
                    for v in values:
                        try:
                            if v != 'NaN' and v != '?' and v is not None:
                                valid_values.append(float(v))
                            else:
                                valid_values.append(np.nan)
                        except ValueError:
                            valid_values.append(np.nan)
                    row_features.extend(valid_values)
                else:
                    # Handle other string type numeric values
                    try:
                        row_features.append(float(value) if value != 'NaN' and value != '?' else np.nan)
                    except ValueError:
                        row_features.append(np.nan)
            else:
                # Handle numeric types
                row_features.append(float(value) if value is not None else np.nan)
        
        # Check feature vector length
        if first_row_length is None:
            first_row_length = len(row_features)
            features.append(row_features)
            labels.append(row[-1])
        elif len(row_features) == first_row_length:
            features.append(row_features)
            labels.append(row[-1])
        else:
            print(f"Warning: Skipping sample with mismatched length (expected: {first_row_length}, actual: {len(row_features)})")
    
    return np.array(features), np.array(labels)

def load_special_dataset(dataset_name, data_dir='dataset'):
    """
    Specifically handles datasets with special formats (AtrialFibrillation and BasicMotions)
    """
    dataset_path = os.path.join(data_dir, dataset_name)
    
    def read_special_arff(file_path):
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Find the start of the data section
        data_start = content.find('@data')
        if data_start == -1:
            raise Exception("Data section not found")
        
        # Separate attribute and data sections
        attributes = content[:data_start].strip()
        data_section = content[data_start:].strip()
        
        # Process data section
        data_lines = data_section.split('\n')[1:]  # Skip @data line
        processed_data = []
        current_row = []
        
        for line in data_lines:
            line = line.strip()
            if not line:
                continue
                
            # Handle multi-line data
            if line.startswith("'") and line.endswith("'"):
                if current_row:  # If the current row is not empty, process it first
                    processed_data.append(current_row)
                    current_row = []
                values = line.strip("'").split(',')
                # Remove all newlines and extra spaces
                values = [v.strip().replace('\n', '') for v in values]
                processed_data.append(values)
            else:
                # Handle regular data lines
                values = line.split(',')
                # Check if it's a new data line (by checking the number of values)
                if len(values) > 1:  # If it contains more than one value, it's a new line
                    if current_row:  # If the current row is not empty, process it first
                        processed_data.append(current_row)
                    current_row = values
                else:  # If there's only one value, it might be a continuation of the previous line
                    current_row.extend(values)
        
        # Process the last line
        if current_row:
            processed_data.append(current_row)
        
        return processed_data
    
    try:
        # Read train and test sets
        train_file = os.path.join(dataset_path, f'{dataset_name}_TRAIN.arff')
        test_file = os.path.join(dataset_path, f'{dataset_name}_TEST.arff')
        
        train_data = read_special_arff(train_file)
        test_data = read_special_arff(test_file)
        
        # Process data
        def process_special_data(data):
            features = []
            labels = []
            
            for row in data:
                # The last value is the label
                label = row[-1]
                # The rest are features
                feature_values = []
                for v in row[:-1]:
                    # Remove quotes and leading/trailing spaces
                    v = v.strip().strip("'")
                    
                    # Handle newlines
                    if '\n' in v:
                        # Take only the part before the newline
                        parts = v.split('\n')
                        v = parts[0].strip()  # Take the first part and strip spaces again
                        # Optional: warn or log the split values parts[1:] if needed
                    
                    # Handle commas
                    if ',' in v:
                        v = v.split(',')[0].strip()
                    
                    # Handle spaces
                    if ' ' in v:
                        v = v.split(' ')[0].strip()
                    
                    try:
                        # Check for empty string or invalid values
                        if v == '' or v == 'NaN' or v == '?':
                            feature_values.append(0.0)
                            print(f"Warning: Encountered empty or invalid value '{v}', replacing with 0.0")
                        else:
                            # Try converting to float
                            try:
                                feature_values.append(float(v))
                            except ValueError:
                                # If conversion fails, try extracting numbers using regex
                                import re
                                numbers = re.findall(r'-?\d+\.?\d*', v)
                                if numbers:
                                    feature_values.append(float(numbers[0]))
                                else:
                                    print(f"Warning: Could not extract number from value '{v}', replacing with 0.0")
                                    feature_values.append(0.0)
                    except Exception as e:
                        print(f"Warning: Error processing value '{v}': {str(e)}, replacing with 0.0")
                        feature_values.append(0.0)
                
                features.append(feature_values)
                labels.append(label)
            
            return np.array(features), np.array(labels)
        
        # Process train and test sets
        X_train, y_train = process_special_data(train_data)
        X_test, y_test = process_special_data(test_data)
        
        # Convert string labels to numbers using LabelEncoder
        le = LabelEncoder()
        le.fit(np.concatenate([y_train, y_test]))
        y_train = le.transform(y_train)
        y_test = le.transform(y_test)
        
        return X_train, y_train, X_test, y_test, le.classes_
        
    except Exception as e:
        print(f"Error loading dataset {dataset_name}: {str(e)}")
        raise

def load_ucr_dataset(dataset_name, data_dir='dataset'):
    """
    Loads a UCR dataset.
    Args:
        dataset_name: The name of the dataset.
        data_dir: The directory where datasets are stored.
    Returns:
        X_train: Training data.
        y_train: Training labels.
        X_test: Testing data.
        y_test: Testing labels.
        classes: The list of class names.
    """
    # Handle special datasets
    if dataset_name in ['AtrialFibrillation', 'BasicMotions']:
        return load_special_dataset(dataset_name, data_dir)
    
    # Construct dataset path
    dataset_path = os.path.join(data_dir, dataset_name)
    
    try:
        # Try loading the file with different encodings
        encodings = ['utf-8', 'latin-1']
        train_data = None
        test_data = None
        
        for encoding in encodings:
            try:
                train_file = os.path.join(dataset_path, f'{dataset_name}_TRAIN.arff')
                test_file = os.path.join(dataset_path, f'{dataset_name}_TEST.arff')
                
                # Read file content
                with open(train_file, 'r', encoding=encoding) as f:
                    train_content = f.read()
                with open(test_file, 'r', encoding=encoding) as f:
                    test_content = f.read()
                
                # Process file content
                train_content = preprocess_arff(train_content)
                test_content = preprocess_arff(test_content)
                
                # Load processed content
                train_data = arff.loads(train_content)
                test_data = arff.loads(test_content)
                break
            except UnicodeDecodeError:
                continue
        
        if train_data is None or test_data is None:
            raise Exception(f"Could not read dataset {dataset_name} using supported encodings.")
        
        # Process train and test sets
        X_train, y_train = process_data(train_data)
        X_test, y_test = process_data(test_data)
        
        # Ensure all feature vector lengths are consistent
        if X_train.shape[1] != X_test.shape[1]:
            raise Exception(f"Train and test set feature dimensions mismatch: {X_train.shape[1]} vs {X_test.shape[1]}")
        
        if dataset_name == 'BeetleFly':
            print(f"[DEBUG] BeetleFly - Before LabelEncoder - y_train unique: {np.unique(y_train)}")
            print(f"[DEBUG] BeetleFly - Before LabelEncoder - y_test unique: {np.unique(y_test)}")

        # Convert string labels to numbers using LabelEncoder
        le = LabelEncoder()
        le.fit(np.concatenate([y_train, y_test]))
        y_train = le.transform(y_train)
        y_test = le.transform(y_test)
        
        if dataset_name == 'BeetleFly':
            print(f"[DEBUG] BeetleFly - After LabelEncoder - y_train unique: {np.unique(y_train)}")
            print(f"[DEBUG] BeetleFly - After LabelEncoder - y_test unique: {np.unique(y_test)}")
            print(f"[DEBUG] BeetleFly - LabelEncoder classes: {le.classes_}")

        # Impute missing values
        X_train = np.nan_to_num(X_train, nan=0.0)
        X_test = np.nan_to_num(X_test, nan=0.0)
        
        return X_train, y_train, X_test, y_test, le.classes_
        
    except Exception as e:
        print(f"Error loading dataset {dataset_name}: {str(e)}")
        raise

def preprocess_data(X_train, X_test):
    """Data preprocessing"""
    # Standardization
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Convert to PyTorch tensors
    X_train_tensor = torch.FloatTensor(X_train_scaled)
    X_test_tensor = torch.FloatTensor(X_test_scaled)
    
    return X_train_tensor, X_test_tensor

def create_dataloaders(X_train, X_test, y_train, y_test, batch_size=32):
    """Create data loaders"""
    # Convert to PyTorch tensors
    y_train_tensor = torch.LongTensor(y_train)
    y_test_tensor = torch.LongTensor(y_test)
    
    # Create datasets
    train_dataset = TensorDataset(X_train, y_train_tensor)
    test_dataset = TensorDataset(X_test, y_test_tensor)
    
    # Create data loaders
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
    
    return train_loader, test_loader

def main():
    """Main function to test data loading functionality"""
    # Get the directory of the current file
    current_dir = os.path.dirname(os.path.abspath(__file__))
    dataset_dir = os.path.join(current_dir, 'dataset')
    
    # Get all dataset directories under the dataset directory
    dataset_names = [d for d in os.listdir(dataset_dir) if os.path.isdir(os.path.join(dataset_dir, d))]
    
    for dataset_name in dataset_names:
        try:
            X_train, y_train, X_test, y_test, classes = load_ucr_dataset(dataset_name)
            print(f"\nDataset {dataset_name} loaded successfully:")
            print(f"Train set shape: {X_train.shape}")
            print(f"Test set shape: {X_test.shape}")
            print(f"Train set labels: {np.unique(y_train)}")
            print(f"Test set labels: {np.unique(y_test)}")
        except Exception as e:
            print(f"Loading dataset {dataset_name} failed: {str(e)}")

if __name__ == "__main__":
    main()