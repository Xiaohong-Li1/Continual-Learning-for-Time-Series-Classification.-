import os
import numpy as np
import torch
import matplotlib.pyplot as plt
from load_timeseries_data import load_ucr_dataset
from model import CNN_BiGRU_Attention, StandardLSTM, StandardGRU
from train import train_model, evaluate_model
import seaborn as sns
from sklearn.metrics import confusion_matrix, classification_report
import pandas as pd
from datetime import datetime

# 导入基线运行函数
from baseline_arima_features import run_arima_baseline_for_dataset
from baseline_random_forest import run_rf_baseline_for_dataset

def train_and_evaluate_all_datasets():
    """Train and evaluate all datasets for PyTorch models and baselines, save results to CSV."""
    # List of datasets
    datasets = [
        'ArrowHead', 'AtrialFibrillation', 'BasicMotions', 'Beef',
        'BeetleFly', 'BirdChicken', 'BME', 'Coffee',
        'DodgerLoopDay', 'DodgerLoopGame'
        # 可以根据需要添加或删除数据集
    ]
    
    # 配置所有模型和基线
    # type: 'pytorch' or 'baseline'
    # runner: 对于 baseline，是直接调用的函数
    # config: 包含实例化或运行所需的参数
    model_configs = {
        'CNN_BiGRU': {
            'type': 'pytorch', 
            'class': CNN_BiGRU_Attention, 
            'config': {'num_classes_param': 'num_classes_initial'}
        },
        'LSTM': {
            'type': 'pytorch', 
            'class': StandardLSTM, 
            'config': {'num_classes_param': 'num_classes', 'hidden_size': 128, 'num_layers': 2}
        },
        'GRU': {
            'type': 'pytorch', 
            'class': StandardGRU, 
            'config': {'num_classes_param': 'num_classes', 'hidden_size': 128, 'num_layers': 2}
        },
        'ARIMA': {
            'type': 'baseline', 
            'runner': run_arima_baseline_for_dataset, 
            'config': {'arima_order': (1,1,0)} # 可以调整ARIMA阶数
        },
        'RandomForest': {
            'type': 'baseline', 
            'runner': run_rf_baseline_for_dataset, 
            'config': {'n_estimators': 100} # 可以调整RF的估计器数量
        }
    }
    
    # Create results directory
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    results_dir = f'results_{timestamp}'
    os.makedirs(results_dir, exist_ok=True)
    print(f"结果将保存在: {results_dir}")
    
    all_results = []
    
    for dataset_name in datasets:
        print(f"\n{'='*10} 处理数据集: {dataset_name} {'='*10}")
        
        try:
            # 加载数据 (所有模型使用相同的数据加载)
            X_train, y_train, X_test, y_test, classes = load_ucr_dataset(dataset_name)
            print(f"数据集 {dataset_name} 加载成功。类别: {classes}")
            num_classes = len(classes)
            sequence_length = X_train.shape[-1] # 假设最后一维是序列长度
            
            # 训练和评估每个模型/基线
            for model_name, model_info in model_configs.items():
                print(f"\n--- 开始处理模型: {model_name} --- ")
                result = None # 初始化当前模型的结果

                if model_info['type'] == 'pytorch':
                    # --- PyTorch 模型处理 --- 
                    try:
                        model_class = model_info['class']
                        config = model_info['config']
                        num_classes_param = config['num_classes_param']

                        model_kwargs = {
                            'input_channels': 1, # 假设UCR数据加载后是单通道
                            num_classes_param: num_classes
                        }
                        # 添加模型特定参数
                        if model_name == 'LSTM' or model_name == 'GRU':
                            model_kwargs['hidden_size'] = config.get('hidden_size', 128)
                            model_kwargs['num_layers'] = config.get('num_layers', 2)
                        elif model_name == 'CNN_BiGRU':
                            model_kwargs['sequence_length'] = sequence_length
                            # 可以从 config 中获取更多 CNN_BiGRU 的超参数

                        model = model_class(**model_kwargs)
                        
                        # 训练 (使用 train.py 中的函数)
                        # 注意：train_model 可能需要修改以处理不同的模型输入期望和返回值
                        # 这里假设 train_model 可以直接用
                        history = train_model(
                            model=model,
                            X_train=X_train,
                            y_train=y_train,
                            X_val=X_test, # 使用测试集作为验证集用于绘图
                            y_val=y_test,
                            batch_size=32,
                            num_epochs=100, # 可能需要调整 epoch
                            learning_rate=0.001
                        )
                        
                        # 评估 (使用 train.py 中的函数)
                        test_loss, test_acc, y_pred = evaluate_model(
                            model=model,
                            X_test=X_test,
                            y_test=y_test
                        )
                        
                        # 准备结果字典
                        result = {
                            'Dataset': dataset_name,
                            'Model': model_name,
                            'Test Accuracy': test_acc,
                            'Test Loss': test_loss,
                            'Classes': num_classes,
                            'Training Samples': len(X_train),
                            'Testing Samples': len(X_test)
                        }
                        print(f"PyTorch 模型 {model_name} 在 {dataset_name} 上完成。 Acc: {test_acc:.4f}, Loss: {test_loss:.4f}")

                    except Exception as e_pytorch:
                         print(f"处理 PyTorch 模型 {model_name} 在 {dataset_name} 时出错: {e_pytorch}")
                         result = {
                            'Dataset': dataset_name,
                            'Model': model_name,
                            'Test Accuracy': np.nan,
                            'Test Loss': np.nan,
                            'Classes': num_classes,
                            'Training Samples': len(X_train),
                            'Testing Samples': len(X_test),
                            'Error': str(e_pytorch)
                         }

                elif model_info['type'] == 'baseline':
                    # --- 基线模型处理 --- 
                    try:
                        runner_func = model_info['runner']
                        config = model_info['config']
                        
                        # 调用基线运行函数，传递数据和配置
                        # 确保基线函数接收这些参数
                        result = runner_func(
                            X_train=X_train,
                            y_train=y_train,
                            X_test=X_test,
                            y_test=y_test,
                            dataset_name=dataset_name,
                            class_names=classes,
                            **config # 将config字典解包为关键字参数
                        )
                        # 基线函数应该返回一个与上面 result 结构类似的字典
                        if 'Test Accuracy' not in result:
                            print(f"警告: 基线 {model_name} for {dataset_name} 返回的结果缺少 'Test Accuracy'。")
                            result['Test Accuracy'] = np.nan # 确保字段存在
                        
                        print(f"基线模型 {model_name} 在 {dataset_name} 上完成。 Acc: {result.get('Test Accuracy', 'N/A'):.4f}")

                    except Exception as e_baseline:
                        print(f"运行基线模型 {model_name} 在 {dataset_name} 时出错: {e_baseline}")
                        result = {
                            'Dataset': dataset_name,
                            'Model': model_name,
                            'Test Accuracy': np.nan,
                            'Test Loss': np.nan,
                            'Classes': num_classes,
                            'Training Samples': len(X_train),
                            'Testing Samples': len(X_test),
                            'Error': str(e_baseline)
                        }
                else:
                    print(f"警告: 未知的模型类型 '{model_info['type']}' for {model_name}. 跳过。")

                # 添加当前模型/基线的结果 (如果成功或失败时创建了错误条目)
                if result:
                    all_results.append(result)
            
        except Exception as e_dataset:
            print(f"处理数据集 {dataset_name} 时发生主错误: {e_dataset}")
            import traceback
            traceback.print_exc()
            # 可以选择为该数据集的所有模型添加错误条目，或仅跳过
            continue
    
    # --- 结果汇总和保存 --- 
    if not all_results:
        print("\n错误：未能收集到任何结果。请检查之前的错误。")
        return
        
    results_df = pd.DataFrame(all_results)
    # 可以在这里添加错误列的处理或筛选
    # results_df.fillna({'Error': ''}, inplace=True)
    csv_path = os.path.join(results_dir, 'all_unified_results.csv')
    results_df.to_csv(csv_path, index=False)
    print(f"\n所有结果已保存到: {csv_path}")
    
    print(f"\n{'='*10} 所有数据集和模型处理完成! {'='*10}")
    print(f"结果保存在目录: {results_dir} (文件: {os.path.basename(csv_path)}) ")

if __name__ == "__main__":
    # plt.rcParams['font.family'] = 'Arial' # 绘图已分离，这里不需要设置
    train_and_evaluate_all_datasets() 