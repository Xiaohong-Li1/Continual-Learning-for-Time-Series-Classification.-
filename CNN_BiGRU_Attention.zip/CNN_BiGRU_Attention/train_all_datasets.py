import os
import numpy as np
import torch
import matplotlib.pyplot as plt
from load_timeseries_data import load_ucr_dataset
from model import CNN_BiGRU_Attention, CNN, MCNN, FCN, ResNet
from train import train_model, evaluate_model
import seaborn as sns
from sklearn.metrics import confusion_matrix, classification_report
import pandas as pd
from datetime import datetime

def plot_training_history(history, dataset_name, model_name, save_dir='results'):
    """Plot training history"""
    plt.figure(figsize=(12, 4))
    
    # Plot loss
    plt.subplot(1, 2, 1)
    plt.plot(history['train_loss'], label='Train Loss')
    plt.plot(history['val_loss'], label='Validation Loss')
    plt.title(f'{dataset_name} - {model_name} - Loss Curves')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    
    # Plot accuracy
    plt.subplot(1, 2, 2)
    plt.plot(history['train_acc'], label='Train Accuracy')
    plt.plot(history['val_acc'], label='Validation Accuracy')
    plt.title(f'{dataset_name} - {model_name} - Accuracy Curves')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.legend()
    
    # Save image
    os.makedirs(save_dir, exist_ok=True)
    plt.savefig(os.path.join(save_dir, f'{dataset_name}_{model_name}_training_history.png'))
    plt.close()

def plot_confusion_matrix(y_true, y_pred, dataset_name, model_name, save_dir='results'):
    """Plot confusion matrix"""
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
    plt.title(f'{dataset_name} - {model_name} - Confusion Matrix')
    plt.xlabel('Predicted Label')
    plt.ylabel('True Label')
    
    # Save image
    os.makedirs(save_dir, exist_ok=True)
    plt.savefig(os.path.join(save_dir, f'{dataset_name}_{model_name}_confusion_matrix.png'))
    plt.close()

def train_and_evaluate_all_datasets():
    """Train and evaluate all datasets"""
    # List of datasets
    datasets = [
        'ArrowHead', 'AtrialFibrillation', 'BasicMotions', 'Beef',
        'BeetleFly', 'BirdChicken', 'BME', 'Coffee',
        'DodgerLoopDay', 'DodgerLoopGame'
    ]
    
    # List of models to evaluate
    models = {
        'CNN_BiGRU': (CNN_BiGRU_Attention, 'num_classes_initial'),
        'CNN': (CNN, 'num_classes'),
        'MCNN': (MCNN, 'num_classes'),
        'FCN': (FCN, 'num_classes'),
        'ResNet': (ResNet, 'num_classes')
    }
    
    # Create results directory
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    results_dir = f'results_{timestamp}'
    os.makedirs(results_dir, exist_ok=True)
    
    # Store all results
    all_results = []
    
    for dataset_name in datasets:
        print(f"\nProcessing dataset: {dataset_name}")
        
        try:
            # Load data
            X_train, y_train, X_test, y_test, classes = load_ucr_dataset(dataset_name)
            
            # Set model parameters
            input_size = X_train.shape[1]
            num_classes = len(classes)
            sequence_length = X_train.shape[1]  # sequence length equals feature dimension
            
            # Train and evaluate each model
            for model_name, (model_class, num_classes_param) in models.items():
                print(f"\nTraining {model_name} on {dataset_name}")
                
                # Create model
                model_kwargs = {
                    'input_channels': 1,
                    'sequence_length': sequence_length,
                    num_classes_param: num_classes
                }
                model = model_class(**model_kwargs)
                
                # Train model
                history = train_model(
                    model=model,
                    X_train=X_train,
                    y_train=y_train,
                    X_val=X_test,  # use test set as validation set
                    y_val=y_test,
                    batch_size=32,
                    num_epochs=100,
                    learning_rate=0.001
                )
                
                # Evaluate model
                test_loss, test_acc, y_pred = evaluate_model(
                    model=model,
                    X_test=X_test,
                    y_test=y_test
                )
                
                # Plot training history
                plot_training_history(history, dataset_name, model_name, save_dir=results_dir)
                
                # Plot confusion matrix
                plot_confusion_matrix(y_test, y_pred, dataset_name, model_name, save_dir=results_dir)
                
                # Generate classification report
                report = classification_report(y_test, y_pred, output_dict=True)
                
                # Save results
                result = {
                    'Dataset': dataset_name,
                    'Model': model_name,
                    'Test Accuracy': test_acc,
                    'Test Loss': test_loss,
                    'Classes': len(classes),
                    'Training Samples': len(X_train),
                    'Testing Samples': len(X_test)
                }
                all_results.append(result)
                
                print(f"{model_name} on {dataset_name} completed")
                print(f"Test Accuracy: {test_acc:.4f}")
                print(f"Test Loss: {test_loss:.4f}")
            
        except Exception as e:
            print(f"Error processing dataset {dataset_name}: {str(e)}")
            continue
    
    # Save all results to CSV file
    results_df = pd.DataFrame(all_results)
    results_df.to_csv(os.path.join(results_dir, 'all_results.csv'), index=False)
    
    # Only plot if we have results
    if not results_df.empty:
        # Plot accuracy comparison for all models and datasets
        plt.figure(figsize=(15, 8))
        sns.barplot(data=results_df, x='Dataset', y='Test Accuracy', hue='Model')
        plt.title('Test Accuracy Comparison Across All Models and Datasets')
        plt.xticks(rotation=45)
        plt.legend(title='Model', bbox_to_anchor=(1.05, 1), loc='upper left')
        plt.tight_layout()
        plt.savefig(os.path.join(results_dir, 'accuracy_comparison.png'))
        plt.close()
    else:
        print("No results to plot - all models failed to train")
    
    print("\nAll datasets and models processing completed!")
    print(f"Results saved to directory: {results_dir}")

if __name__ == "__main__":
    # Set font for matplotlib
    plt.rcParams['font.family'] = 'Arial'
    train_and_evaluate_all_datasets() 