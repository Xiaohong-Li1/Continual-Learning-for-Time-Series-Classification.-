import torch
import numpy as np
import matplotlib.pyplot as plt
import argparse
import os

from model import CNN_BiGRU_Attention # 确保 model.py 在PYTHONPATH中或同一目录
from load_timeseries_data import load_ucr_dataset # 确保 load_timeseries_data.py 可访问

def visualize_attention(model_path, dataset_name, data_dir, sample_idx=0, 
                        # 模型实例化参数 (应与训练时使用的参数匹配)
                        # 这些可以作为argparse参数，或从配置文件加载
                        # 为了演示，我们可能需要根据数据集自动获取 input_channels 和 sequence_length
                        # num_classes_initial 对于仅推理和权重提取可能不那么重要，但仍需提供
                        num_multiscale_paths_model=4, # 示例，应与训练时所用一致
                        final_dropout_rate_model=0.4, # 示例
                        gru_hidden_size_model=128,    # 示例
                        num_gru_layers_model=2,       # 示例
                        adaptive_pool_output_size_model=50 # 示例
                        ):
    """
    加载模型和数据，提取并可视化注意力权重。
    """
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    # 1. 加载数据
    print(f"Loading dataset: {dataset_name} from {data_dir}")
    try:
        X_train, y_train, X_test, y_test, classes = load_ucr_dataset(dataset_name, data_dir=data_dir)
    except Exception as e:
        print(f"Error loading dataset {dataset_name}: {e}")
        return

    if sample_idx >= len(X_test):
        print(f"Error: sample_idx {sample_idx} is out of bounds for X_test with length {len(X_test)}.")
        return

    sample_np = X_test[sample_idx]
    true_label = y_test[sample_idx]
    print(f"Selected sample {sample_idx} from {dataset_name}. True label: {classes[true_label]}")

    # 预处理样本：确保是 (1, num_features, sequence_length)
    if sample_np.ndim == 1: # (sequence_length,) -> (1, 1, sequence_length)
        sample_np = np.expand_dims(sample_np, axis=0) # (1, sequence_length)
        sample_np = np.expand_dims(sample_np, axis=0) # (1, 1, sequence_length)
    elif sample_np.ndim == 2: # (num_features, sequence_length) -> (1, num_features, sequence_length)
        sample_np = np.expand_dims(sample_np, axis=0) 
    
    sample = torch.FloatTensor(sample_np).to(device)
    print(f"Sample shape for model: {sample.shape}")

    input_channels = sample.shape[1]
    sequence_length = sample.shape[2] 
    # num_classes_initial 对于权重提取不是直接使用，但模型需要它进行初始化
    # 我们可以从训练好的模型中获取，或者提供一个占位符（比如数据集中实际的类别数）
    num_classes_initial_placeholder = len(classes) 

    # 2. 加载模型
    print(f"Loading model from: {model_path}")
    # 实例化模型时使用与训练时相同的参数
    model = CNN_BiGRU_Attention(
        input_channels=input_channels, 
        sequence_length=sequence_length, # 注意：此参数在CNN_BiGRU_Attention模型中主要用于推断FC层大小（如果存在），或作为参考
                                         # 我们的模型通过AdaptiveAvgPool1d处理序列长度变化
        num_classes_initial=num_classes_initial_placeholder, # 可能需要根据实际情况调整或从模型配置中读取
        num_multiscale_paths=num_multiscale_paths_model,
        final_dropout_rate=final_dropout_rate_model,
        gru_hidden_size=gru_hidden_size_model,
        num_gru_layers=num_gru_layers_model,
        adaptive_pool_output_size=adaptive_pool_output_size_model
    ).to(device)

    try:
        # 加载状态字典。确保 map_location 适应当前设备。
        model.load_state_dict(torch.load(model_path, map_location=device))
        model.eval() # 设置为评估模式
        print("Model loaded successfully.")
    except Exception as e:
        print(f"Error loading model state_dict: {e}")
        return

    # 3. 提取注意力权重
    print("Extracting attention weights...")
    # 假设我们对第一个任务的注意力感兴趣（如果模型是多任务训练的）
    # 对于单任务模型或预训练在特定任务上的模型，task_labels 可以是固定的，例如0
    mock_task_labels = torch.tensor([0], device=device, dtype=torch.long) 

    with torch.no_grad():
        output, channel_weights, spatial_weights = model(sample, task_labels=mock_task_labels, return_attention_weights=True)
    
    _, predicted_label_idx = torch.max(output, 1)
    predicted_label = classes[predicted_label_idx.item()]
    print(f"Model prediction: {predicted_label}")

    if channel_weights is None or spatial_weights is None:
        print("Error: Could not retrieve attention weights. Ensure model.forward supports it and return_attention_weights=True was effective.")
        return

    print(f"Channel weights shape: {channel_weights.shape}") # Expected: (batch, channels_att, 1) or (batch, channels_att)
    print(f"Spatial weights shape: {spatial_weights.shape}") # Expected: (batch, 1, seq_len_att)

    # 4. 可视化
    # 将权重移到CPU并转为NumPy
    channel_weights_np = channel_weights.squeeze().cpu().numpy()
    spatial_weights_np = spatial_weights.squeeze().cpu().numpy()
    original_timeseries = sample_np.squeeze()

    # 确保 spatial_weights_np 的长度与注意力模块看到的序列长度一致
    # 这可能短于原始序列长度，取决于模型中的卷积和池化层
    # CNN_BiGRU_Attention 的 AttentionBlock 应用在 multi_scale 模块的输出之后
    # MultiScaleFeatureExtraction -> StandardConvLayer -> MaxPool1d (stride 2)
    # InitialConv -> MaxPool1d (stride 2)
    # 所以空间注意力的长度会比原始序列短。我们需要找到这个长度或调整绘图。
    # 暂定：直接绘制，横轴可能不完全对齐原始序列，但显示权重分布。

    num_plots = 2 + (input_channels if input_channels > 1 else 0) # 原始序列, 空间注意力, [每个通道的原始序列+通道注意力权重]
    fig_height = 5 * num_plots
    # fig, axs = plt.subplots(num_plots, 1, figsize=(15, fig_height), sharex=False)
    # current_ax = 0

    plt.figure(figsize=(15, 5 + 3 * (1 if input_channels == 1 else input_channels) + 3))

    # 图1: 原始时间序列
    ax1 = plt.subplot(2 + (1 if input_channels == 1 else input_channels), 1, 1)
    if original_timeseries.ndim > 1:
        # 多变量时间序列，绘制第一个通道或所有通道叠加
        for i in range(original_timeseries.shape[0]):
            ax1.plot(original_timeseries[i, :], label=f'Channel {i+1}')
        ax1.legend()
    else:
        ax1.plot(original_timeseries, label='Original Time Series')
    ax1.set_title(f'Original Sample from {dataset_name} (Idx: {sample_idx}, True: {classes[true_label]}, Pred: {predicted_label})')
    ax1.set_xlabel('Time Step')
    ax1.set_ylabel('Value')
    
    # 图2: 空间注意力权重
    ax2 = plt.subplot(2 + (1 if input_channels == 1 else input_channels), 1, 2)
    # spatial_weights_np 应该是1D数组 (seq_len_att,)
    # 如果 spatial_weights_np 的长度与 original_timeseries 不匹配，横轴代表注意力模块的输入序列
    # 我们可以尝试将其插值或拉伸以匹配原始长度，或直接绘制
    # 为简单起见，直接绘制，并使用其自身的长度作为x轴
    time_steps_att = np.arange(len(spatial_weights_np))
    ax2.plot(time_steps_att, spatial_weights_np, color='red', label='Spatial Attention Weights')
    # ax2.bar(time_steps_att, spatial_weights_np, color='red', alpha=0.7, width=1.0, label='Spatial Attention Weights') # 条形图可能更清晰
    ax2.set_title('Spatial Attention Weights')
    ax2.set_xlabel('Attention Time Step (after convolutions/pooling)')
    ax2.set_ylabel('Attention Weight')
    ax2.legend()

    # 图3 onwards: 通道注意力权重 (如果多变量)
    if input_channels > 1:
        # channel_weights_np 应该是1D数组 (num_model_channels_for_attention,)
        # 注意：这里的 num_model_channels_for_attention 是 AttentionBlock 的输入通道数，
        # 而不是原始数据的 input_channels。原始数据的每个通道会经过 initial_conv 和 multi_scale，
        # 然后 AttentionBlock 作用于这些组合后的特征图。
        # 可视化原始 input_channels 的权重需要更复杂的映射或不同类型的注意力。
        # 当前的 channel_weights 是对 AttentionBlock 输入的所有通道的权重。
        # 因此，直接将其绘制为条形图更有意义。
        ax3 = plt.subplot(2 + (1 if input_channels == 1 else input_channels), 1, 3)
        num_att_channels = len(channel_weights_np)
        ax3.bar(np.arange(num_att_channels), channel_weights_np, color='green')
        ax3.set_title(f'Channel Attention Weights (for {num_att_channels} channels entering AttentionBlock)')
        ax3.set_xlabel('Channel Index (in AttentionBlock)')
        ax3.set_ylabel('Attention Weight')
    elif input_channels == 1 and len(channel_weights_np) > 1: # 单输入通道，但注意力模块可能看多个衍生通道
        ax3 = plt.subplot(3, 1, 3)
        num_att_channels = len(channel_weights_np)
        ax3.bar(np.arange(num_att_channels), channel_weights_np, color='green')
        ax3.set_title(f'Channel Attention Weights (for {num_att_channels} channels entering AttentionBlock from single input)')
        ax3.set_xlabel('Derived Channel Index (in AttentionBlock)')
        ax3.set_ylabel('Attention Weight')

    plt.tight_layout()
    # 保存图像
    save_path = f"attention_visualization_{dataset_name}_sample{sample_idx}.png"
    plt.savefig(save_path)
    print(f"Attention visualization saved to {save_path}")
    plt.show()

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Visualize Attention Weights of CNN_BiGRU_Attention Model')
    parser.add_argument('--model_path', type=str, required=True, help='Path to the pre-trained model (.pth file)')
    parser.add_argument('--dataset_name', type=str, required=True, help='Name of the UCR dataset to load (e.g., ArrowHead)')
    parser.add_argument('--data_dir', type=str, default='dataset', help='Directory where UCR datasets are stored')
    parser.add_argument('--sample_idx', type=int, default=0, help='Index of the sample from the test set to visualize')
    
    # 添加模型实例化所需的参数，最好与train.py中的一致，并提供合理的默认值或使其可配置
    parser.add_argument('--num_multiscale_paths', type=int, default=4, help='Number of parallel conv paths in MultiScaleFeatureExtraction')
    parser.add_argument('--final_dropout_rate', type=float, default=0.4, help='Dropout rate before the final classifier')
    parser.add_argument('--gru_hidden_size', type=int, default=128, help='Hidden size of GRU layers')
    parser.add_argument('--num_gru_layers', type=int, default=2, help='Number of GRU layers')
    parser.add_argument('--adaptive_pool_output_size', type=int, default=50, help='Output size of AdaptiveAvgPool1d before GRU')

    args = parser.parse_args()

    visualize_attention(
        model_path=args.model_path,
        dataset_name=args.dataset_name,
        data_dir=args.data_dir,
        sample_idx=args.sample_idx,
        num_multiscale_paths_model=args.num_multiscale_paths,
        final_dropout_rate_model=args.final_dropout_rate,
        gru_hidden_size_model=args.gru_hidden_size,
        num_gru_layers_model=args.num_gru_layers,
        adaptive_pool_output_size_model=args.adaptive_pool_output_size
    ) 