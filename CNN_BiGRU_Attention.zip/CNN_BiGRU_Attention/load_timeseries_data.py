# load_timeseries_data_cn.py
import numpy as np
import os
from sklearn.preprocessing import StandardScaler, LabelEncoder
import torch
from torch.utils.data import TensorDataset, DataLoader
import arff

def preprocess_arff(content):
    lines = content.split('\n')
    processed_lines = []
    in_data_section = False
    current_data_line = []
    
    for line in lines:
        line = line.strip()
        if not line or line.startswith('%'):
            continue
            
        if line.lower().startswith('@data'):
            in_data_section = True
            processed_lines.append(line)
            continue
            
        if in_data_section:
            # 处理数据行
            if line.startswith("'") and line.endswith("'"):
                # 处理多行数据
                values = line.strip("'").split(',')
                # 移除所有换行符和多余的空格
                values = [v.strip().replace('\n', '') for v in values]
                # 移除最后一个值中的'n'字符
                if values and values[-1].endswith('n'):
                    values[-1] = values[-1][:-1]
                # 移除最后一个值中的'Standing'字符
                if values and values[-1].endswith('Standing'):
                    values[-1] = values[-1][:-8]
                # 移除最后一个值中的'Standing\n'字符
                if values and values[-1].endswith('Standing\n'):
                    values[-1] = values[-1][:-9]
                processed_line = ','.join(values)
                processed_lines.append(processed_line)
            else:
                # 处理普通数据行
                line = line.replace('\n', '').strip()
                if line:  # 只添加非空行
                    # 移除行末尾的'n'字符
                    if line.endswith('n'):
                        line = line[:-1]
                    # 移除行末尾的'Standing'字符
                    if line.endswith('Standing'):
                        line = line[:-8]
                    # 移除行末尾的'Standing\n'字符
                    if line.endswith('Standing\n'):
                        line = line[:-9]
                    processed_lines.append(line)
        else:
            # 处理属性定义
            if not line.lower().startswith('@attribute') or 'relational' not in line.lower():
                processed_lines.append(line)
    
    return '\n'.join(processed_lines)

def process_data(data):
    """处理单个数据集的辅助函数"""
    features = []
    labels = []
    first_row_length = None
    
    for row in data['data']:
        # 初始化特征列表
        row_features = []
        
        # 处理特征
        for i, value in enumerate(row[:-1]):  # 除最后一个值（标签）外的所有值
            if isinstance(value, str):
                if value.startswith("'") and value.endswith("'"):
                    # 处理关系型数据
                    values = value.strip("'").split(',')
                    # 确保所有值都是有效的数值
                    valid_values = []
                    for v in values:
                        try:
                            if v != 'NaN' and v != '?' and v is not None:
                                valid_values.append(float(v))
                            else:
                                valid_values.append(np.nan)
                        except ValueError:
                            valid_values.append(np.nan)
                    row_features.extend(valid_values)
                else:
                    # 处理其他字符串类型的数值
                    try:
                        row_features.append(float(value) if value != 'NaN' and value != '?' else np.nan)
                    except ValueError:
                        row_features.append(np.nan)
            else:
                # 处理数值类型
                row_features.append(float(value) if value is not None else np.nan)
        
        # 检查特征向量长度
        if first_row_length is None:
            first_row_length = len(row_features)
            features.append(row_features)
            labels.append(row[-1])
        elif len(row_features) == first_row_length:
            features.append(row_features)
            labels.append(row[-1])
        else:
            print(f"警告：跳过长度不匹配的样本（期望长度：{first_row_length}，实际长度：{len(row_features)}）")
    
    return np.array(features), np.array(labels)

def load_special_dataset(dataset_name, data_dir='dataset'):
    """
    专门处理特殊格式的数据集（AtrialFibrillation和BasicMotions）
    """
    dataset_path = os.path.join(data_dir, dataset_name)
    
    def read_special_arff(file_path):
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 找到数据部分的开始
        data_start = content.find('@data')
        if data_start == -1:
            raise Exception("找不到数据部分")
        
        # 分离属性和数据部分
        attributes = content[:data_start].strip()
        data_section = content[data_start:].strip()
        
        # 处理数据部分
        data_lines = data_section.split('\n')[1:]  # 跳过@data行
        processed_data = []
        current_row = []
        
        for line in data_lines:
            line = line.strip()
            if not line:
                continue
                
            # 处理多行数据
            if line.startswith("'") and line.endswith("'"):
                if current_row:  # 如果当前行不为空，先处理它
                    processed_data.append(current_row)
                    current_row = []
                values = line.strip("'").split(',')
                # 移除所有换行符和多余的空格
                values = [v.strip().replace('\n', '') for v in values]
                processed_data.append(values)
            else:
                # 处理普通数据行
                values = line.split(',')
                # 检查是否是新的数据行（通过检查值的数量）
                if len(values) > 1:  # 如果包含多个值，说明是新行
                    if current_row:  # 如果当前行不为空，先处理它
                        processed_data.append(current_row)
                    current_row = values
                else:  # 如果只有一个值，可能是上一行的继续
                    current_row.extend(values)
        
        # 处理最后一行
        if current_row:
            processed_data.append(current_row)
        
        return processed_data
    
    try:
        # 读取训练集和测试集
        train_file = os.path.join(dataset_path, f'{dataset_name}_TRAIN.arff')
        test_file = os.path.join(dataset_path, f'{dataset_name}_TEST.arff')
        
        train_data = read_special_arff(train_file)
        test_data = read_special_arff(test_file)
        
        # 处理数据
        def process_special_data(data):
            features = []
            labels = []
            
            for row in data:
                # 最后一个值是标签
                label = row[-1]
                # 其余都是特征
                feature_values = []
                for v in row[:-1]:
                    # 移除引号和两端空格
                    v = v.strip().strip("'")
                    
                    # 处理换行符
                    if '\n' in v:
                        # 只取换行符之前的部分
                        parts = v.split('\n')
                        v = parts[0].strip()  # 取第一部分并再次去除空格
                        # 可选：如果需要，可以警告或记录被分割的值 parts[1:]
                    
                    # 处理逗号
                    if ',' in v:
                        v = v.split(',')[0].strip()
                    
                    # 处理空格
                    if ' ' in v:
                        v = v.split(' ')[0].strip()
                    
                    try:
                        # 检查是否为空字符串或无效值
                        if v == '' or v == 'NaN' or v == '?':
                            feature_values.append(0.0)
                            print(f"警告：遇到空值或无效值 '{v}', 使用0.0代替")
                        else:
                            # 尝试转换为浮点数
                            try:
                                feature_values.append(float(v))
                            except ValueError:
                                # 如果转换失败，尝试使用正则表达式提取数字
                                import re
                                numbers = re.findall(r'-?\d+\.?\d*', v)
                                if numbers:
                                    feature_values.append(float(numbers[0]))
                                else:
                                    print(f"警告：无法从值 '{v}' 中提取数字，使用0.0代替")
                                    feature_values.append(0.0)
                    except Exception as e:
                        print(f"警告：处理值 '{v}' 时发生错误: {str(e)}, 使用0.0代替")
                        feature_values.append(0.0)
                
                features.append(feature_values)
                labels.append(label)
            
            return np.array(features), np.array(labels)
        
        # 处理训练集和测试集
        X_train, y_train = process_special_data(train_data)
        X_test, y_test = process_special_data(test_data)
        
        # 使用 LabelEncoder 将字符串标签转换为数字
        le = LabelEncoder()
        le.fit(np.concatenate([y_train, y_test]))
        y_train = le.transform(y_train)
        y_test = le.transform(y_test)
        
        return X_train, y_train, X_test, y_test, le.classes_
        
    except Exception as e:
        print(f"加载数据集 {dataset_name} 时发生错误: {str(e)}")
        raise

def load_ucr_dataset(dataset_name, data_dir='dataset'):
    """
    加载 UCR 数据集
    Args:
        dataset_name: 数据集名称
        data_dir: 数据集目录
    Returns:
        X_train: 训练数据
        y_train: 训练标签
        X_test: 测试数据
        y_test: 测试标签
    """
    # 特殊数据集处理
    if dataset_name in ['AtrialFibrillation', 'BasicMotions']:
        return load_special_dataset(dataset_name, data_dir)
    
    # 构建数据集路径
    dataset_path = os.path.join(data_dir, dataset_name)
    
    try:
        # 尝试不同的编码方式加载文件
        encodings = ['utf-8', 'latin-1']
        train_data = None
        test_data = None
        
        for encoding in encodings:
            try:
                train_file = os.path.join(dataset_path, f'{dataset_name}_TRAIN.arff')
                test_file = os.path.join(dataset_path, f'{dataset_name}_TEST.arff')
                
                # 读取文件内容
                with open(train_file, 'r', encoding=encoding) as f:
                    train_content = f.read()
                with open(test_file, 'r', encoding=encoding) as f:
                    test_content = f.read()
                
                # 处理文件内容
                train_content = preprocess_arff(train_content)
                test_content = preprocess_arff(test_content)
                
                # 加载处理后的内容
                train_data = arff.loads(train_content)
                test_data = arff.loads(test_content)
                break
            except UnicodeDecodeError:
                continue
        
        if train_data is None or test_data is None:
            raise Exception(f"无法使用支持的编码方式读取数据集 {dataset_name}")
        
        # 处理训练集和测试集
        X_train, y_train = process_data(train_data)
        X_test, y_test = process_data(test_data)
        
        # 确保所有特征向量长度一致
        if X_train.shape[1] != X_test.shape[1]:
            raise Exception(f"训练集和测试集特征维度不匹配: {X_train.shape[1]} vs {X_test.shape[1]}")
        
        if dataset_name == 'BeetleFly':
            print(f"[DEBUG] BeetleFly - Before LabelEncoder - y_train unique: {np.unique(y_train)}")
            print(f"[DEBUG] BeetleFly - Before LabelEncoder - y_test unique: {np.unique(y_test)}")

        # 使用 LabelEncoder 将字符串标签转换为数字
        le = LabelEncoder()
        le.fit(np.concatenate([y_train, y_test]))
        y_train = le.transform(y_train)
        y_test = le.transform(y_test)
        
        if dataset_name == 'BeetleFly':
            print(f"[DEBUG] BeetleFly - After LabelEncoder - y_train unique: {np.unique(y_train)}")
            print(f"[DEBUG] BeetleFly - After LabelEncoder - y_test unique: {np.unique(y_test)}")
            print(f"[DEBUG] BeetleFly - LabelEncoder classes: {le.classes_}")

        # 填充缺失值
        X_train = np.nan_to_num(X_train, nan=0.0)
        X_test = np.nan_to_num(X_test, nan=0.0)
        
        return X_train, y_train, X_test, y_test, le.classes_
        
    except Exception as e:
        print(f"加载数据集 {dataset_name} 时发生错误: {str(e)}")
        raise

def preprocess_data(X_train, X_test):
    """数据预处理"""
    # 标准化
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # 转换为 PyTorch 张量
    X_train_tensor = torch.FloatTensor(X_train_scaled)
    X_test_tensor = torch.FloatTensor(X_test_scaled)
    
    return X_train_tensor, X_test_tensor

def create_dataloaders(X_train, X_test, y_train, y_test, batch_size=32):
    """创建数据加载器"""
    # 转换为 PyTorch 张量
    y_train_tensor = torch.LongTensor(y_train)
    y_test_tensor = torch.LongTensor(y_test)
    
    # 创建数据集
    train_dataset = TensorDataset(X_train, y_train_tensor)
    test_dataset = TensorDataset(X_test, y_test_tensor)
    
    # 创建数据加载器
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
    
    return train_loader, test_loader

def main():
    """测试数据加载功能的主函数"""
    # 获取当前文件所在目录
    current_dir = os.path.dirname(os.path.abspath(__file__))
    dataset_dir = os.path.join(current_dir, 'dataset')
    
    # 获取dataset目录下的所有数据集目录
    dataset_names = [d for d in os.listdir(dataset_dir) if os.path.isdir(os.path.join(dataset_dir, d))]
    
    for dataset_name in dataset_names:
        try:
            X_train, y_train, X_test, y_test, classes = load_ucr_dataset(dataset_name)
            print(f"\n数据集 {dataset_name} 加载成功:")
            print(f"训练集形状: {X_train.shape}")
            print(f"测试集形状: {X_test.shape}")
            print(f"训练集标签: {np.unique(y_train)}")
            print(f"测试集标签: {np.unique(y_test)}")
        except Exception as e:
            print(f"加载数据集 {dataset_name} 失败: {str(e)}")

if __name__ == "__main__":
    main()