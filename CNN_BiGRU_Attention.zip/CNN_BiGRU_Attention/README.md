<!-- Automatically generated markdown file -->
# Time Series Classification with Continual Learning

This project focuses on Continual Learning (CL) for Time Series Classification (TSC) using a custom deep learning model, `CNN_BiGRU_Attention`. It provides scripts for standard training, evaluation, and dedicated continual learning experiments on UCR time series datasets.

## Features

### 1. Core Model: `CNN_BiGRU_Attention`
   - Located in `model.py`.
   - **Hybrid Architecture**: Combines Convolutional Neural Networks (CNNs), a Bidirectional Gated Recurrent Unit (BiGRU), and a CBAM-like Attention mechanism (Channel and Spatial attention).
   - **Multi-Scale Feature Extraction**: Employs multiple parallel 1D convolutional paths with different kernel sizes (configurable, defaults to 4 paths with kernels 3, 5, 7, 9) to capture features at various temporal scales.
   - **Attention Mechanism**: Enhances feature representation by focusing on important channels and time steps.
       - **Attention Weight Export**: The model can optionally return channel and spatial attention weights for interpretability analysis (see `visualize_attention.py`).
   - **Adaptive Pooling**: Handles variable-length time series before feeding them into the BiGRU layer.
   - **Bidirectional GRU**: Captures temporal dependencies from both forward and backward directions.
   - **Configurable Architecture**: Key parameters like the number of multi-scale paths, dropout rates, GRU hidden size, GRU layers, and adaptive pooling output size are configurable via command-line arguments in `train.py`.
   - **Multi-Head Classifier**: Dynamically adds new classification heads for new tasks encountered in a continual learning scenario.

### 2. Data Handling (`load_timeseries_data.py`)
   - **UCR Dataset Loading**: Supports loading and preprocessing of UCR time series datasets from `.arff` files.
   - **Specialized Handling**: Includes logic to correctly parse datasets with non-standard ARFF formats (e.g., `AtrialFibrillation`, `BasicMotions`).
   - **Preprocessing**: Performs Z-score normalization on features and independent label encoding for each dataset.

### 3. Continual Learning Framework (`train.py`)
   - **Flexible Benchmark Creation**:
     - **UCR Time Series Benchmark**: Facilitates creating CL scenarios using 10 specified UCR datasets (`ArrowHead`, `AtrialFibrillation`, `BasicMotions`, `Beef`, `BeetleFly`, `BirdChicken`, `BME`, `Coffee`, `DodgerLoopDay`, `DodgerLoopGame`), where each dataset can form a separate learning "experience" or "task".
       - Automatically infers `input_channels` and `sequence_length` from the first loaded dataset.
       - Handles potential inconsistencies in sequence length or feature dimensions across datasets by using the dimensions of the first dataset and issuing warnings for mismatches (padding/truncation logic is commented out for future implementation if needed).
     - **SplitMNIST Benchmark**: Retains the SplitMNIST benchmark for comparison and quick validation.
     - Utilizes Avalanche-lib utilities like `benchmark_from_datasets` and `AvalancheDataset` for robust benchmark construction.
   - **Supported Continual Learning Strategies**:
     - **Naive (Finetuning)**
     - **EWC (Elastic Weight Consolidation)**: `ewc_lambda` is configurable.
     - **Replay (Experience Replay)**: `memory_size` is configurable, using `ExperienceBalancedBuffer`.
     - **LwF (Learning without Forgetting)**: `lwf_alpha` (balancing factor) and `lwf_temperature` are configurable.
   - **Dynamic Training Loop**:
     - Iterates sequentially through experiences in the benchmark.
     - Dynamically adds new classifier heads to the model and resets the optimizer when new tasks are encountered.
   - **Comprehensive Evaluation & Logging**:
     - Tracks a wide array of metrics: accuracy (batch, epoch, experience, stream), loss, forgetting, CPU usage, training/evaluation time, and RAM usage.
     - **Multiple Loggers**: Supports `InteractiveLogger` (console), `TextLogger` (to `.txt` files), and `TensorboardLogger`.
     - **End-of-Strategy Summary**: Prints a console summary after each strategy run, including final average accuracy, backward transfer (forgetting), per-task final accuracies, and final CPU/RAM usage.
   - **Extensive Command-Line Interface (`argparse`)**: Allows for detailed configuration of:
     - Benchmark selection and data paths.
     - Model architecture parameters.
     - Training hyperparameters (learning rate, epochs, batch size).
     - CL strategies to run and their specific hyperparameters.
     - Logging options, random seed, and CUDA device.

### 4. Model Interpretability (`visualize_attention.py`)
   - **Attention Weight Visualization**:
     - Loads a pre-trained `CNN_BiGRU_Attention` model and a sample from a specified UCR dataset.
     - Extracts channel and spatial attention weights by calling the model with `return_attention_weights=True`.
     - Visualizes the original time series, spatial attention weights (over (subsampled) time steps), and channel attention weights (for channels entering the `AttentionBlock`) using `matplotlib`.
     - Saves the visualization to an image file.
     - Configurable via command-line arguments for model path, dataset, sample index, and model architecture parameters (which must match the pre-trained model).

### 5. Results Visualization (`visualization_all.py`) - In Progress
   - This script is designed to generate various plots for experiment reporting:
     - Training history (loss/accuracy curves).
     - Confusion matrices.
     - Accuracy comparisons across datasets and models.
     - Ablation study results.
     - CL strategy performance comparisons.
   - **Current Status**:
     - The plotting functions are implemented.
     - **Training history visualization now supports loading real data from a CSV file** (specified via `--history_csv`).
     - Other plots currently use placeholder/simulated data. The script is structured to be extended by adding data loading functions for these plots from actual experimental result files (e.g., CSVs).
   - **Future Work for this script**: Implement data loading from saved experiment results for all plot types.

## Project Structure

```
.
├── dataset/                  # Directory to store UCR datasets (e.g., ArrowHead/ArrowHead_TRAIN.arff)
├── model.py                  # Contains the CNN_BiGRU_Attention model definition.
├── load_timeseries_data.py   # Utilities for loading and preprocessing UCR datasets.
├── train.py                  # Main script for running continual learning experiments.
├── visualize_attention.py    # Script to visualize attention weights of a trained model.
├── visualization_all.py      # Script to generate various plots from experiment results.
├── plots/                    # Default directory where generated plots are saved.
├── README.md                 # This file.
└── (other potential files: requirements.txt, saved_models/, logs/)
```

## Setup

1.  **Clone the repository (if applicable).**
2.  **Install dependencies.** It's recommended to use a virtual environment.
    ```bash
    pip install torch torchvision torchaudio avalanche-lib numpy pandas scikit-learn matplotlib seaborn arff
    ```
    (Ensure `avalanche-lib` is a version compatible with the imports used, e.g., >=0.5.0 for some metrics/generators).
3.  **Download UCR Datasets**:
    Place the 10 UCR datasets (ArrowHead, AtrialFibrillation, etc.) into the `dataset/` directory. Each dataset should typically have its own subdirectory (e.g., `dataset/ArrowHead/ArrowHead_TRAIN.arff`, `dataset/ArrowHead/ArrowHead_TEST.arff`).

## Usage

### 1. Training Continual Learning Models

Use `train.py` to run experiments.

**Example: Running EWC and LwF on the UCR benchmark with specific model parameters:**
```bash
python train.py \
    --benchmark_name ucr_timeseries \
    --data_dir dataset/ \
    --strategies EWC LwF \
    --num_multiscale_paths 4 \
    --final_dropout_rate 0.4 \
    --epochs 50 \
    --batch_size 32 \
    --lr 0.001 \
    --ewc_lambda 1000 \
    --lwf_alpha 0.5 \
    --lwf_temperature 1 \
    --log_text --log_tb \
    --cuda 0
```

**Key command-line arguments for `train.py`:**
*   `--benchmark_name`: `ucr_timeseries` or `split_mnist`.
*   `--data_dir`: Path to the root directory of UCR datasets.
*   `--strategies`: List of CL strategies (e.g., `Naive`, `EWC`, `Replay`, `LwF`).
*   `--num_multiscale_paths`, `--final_dropout_rate`, etc.: Model architecture parameters.
*   `--epochs`, `--lr`, `--batch_size`: Training hyperparameters.
*   `--ewc_lambda`, `--memory_size`, `--lwf_alpha`, `--lwf_temperature`: Strategy-specific hyperparameters.
*   `--log_text`, `--log_tb`: Enable text and TensorBoard logging.
*   `--cuda`: GPU ID to use (e.g., 0, 1) or -1 for CPU.
*   `--seed`: Random seed.

Experiment logs will be saved to `tb_logs/` (for TensorBoard) and `<strategy_name>_log.txt`.

### 2. Visualizing Attention Weights

First, train a model using `train.py` and ensure its state dictionary is saved (e.g., as `saved_models/my_ucr_model.pth`).

Then, use `visualize_attention.py`. **Ensure the model architecture parameters passed to this script match those used for training the loaded model.**

**Example:**
```bash
python visualize_attention.py \
    --model_path saved_models/my_ucr_model.pth \
    --dataset_name ArrowHead \
    --data_dir dataset/ \
    --sample_idx 0 \
    --num_multiscale_paths 4 \
    --final_dropout_rate 0.4
```
This will save an image (e.g., `attention_visualization_ArrowHead_sample0.png`) in the current directory.

### 3. Visualizing Experiment Results (`visualization_all.py`)

This script is used to generate plots from collected experiment data. Currently, it primarily supports loading training history from a CSV file.

**Example for training history:**
Assume your `train.py` (or a separate script) saves training history to `results/Coffee_CNNBiGRU_history.csv` with columns like `epoch,train_loss,val_loss,train_acc,val_acc`.
```bash
python visualization_all.py \
    --history_csv results/Coffee_CNNBiGRU_history.csv \
    --dataset_name Coffee \
    --model_name CNN_BiGRU_Attention
```
This will save `plots/Coffee_CNN_BiGRU_Attention_training_history.png`.

To use other plotting functions in `visualization_all.py` with real data, you'll need to:
1.  Ensure your experiments save the necessary data (e.g., accuracy scores, confusion matrix components) in a parsable format (like CSV).
2.  Implement corresponding data loading functions within `visualization_all.py`.
3.  Add command-line arguments to specify the paths to these data files.

## Future Work 

*   **Implement Data Unification for UCR Benchmark**: Add robust padding/truncation in `train.py` for UCR datasets with varying sequence lengths to ensure model compatibility.
*   **Save/Load Model Configuration**: Store model architecture parameters alongside the state dictionary to simplify loading in `visualize_attention.py` and other analysis scripts.
*   **Expand `visualization_all.py`**:
    *   Implement data loading from actual experiment logs/CSVs for all plot types (confusion matrix, accuracy comparisons, ablation studies, CL results).
    *   Allow parsing data from `TextLogger` output of `train.py` for CL metrics.
*   **Hyperparameter Optimization**: Systematically study the impact of CL hyperparameters (EWC lambda, Replay buffer size, LwF alpha/temperature) using sweeps or automated HPO tools.
*   **Explore More Advanced CL Algorithms**: Integrate and evaluate other CL strategies beyond the current set.
*   **Quantitative CL Metrics**: Ensure detailed logging and analysis of metrics like Forward Transfer, Learning Accuracy, etc.
*   **Refined Attention Visualization**: For spatial attention, explore methods to align its "time steps" more directly with the original input sequence (e.g., by upsampling or mapping). 