# -*- coding: utf-8 -*-
import torch
import torch.nn as nn
import torch.nn.functional as F

class StandardConvLayer(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size):
        super(StandardConvLayer, self).__init__()
        # 增加了 'same' 风格的 padding 以适应奇数卷积核
        self.conv = nn.Conv1d(in_channels, out_channels, kernel_size, padding=kernel_size // 2)
        self.bn = nn.BatchNorm1d(out_channels)
        # 将 MaxPool1d 的 kernel_size 改为 3，stride 改为 2，以减少下采样强度
        # 注意：输出长度可能会根据输入长度和步长而变化。
        # 如果需要固定输出大小，请考虑使用自适应池化或调整层。
        self.pool = nn.MaxPool1d(kernel_size=3, stride=2, padding=1) # 这里也添加了 padding

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = F.relu(x)
        x = self.pool(x)
        return x

class MultiScaleFeatureExtraction(nn.Module):
    def __init__(self, in_channels, out_channels=32, num_paths=3):
        super(MultiScaleFeatureExtraction, self).__init__()
        self.num_paths = num_paths
        self.conv_paths = nn.ModuleList()
        # 使用不同的卷积核大小进行多尺度分析
        # 路径1: kernel_size=3
        # 路径2: kernel_size=5
        # 路径3: kernel_size=7
        # 路径4: kernel_size=9 (如果 num_paths >= 4)
        # 可以根据 num_paths 动态创建更多路径，这里为了匹配报告，如果num_paths=4，我们有特定的核大小
        
        kernel_sizes = [3, 5, 7, 9, 11] # 可以扩展的卷积核大小列表

        if num_paths > len(kernel_sizes):
            print(f"警告: 请求的并行路径数 ({num_paths}) 大于预定义的卷积核大小数量 ({len(kernel_sizes)}). 将使用所有预定义路径.")
            self.num_paths = len(kernel_sizes)

        for i in range(self.num_paths):
            self.conv_paths.append(StandardConvLayer(in_channels, out_channels, kernel_sizes[i]))

    def forward(self, x):
        path_outputs = []
        min_len = -1
        for conv_layer in self.conv_paths:
            out = conv_layer(x)
            path_outputs.append(out)
            if min_len == -1 or out.size(2) < min_len:
                min_len = out.size(2)
        
        # 将所有路径的输出裁剪到最小长度
        processed_outputs = []
        for out in path_outputs:
            processed_outputs.append(out[:, :, :min_len])
            
        return torch.cat(processed_outputs, dim=1) # 沿通道维度拼接

class AttentionBlock(nn.Module):
    # 使用类似 CBAM 的注意力（通道 + 空间）
    def __init__(self, channels):
        super(AttentionBlock, self).__init__()
        self.channel_attention = nn.Sequential(
            nn.AdaptiveAvgPool1d(1),
            # 对通道注意力的 MLP 使用 Conv1d 而不是 Linear
            nn.Conv1d(channels, channels // 8, 1, bias=False),
            nn.ReLU(),
            nn.Conv1d(channels // 8, channels, 1, bias=False),
            # 根据一些 CBAM 变体，从通道注意力路径中移除最后的 Sigmoid
        )
        # 在此处添加 sigmoid，在广播后按元素应用
        self.sigmoid_channel = nn.Sigmoid()

        self.spatial_attention = nn.Sequential(
            # 对空间注意力上下文使用更大的卷积核
            nn.Conv1d(2, 1, kernel_size=7, padding=3, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x, return_attention_weights=False):
        # 通道注意力
        # 注意：原始CBAM论文中，MLP是共享的。这里实现为两个独立的MLP路径然后相加。
        # 为了简化并匹配一些实现，我们可以在应用MLP之前进行池化。
        # 当前代码：先池化，然后每个池化结果通过独立的MLP（因为channel_attention是Sequential）。
        # 如果要共享MLP，channel_attention需要先作用于拼接的或者相加的池化特征。
        # 让我们保持当前结构，它分别处理 avg 和 max pool 然后合并它们的输出（权重）。

        pooled_avg = F.adaptive_avg_pool1d(x, 1)
        pooled_max = F.adaptive_max_pool1d(x, 1)
        
        avg_pool_ca_out = self.channel_attention(pooled_avg) 
        max_pool_ca_out = self.channel_attention(pooled_max) 
        
        channel_weights = self.sigmoid_channel(avg_pool_ca_out + max_pool_ca_out) 
        x_channel_att = x * channel_weights  # 应用通道注意力

        # 空间注意力
        avg_pool_spatial = torch.mean(x_channel_att, dim=1, keepdim=True)
        max_pool_spatial, _ = torch.max(x_channel_att, dim=1, keepdim=True)
        spatial_cat = torch.cat([avg_pool_spatial, max_pool_spatial], dim=1) 
        spatial_weights = self.spatial_attention(spatial_cat) 
        x_spatial_att = x_channel_att * spatial_weights 

        if return_attention_weights:
            return x_spatial_att, channel_weights, spatial_weights
        else:
            return x_spatial_att

class CNN_BiGRU_Attention(nn.Module):
    def __init__(self, input_channels, sequence_length, num_classes_initial, 
                 num_multiscale_paths=3, final_dropout_rate=0.5, gru_hidden_size=128, num_gru_layers=2, adaptive_pool_output_size=50):
        super(CNN_BiGRU_Attention, self).__init__()
        self.input_channels = input_channels # 期望输入形状 (batch, channels, sequence_length)

        # 初始特征提取 (调整输入通道)
        initial_conv_out_channels = 64
        self.initial_conv = nn.Sequential(
            nn.Conv1d(input_channels, initial_conv_out_channels, kernel_size=7, padding=3, bias=False), # 增加滤波器数量，增大卷积核
            nn.BatchNorm1d(initial_conv_out_channels),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=3, stride=2, padding=1)
        )
        current_channels = initial_conv_out_channels

        # 多尺度特征提取
        multiscale_out_channels_per_path = 64 # 每个路径的输出通道数
        self.multi_scale = MultiScaleFeatureExtraction(current_channels, 
                                                   out_channels=multiscale_out_channels_per_path, 
                                                   num_paths=num_multiscale_paths)
        # 计算多尺度后的输出通道数 (num_multiscale_paths * multiscale_out_channels_per_path)
        current_channels = multiscale_out_channels_per_path * num_multiscale_paths

        # 注意力机制
        self.attention = AttentionBlock(current_channels)
        # 注意力机制后通道数不变

        # 自适应池化
        self.adaptive_pool_output_size = adaptive_pool_output_size
        self.adaptive_pool = nn.AdaptiveAvgPool1d(output_size=self.adaptive_pool_output_size)

        # 时序特征提取 (GRU)
        self.gru_input_size = current_channels 
        self.gru_hidden_size = gru_hidden_size 
        self.num_gru_layers = num_gru_layers
        self.gru1 = nn.GRU(self.gru_input_size, self.gru_hidden_size, num_layers=self.num_gru_layers,
                           bidirectional=True, batch_first=True, dropout=0.2 if self.num_gru_layers > 1 else 0) # GRU的dropout只在多层时有效

        # 分类器
        self.classifier_input_features = self.gru_hidden_size * 2 # 双向
        self.dropout = nn.Dropout(final_dropout_rate) # 使用可配置的dropout率
        
        self.task_classifiers = nn.ModuleList([
            nn.Linear(self.classifier_input_features, num_classes_initial)
        ])

    def add_task_classifier(self, num_new_classes, device):
        """添加一个新的任务特定分类器"""
        new_classifier = nn.Linear(self.classifier_input_features, num_new_classes).to(device)
        self.task_classifiers.append(new_classifier)
        print(f"为任务 {len(self.task_classifiers) - 1} 添加了新的分类器头，包含 {num_new_classes} 个类。")
        return len(self.task_classifiers) - 1 # 返回新分类器的索引

    def forward(self, x, task_labels=None, return_attention_weights=False):
        # 输入 x: (batch_size, sequence_length)
        # 模型期望输入 (batch, channels, sequence_length)
        if x.dim() == 2:  # 如果是 (batch, sequence_length)
            x = x.unsqueeze(1)  # 添加通道维度 (batch, channel, sequence_length)
        # 检查通道数是否与模型初始化时的 input_channels 匹配
        # 这个检查应该在 unsqueeze(1) 之后，如果初始维度是2D
        # 或者在开始时，如果期望输入总是3D
        # 当前实现：如果输入是2D，则假定为单通道并unsqueeze。如果输入是3D，则检查通道数。
        if x.shape[1] != self.input_channels:
            # 如果原始是2D且input_channels=1，上面的unsqueeze(1)已经处理了
            # 这个错误主要针对当输入已经是3D但通道数不匹配的情况
            if not (x.dim() == 3 and self.input_channels == 1 and x.shape[1] != 1 ): # 修正条件，允许input_channels=1时，扩展后的x.shape[1]为1
                 # 实际上，如果 x.dim() == 2 并且 self.input_channels == 1，那么 x.unsqueeze(1) 后 x.shape[1] == 1，所以不会触发下面的错误
                 # 如果 x.dim() == 3, 那么 x.shape[1] 必须等于 self.input_channels
                 if not (x.dim() == 2 and self.input_channels == 1): # 如果不是来自2D->3D且input_channel=1的情况
                    if x.shape[1] != self.input_channels: #再次检查，确保逻辑正确
                        raise ValueError(f"Input tensor channel dimension mismatch. Model expected {self.input_channels} channels, but got {x.shape[1]} in shape {x.shape}")
        
        # 初始卷积 -> 多尺度 -> 注意力
        x_conv = self.initial_conv(x)
        x_multiscale = self.multi_scale(x_conv)
        
        att_output = self.attention(x_multiscale, return_attention_weights=return_attention_weights)
        if return_attention_weights:
            x_attention, channel_weights, spatial_weights = att_output
        else:
            x_attention = att_output
            channel_weights, spatial_weights = None, None # 确保在不返回时这些是None

        # 自适应池化以固定 GRU 前的序列长度
        x_pooled = self.adaptive_pool(x_attention) 

        # 为 GRU 做准备
        x_gru_input = x_pooled.permute(0, 2, 1) 

        # GRU 层
        x_gru_out, _ = self.gru1(x_gru_input) 

        # 使用最后一个时间步的输出进行分类
        x_features = x_gru_out[:, -1, :] 

        x_dropped = self.dropout(x_features)

        # 多头分类逻辑
        if task_labels is None:
            # 如果没有任务标签，并且有多个头，则不明确使用哪个头。
            # 默认使用第一个头，或者抛出错误/警告。
            # 当前实现：使用第一个头。
            if len(self.task_classifiers) > 1:
                print("Warning: task_labels is None, but multiple classifiers exist. Using classifier 0.")
            final_output = self.task_classifiers[0](x_dropped)
        else:
            # Ensure task_labels is a tensor and on the correct device if it's passed from outside Avalanche
            if not isinstance(task_labels, torch.Tensor):
                task_labels = torch.tensor(task_labels, device=x_dropped.device, dtype=torch.long)
            elif task_labels.device != x_dropped.device:
                task_labels = task_labels.to(x_dropped.device)
            
            # Ensure task_labels is not empty and contains valid indices
            if task_labels.numel() == 0:
                raise ValueError("task_labels tensor is empty.")
            
            # For batch_first=True in GRU, task_labels might correspond to each item in the batch.
            # Avalanche strategies usually provide task_labels for the whole batch, often as a single value or per-sample.
            # Assuming task_labels is either a scalar or a 1D tensor where all elements are the same (homogenous batch for task ID).
            if task_labels.ndim > 0:
                task_id = int(task_labels[0].item()) # Use the task_label of the first sample for the batch
            else: # scalar tensor
                task_id = int(task_labels.item())

            if task_id < len(self.task_classifiers):
                final_output = self.task_classifiers[task_id](x_dropped)
            else:
                print(f"Warning: Task ID {task_id} is out of range for available classifiers ({len(self.task_classifiers)}). Using classifier 0.")
                final_output = self.task_classifiers[0](x_dropped)

        if return_attention_weights:
            return final_output, channel_weights, spatial_weights
        else:
            return final_output

class MultiHeadMLP(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, num_initial_classes):
        super(MultiHeadMLP, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        
        # 共享的特征提取层
        self.feature_extractor = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(hidden_size, output_size),
            nn.ReLU(),
            nn.Dropout(0.5)
        )
        
        # 任务特定的分类器头
        self.task_classifiers = nn.ModuleList([
            nn.Linear(output_size, num_initial_classes)
        ])
        
    def add_task_classifier(self, num_new_classes, device):
        """添加一个新的任务特定分类器"""
        new_classifier = nn.Linear(self.output_size, num_new_classes).to(device)
        self.task_classifiers.append(new_classifier)
        print(f"为任务 {len(self.task_classifiers) - 1} 添加了新的分类器头，包含 {num_new_classes} 个类。")
        return len(self.task_classifiers) - 1
        
    def forward(self, x, task_labels=None):
        # 提取共享特征
        features = self.feature_extractor(x)
        
        # 如果没有提供 task_labels，使用默认分类器
        if task_labels is None:
            return self.task_classifiers[0](features)
            
        # 使用任务特定的分类器
        task_id = int(task_labels[0].item())  # 假设批次是同质的
        if task_id < len(self.task_classifiers):
            return self.task_classifiers[task_id](features)
        else:
            print(f"警告: 任务 ID {task_id} 超出可用分类器范围 ({len(self.task_classifiers)})。使用分类器 0。")
            return self.task_classifiers[0](features)

class CNN(nn.Module):
    def __init__(self, input_channels, sequence_length, num_classes):
        super(CNN, self).__init__()
        
        self.features = nn.Sequential(
            nn.Conv1d(input_channels, 64, kernel_size=3, padding=1),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2, stride=2),
            
            nn.Conv1d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2, stride=2),
            
            nn.Conv1d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2, stride=2),
        )
        
        # 计算全连接层的输入特征数
        self.fc_input_size = 256 * (sequence_length // 8)  # 经过3次池化，序列长度变为原来的1/8
        
        self.classifier = nn.Sequential(
            nn.Linear(self.fc_input_size, 512),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(512, num_classes)
        )
        
    def forward(self, x):
        if x.dim() == 2:
            x = x.unsqueeze(1)
        x = self.features(x)
        x = x.view(x.size(0), -1)
        x = self.classifier(x)
        return x

class MCNN(nn.Module):
    def __init__(self, input_channels, sequence_length, num_classes):
        super(MCNN, self).__init__()
        
        # 多尺度卷积分支
        self.branch1 = nn.Sequential(
            nn.Conv1d(input_channels, 32, kernel_size=3, padding=1),
            nn.BatchNorm1d(32),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2, stride=2)
        )
        
        self.branch2 = nn.Sequential(
            nn.Conv1d(input_channels, 32, kernel_size=5, padding=2),
            nn.BatchNorm1d(32),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2, stride=2)
        )
        
        self.branch3 = nn.Sequential(
            nn.Conv1d(input_channels, 32, kernel_size=7, padding=3),
            nn.BatchNorm1d(32),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2, stride=2)
        )
        
        # 合并后的特征提取
        self.features = nn.Sequential(
            nn.Conv1d(96, 128, kernel_size=3, padding=1),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2, stride=2),
            
            nn.Conv1d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2, stride=2)
        )
        
        # 计算全连接层的输入特征数
        self.fc_input_size = 256 * (sequence_length // 8)
        
        self.classifier = nn.Sequential(
            nn.Linear(self.fc_input_size, 512),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(512, num_classes)
        )
        
    def forward(self, x):
        if x.dim() == 2:
            x = x.unsqueeze(1)
        
        # 多尺度特征提取
        x1 = self.branch1(x)
        x2 = self.branch2(x)
        x3 = self.branch3(x)
        
        # 合并多尺度特征
        x = torch.cat([x1, x2, x3], dim=1)
        
        # 进一步特征提取
        x = self.features(x)
        x = x.view(x.size(0), -1)
        x = self.classifier(x)
        return x

class FCN(nn.Module):
    def __init__(self, input_channels, sequence_length, num_classes):
        super(FCN, self).__init__()
        
        self.features = nn.Sequential(
            nn.Conv1d(input_channels, 128, kernel_size=8, padding=4),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            
            nn.Conv1d(128, 256, kernel_size=5, padding=2),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            
            nn.Conv1d(256, 128, kernel_size=3, padding=1),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            
            nn.AdaptiveAvgPool1d(1)  # 全局平均池化
        )
        
        self.classifier = nn.Sequential(
            nn.Linear(128, num_classes)
        )
        
    def forward(self, x):
        if x.dim() == 2:
            x = x.unsqueeze(1)
        x = self.features(x)
        x = x.view(x.size(0), -1)
        x = self.classifier(x)
        return x

class ResidualBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1):
        super(ResidualBlock, self).__init__()
        
        self.conv1 = nn.Conv1d(in_channels, out_channels, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm1d(out_channels)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv1d(out_channels, out_channels, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm1d(out_channels)
        
        self.shortcut = nn.Sequential()
        if stride != 1 or in_channels != out_channels:
            self.shortcut = nn.Sequential(
                nn.Conv1d(in_channels, out_channels, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm1d(out_channels)
            )
            
    def forward(self, x):
        residual = x
        
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)
        
        out = self.conv2(out)
        out = self.bn2(out)
        
        out += self.shortcut(residual)
        out = self.relu(out)
        
        return out

class ResNet(nn.Module):
    def __init__(self, input_channels, sequence_length, num_classes):
        super(ResNet, self).__init__()
        
        self.in_channels = 64
        
        # 初始卷积层
        self.conv1 = nn.Sequential(
            nn.Conv1d(input_channels, 64, kernel_size=7, stride=2, padding=3, bias=False),
            nn.BatchNorm1d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool1d(kernel_size=3, stride=2, padding=1)
        )
        
        # ResNet层
        self.layer1 = self.make_layer(64, 2, stride=1)
        self.layer2 = self.make_layer(128, 2, stride=2)
        self.layer3 = self.make_layer(256, 2, stride=2)
        self.layer4 = self.make_layer(512, 2, stride=2)
        
        # 全局平均池化
        self.avgpool = nn.AdaptiveAvgPool1d(1)
        
        # 分类器
        self.classifier = nn.Sequential(
            nn.Linear(512, num_classes)
        )
        
    def make_layer(self, out_channels, num_blocks, stride):
        layers = []
        layers.append(ResidualBlock(self.in_channels, out_channels, stride))
        self.in_channels = out_channels
        for _ in range(1, num_blocks):
            layers.append(ResidualBlock(out_channels, out_channels))
        return nn.Sequential(*layers)
        
    def forward(self, x):
        if x.dim() == 2:
            x = x.unsqueeze(1)
            
        x = self.conv1(x)
        
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        
        x = self.avgpool(x)
        x = x.view(x.size(0), -1)
        x = self.classifier(x)
        
        return x

# --- 添加以下 main 函数用于测试 ---
if __name__ == '__main__':
    # 1. 定义测试参数
    batch_size = 4         # 示例批次大小
    input_channels = 1     # 示例输入通道数 (例如，单变量时间序列)
    sequence_length = 1000 # 示例序列长度 (需要足够长以通过所有卷积/池化层)
    num_classes_initial = 10 # 示例初始任务的类别数
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print(f"--- Model Test Initializing ---")
    print(f"Device: {device}")
    print(f"Parameters: Batch={batch_size}, Channels={input_channels}, SeqLen={sequence_length}, Classes={num_classes_initial}")

    # 2. 实例化模型
    try:
        model = CNN_BiGRU_Attention(
            input_channels=input_channels,
            sequence_length=sequence_length, # 注意：模型内部未使用此参数初始化层，但为了匹配构造函数签名而保留
            num_classes_initial=num_classes_initial
        ).to(device)
        print("\n--- Model Architecture ---")
        print(model)
        print("Model instantiated successfully.")
    except Exception as e:
        print(f"\n--- Error during model instantiation ---")
        print(e)
        exit() # 如果模型无法实例化，则退出

    # 3. 创建虚拟输入数据
    # 模型期望输入形状: (batch, channels, sequence_length)
    dummy_input = torch.randn(batch_size, input_channels, sequence_length).to(device)
    # 模型 forward 方法需要 task_labels
    dummy_task_labels = torch.zeros(batch_size, dtype=torch.long).to(device) # 假设测试任务 0

    print(f"\n--- Testing Forward Pass ---")
    print(f"Dummy input shape: {dummy_input.shape}")
    print(f"Dummy task labels shape: {dummy_task_labels.shape}")

    # 4. 测试前向传播
    try:
        model.eval() # 设置为评估模式（会影响 Dropout, BatchNorm 等）
        with torch.no_grad(): # 不需要计算梯度
            output = model(dummy_input, dummy_task_labels)
        print(f"Forward pass successful!")
        print(f"Output shape: {output.shape}")
        # 检查输出形状是否符合预期：(batch_size, num_classes_initial)
        expected_shape = (batch_size, num_classes_initial)
        if output.shape == expected_shape:
            print(f"Output shape matches expected shape: {expected_shape}")
        else:
            print(f"Warning: Output shape {output.shape} does not match expected shape {expected_shape}")

    except Exception as e:
        print(f"\n--- Error during forward pass ---")
        print(e)

    print(f"\n--- Model Test Finished ---")