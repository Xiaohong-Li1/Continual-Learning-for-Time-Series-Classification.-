# -*- coding: utf-8 -*-
import torch
import torch.nn as nn
import torch.nn.functional as F

class StandardConvLayer(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size):
        super(StandardConvLayer, self).__init__()
        # 增加了 'same' 风格的 padding 以适应奇数卷积核
        self.conv = nn.Conv1d(in_channels, out_channels, kernel_size, padding=kernel_size // 2)
        self.bn = nn.BatchNorm1d(out_channels)
        # 将 MaxPool1d 的 kernel_size 改为 3，stride 改为 2，以减少下采样强度
        # 注意：输出长度可能会根据输入长度和步长而变化。
        # 如果需要固定输出大小，请考虑使用自适应池化或调整层。
        self.pool = nn.MaxPool1d(kernel_size=3, stride=2, padding=1) # 这里也添加了 padding

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = F.relu(x)
        x = self.pool(x)
        return x

class MultiScaleFeatureExtraction(nn.Module):
    def __init__(self, in_channels, out_channels=32, num_paths=3):
        super(MultiScaleFeatureExtraction, self).__init__()
        self.num_paths = num_paths
        self.conv_paths = nn.ModuleList()
        # 使用不同的卷积核大小进行多尺度分析
        # 路径1: kernel_size=3
        # 路径2: kernel_size=5
        # 路径3: kernel_size=7
        # 路径4: kernel_size=9 (如果 num_paths >= 4)
        # 可以根据 num_paths 动态创建更多路径，这里为了匹配报告，如果num_paths=4，我们有特定的核大小
        
        kernel_sizes = [3, 5, 7, 9, 11] # 可以扩展的卷积核大小列表

        if num_paths > len(kernel_sizes):
            print(f"警告: 请求的并行路径数 ({num_paths}) 大于预定义的卷积核大小数量 ({len(kernel_sizes)}). 将使用所有预定义路径.")
            self.num_paths = len(kernel_sizes)

        for i in range(self.num_paths):
            self.conv_paths.append(StandardConvLayer(in_channels, out_channels, kernel_sizes[i]))

    def forward(self, x):
        path_outputs = []
        min_len = -1
        for conv_layer in self.conv_paths:
            out = conv_layer(x)
            path_outputs.append(out)
            if min_len == -1 or out.size(2) < min_len:
                min_len = out.size(2)
        
        # 将所有路径的输出裁剪到最小长度
        processed_outputs = []
        for out in path_outputs:
            processed_outputs.append(out[:, :, :min_len])
            
        return torch.cat(processed_outputs, dim=1) # 沿通道维度拼接

class AttentionBlock(nn.Module):
    # 使用类似 CBAM 的注意力（通道 + 空间）
    def __init__(self, channels):
        super(AttentionBlock, self).__init__()
        self.channel_attention = nn.Sequential(
            nn.AdaptiveAvgPool1d(1),
            # 对通道注意力的 MLP 使用 Conv1d 而不是 Linear
            nn.Conv1d(channels, channels // 8, 1, bias=False),
            nn.ReLU(),
            nn.Conv1d(channels // 8, channels, 1, bias=False),
            # 根据一些 CBAM 变体，从通道注意力路径中移除最后的 Sigmoid
        )
        # 在此处添加 sigmoid，在广播后按元素应用
        self.sigmoid_channel = nn.Sigmoid()

        self.spatial_attention = nn.Sequential(
            # 对空间注意力上下文使用更大的卷积核
            nn.Conv1d(2, 1, kernel_size=7, padding=3, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x, return_attention_weights=False):
        # 通道注意力
        # 注意：原始CBAM论文中，MLP是共享的。这里实现为两个独立的MLP路径然后相加。
        # 为了简化并匹配一些实现，我们可以在应用MLP之前进行池化。
        # 当前代码：先池化，然后每个池化结果通过独立的MLP（因为channel_attention是Sequential）。
        # 如果要共享MLP，channel_attention需要先作用于拼接的或者相加的池化特征。
        # 让我们保持当前结构，它分别处理 avg 和 max pool 然后合并它们的输出（权重）。

        pooled_avg = F.adaptive_avg_pool1d(x, 1)
        pooled_max = F.adaptive_max_pool1d(x, 1)
        
        avg_pool_ca_out = self.channel_attention(pooled_avg) 
        max_pool_ca_out = self.channel_attention(pooled_max) 
        
        channel_weights = self.sigmoid_channel(avg_pool_ca_out + max_pool_ca_out) 
        x_channel_att = x * channel_weights  # 应用通道注意力

        # 空间注意力
        avg_pool_spatial = torch.mean(x_channel_att, dim=1, keepdim=True)
        max_pool_spatial, _ = torch.max(x_channel_att, dim=1, keepdim=True)
        spatial_cat = torch.cat([avg_pool_spatial, max_pool_spatial], dim=1) 
        spatial_weights = self.spatial_attention(spatial_cat) 
        x_spatial_att = x_channel_att * spatial_weights 

        if return_attention_weights:
            return x_spatial_att, channel_weights, spatial_weights
        else:
            return x_spatial_att

class CNN_BiGRU_Attention(nn.Module):
    def __init__(self, input_channels, sequence_length, num_classes_initial, 
                 num_multiscale_paths=3, final_dropout_rate=0.5, gru_hidden_size=128, num_gru_layers=2, adaptive_pool_output_size=50):
        super(CNN_BiGRU_Attention, self).__init__()
        self.input_channels = input_channels # 期望输入形状 (batch, channels, sequence_length)
        self.current_task_id = 0 # 初始化 current_task_id 属性

        # 初始特征提取 (调整输入通道)
        initial_conv_out_channels = 64
        self.initial_conv = nn.Sequential(
            nn.Conv1d(input_channels, initial_conv_out_channels, kernel_size=7, padding=3, bias=False), # 增加滤波器数量，增大卷积核
            nn.BatchNorm1d(initial_conv_out_channels),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=3, stride=2, padding=1)
        )
        current_channels = initial_conv_out_channels

        # 多尺度特征提取
        multiscale_out_channels_per_path = 64 # 每个路径的输出通道数
        self.multi_scale = MultiScaleFeatureExtraction(current_channels, 
                                                   out_channels=multiscale_out_channels_per_path, 
                                                   num_paths=num_multiscale_paths)
        # 计算多尺度后的输出通道数 (num_multiscale_paths * multiscale_out_channels_per_path)
        current_channels = multiscale_out_channels_per_path * num_multiscale_paths

        # 注意力机制
        self.attention = AttentionBlock(current_channels)
        # 注意力机制后通道数不变

        # 自适应池化
        self.adaptive_pool_output_size = adaptive_pool_output_size
        self.adaptive_pool = nn.AdaptiveAvgPool1d(output_size=self.adaptive_pool_output_size)

        # 时序特征提取 (GRU)
        self.gru_input_size = current_channels 
        self.gru_hidden_size = gru_hidden_size 
        self.num_gru_layers = num_gru_layers
        self.gru1 = nn.GRU(self.gru_input_size, self.gru_hidden_size, num_layers=self.num_gru_layers,
                           bidirectional=True, batch_first=True, dropout=0.2 if self.num_gru_layers > 1 else 0) # GRU的dropout只在多层时有效

        # 分类器
        self.classifier_input_features = self.gru_hidden_size * 2 # 双向
        self.dropout = nn.Dropout(final_dropout_rate) # 使用可配置的dropout率
        
        self.task_classifiers = nn.ModuleList([
            nn.Linear(self.classifier_input_features, num_classes_initial)
        ])

    def add_task_classifier(self, num_new_classes, device):
        """添加一个新的任务特定分类器"""
        new_classifier = nn.Linear(self.classifier_input_features, num_new_classes).to(device)
        self.task_classifiers.append(new_classifier)
        print(f"为任务 {len(self.task_classifiers) - 1} 添加了新的分类器头，包含 {num_new_classes} 个类。")
        return len(self.task_classifiers) - 1 # 返回新分类器的索引

    def forward(self, x, task_labels=None, return_attention_weights=False):
        # 输入 x: (batch_size, sequence_length)
        # 模型期望输入 (batch, channels, sequence_length)
        if x.dim() == 2:  # 如果是 (batch, sequence_length)
            x = x.unsqueeze(1)  # 添加通道维度 (batch, channel, sequence_length)
        # 检查通道数是否与模型初始化时的 input_channels 匹配
        # 这个检查应该在 unsqueeze(1) 之后，如果初始维度是2D
        # 或者在开始时，如果期望输入总是3D
        # 当前实现：如果输入是2D，则假定为单通道并unsqueeze。如果输入是3D，则检查通道数。
        if x.shape[1] != self.input_channels:
            # 如果原始是2D且input_channels=1，上面的unsqueeze(1)已经处理了
            # 这个错误主要针对当输入已经是3D但通道数不匹配的情况
            if not (x.dim() == 3 and self.input_channels == 1 and x.shape[1] != 1 ): # 修正条件，允许input_channels=1时，扩展后的x.shape[1]为1
                 # 实际上，如果 x.dim() == 2 并且 self.input_channels == 1，那么 x.unsqueeze(1) 后 x.shape[1] == 1，所以不会触发下面的错误
                 # 如果 x.dim() == 3, 那么 x.shape[1] 必须等于 self.input_channels
                 if not (x.dim() == 2 and self.input_channels == 1): # 如果不是来自2D->3D且input_channel=1的情况
                    if x.shape[1] != self.input_channels: #再次检查，确保逻辑正确
                        raise ValueError(f"Input tensor channel dimension mismatch. Model expected {self.input_channels} channels, but got {x.shape[1]} in shape {x.shape}")
        
        # 初始卷积 -> 多尺度 -> 注意力
        x_conv = self.initial_conv(x)
        x_multiscale = self.multi_scale(x_conv)
        
        att_output = self.attention(x_multiscale, return_attention_weights=return_attention_weights)
        if return_attention_weights:
            x_attention, channel_weights, spatial_weights = att_output
        else:
            x_attention = att_output
            channel_weights, spatial_weights = None, None # 确保在不返回时这些是None

        # 自适应池化以固定 GRU 前的序列长度
        x_pooled = self.adaptive_pool(x_attention) 

        # 为 GRU 做准备
        x_gru_input = x_pooled.permute(0, 2, 1) 

        # GRU 层
        x_gru_out, _ = self.gru1(x_gru_input) 

        # 使用最后一个时间步的输出进行分类
        x_features = x_gru_out[:, -1, :] 

        x_dropped = self.dropout(x_features)

        # 多头分类逻辑 - 使用 self.current_task_id (由插件设置)
        # print(f"[MODEL FORWARD DEBUG] task_labels param: {task_labels}") # 调试传入的task_labels
        # print(f"[MODEL FORWARD DEBUG] self.current_task_id attr: {getattr(self, 'current_task_id', 'NOT SET')}")
        
        # 优先使用插件设置的 current_task_id
        print(f"[MODEL FORWARD] Top: Accessed model.current_task_id: {getattr(self, 'current_task_id', 'NOT SET (will default to 0 if task_labels not provided)')}")
        if hasattr(self, 'current_task_id'):
            # 这个 current_task_id 应该由 Avalanche 插件 (SetTaskLabelPlugin) 在每个经验开始时设置
            task_id_to_use = self.current_task_id
            # print(f"[MODEL FORWARD DEBUG] Using task_id from self.current_task_id: {task_id_to_use}")
        elif task_labels is not None:
            # 如果插件没设置，但forward被直接调用且传入了task_labels (例如独立测试模型时)
            # 确保 task_labels 是单个整数或可以转换为单个整数的张量
            if isinstance(task_labels, torch.Tensor):
                if task_labels.numel() == 1:
                    task_id_to_use = task_labels.item()
                else: # 如果 task_labels 是一个批次的标签，这里逻辑需要调整，通常模型希望一个统一的task_id
                    print(f"[MODEL FORWARD] Warning: task_labels provided as a batch, using first element: {task_labels[0].item()}")
                    task_id_to_use = task_labels[0].item() # 或者抛出错误，取决于期望行为
            elif isinstance(task_labels, int):
                task_id_to_use = task_labels
            else:
                raise ValueError("task_labels must be an int or a single-element tensor if self.current_task_id is not set.")
            # print(f"[MODEL FORWARD DEBUG] Using task_id from task_labels argument: {task_id_to_use}")
        else:
            # print("[MODEL FORWARD DEBUG] Neither self.current_task_id set nor task_labels provided. Defaulting task_id to 0.")
            task_id_to_use = 0 # 最后的默认值

        print(f"[MODEL FORWARD] Middle: Effective task_id to use: {task_id_to_use} for a model with {len(self.task_classifiers)} heads.")

        if task_id_to_use < len(self.task_classifiers):
            final_output = self.task_classifiers[task_id_to_use](x_dropped)
            # print(f"[MODEL FORWARD DEBUG] Selected head {task_id_to_use} with output shape: {final_output.shape}")
        else:
            print(f"[MODEL FORWARD] ERROR! task_id {task_id_to_use} is out of bounds for {len(self.task_classifiers)} classifiers.")
            raise IndexError(f"Error in forward: task_id {task_id_to_use} is out of bounds. "
                             f"Model only has {len(self.task_classifiers)} classifiers (up to task {len(self.task_classifiers)-1}). "
                             f"Attempted to access head for task {task_id_to_use}.")

        if return_attention_weights:
            return final_output, channel_weights, spatial_weights
        else:
            return final_output

class MultiHeadMLP(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, num_initial_classes):
        super(MultiHeadMLP, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        
        # 共享的特征提取层
        self.feature_extractor = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(hidden_size, output_size),
            nn.ReLU(),
            nn.Dropout(0.5)
        )
        
        # 任务特定的分类器头
        self.task_classifiers = nn.ModuleList([
            nn.Linear(output_size, num_initial_classes)
        ])
        
    def add_task_classifier(self, num_new_classes, device):
        """添加一个新的任务特定分类器"""
        new_classifier = nn.Linear(self.output_size, num_new_classes).to(device)
        self.task_classifiers.append(new_classifier)
        print(f"为任务 {len(self.task_classifiers) - 1} 添加了新的分类器头，包含 {num_new_classes} 个类。")
        return len(self.task_classifiers) - 1
        
    def forward(self, x, task_labels=None):
        # 提取共享特征
        features = self.feature_extractor(x)
        
        # 如果没有提供 task_labels，使用默认分类器
        if task_labels is None:
            return self.task_classifiers[0](features)
            
        # 使用任务特定的分类器
        task_id = int(task_labels[0].item())  # 假设批次是同质的
        if task_id < len(self.task_classifiers):
            return self.task_classifiers[task_id](features)
        else:
            print(f"警告: 任务 ID {task_id} 超出可用分类器范围 ({len(self.task_classifiers)})。使用分类器 0。")
            return self.task_classifiers[0](features)

# --- Standard LSTM Model --- 
class StandardLSTM(nn.Module):
    def __init__(self, input_channels, hidden_size, num_layers, num_classes, 
                 bidirectional=False, dropout_rate=0.5):
        super(StandardLSTM, self).__init__()
        self.input_channels = input_channels
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.bidirectional = bidirectional
        
        # LSTM 层
        # batch_first=True 使输入/输出张量的形状为 (batch, seq, feature)
        self.lstm = nn.LSTM(input_size=input_channels, 
                            hidden_size=hidden_size, 
                            num_layers=num_layers, 
                            batch_first=True, 
                            bidirectional=bidirectional,
                            # dropout只在num_layers > 1时应用在层之间
                            dropout=dropout_rate if num_layers > 1 else 0)
        
        # 分类器层
        # 如果是双向，则最终特征维度是 hidden_size * 2
        classifier_input_features = hidden_size * 2 if bidirectional else hidden_size
        self.classifier = nn.Sequential(
            nn.Dropout(dropout_rate),
            nn.Linear(classifier_input_features, num_classes)
        )

    def forward(self, x):
        # 输入 x: (batch, channels, seq_len)
        # LSTM 期望: (batch, seq_len, channels/features)
        if x.dim() == 2:
            x = x.unsqueeze(1) # -> (batch, 1, seq_len)
        
        # 检查通道维度
        if x.shape[1] != self.input_channels:
             if not (x.dim() == 3 and self.input_channels == 1 and x.shape[1] == 1): # 允许从 (B, S) -> (B, 1, S) 转换
                raise ValueError(f"Input tensor channel mismatch. Expected {self.input_channels}, got {x.shape[1]}")

        x = x.permute(0, 2, 1) # (batch, seq_len, channels)
        
        # 初始化隐藏状态和细胞状态 (默认为0)
        # h0 = torch.zeros(self.num_layers * (2 if self.bidirectional else 1), x.size(0), self.hidden_size).to(x.device)
        # c0 = torch.zeros(self.num_layers * (2 if self.bidirectional else 1), x.size(0), self.hidden_size).to(x.device)
        
        # LSTM 前向传播
        # output: (batch, seq_len, hidden_size * num_directions)
        # hn: (num_layers * num_directions, batch, hidden_size) - 最后时间步的隐藏状态
        # cn: (num_layers * num_directions, batch, hidden_size) - 最后时间步的细胞状态
        output, (hn, cn) = self.lstm(x) #, (h0, c0))
        
        # 使用最后一个时间步的输出进行分类
        # output[:, -1, :] 形状为 (batch, hidden_size * num_directions)
        features = output[:, -1, :]
        
        # 或者使用最后一层的最后一个隐藏状态 hn
        # 需要正确处理双向和多层的情况来获取用于分类的特征
        # 例如，对于双向单层: torch.cat((hn[0,:,:], hn[1,:,:]), dim=1)
        # 使用 output[:, -1, :] 更简单
        
        # 分类
        out = self.classifier(features)
        return out

class StandardGRU(nn.Module):
    def __init__(self, input_channels, hidden_size, num_layers, num_classes,
                 bidirectional=False, dropout_rate=0.5):
        super(StandardGRU, self).__init__()
        self.input_channels = input_channels
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.bidirectional = bidirectional
        
        self.gru = nn.GRU(input_size=input_channels,
                          hidden_size=hidden_size,
                          num_layers=num_layers,
                          batch_first=True,
                          bidirectional=bidirectional,
                          dropout=dropout_rate if num_layers > 1 else 0)
        
        classifier_input_features = hidden_size * 2 if bidirectional else hidden_size
        self.classifier = nn.Sequential(
            nn.Dropout(dropout_rate),
            nn.Linear(classifier_input_features, num_classes)
        )

    def forward(self, x):
        if x.dim() == 2:
            x = x.unsqueeze(1) 
            
        if x.shape[1] != self.input_channels:
             if not (x.dim() == 3 and self.input_channels == 1 and x.shape[1] == 1):
                raise ValueError(f"Input tensor channel mismatch. Expected {self.input_channels}, got {x.shape[1]}")

        x = x.permute(0, 2, 1) 
        
        output, hn = self.gru(x)
        features = output[:, -1, :]
        out = self.classifier(features)
        return out