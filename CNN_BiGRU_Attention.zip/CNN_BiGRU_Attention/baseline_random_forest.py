# baseline_random_forest.py

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
from scipy.stats import skew, kurtosis
import warnings
# from load_timeseries_data import load_ucr_dataset # 不再由此文件直接加载
# import os # 不再需要

# Suppress warnings for cleaner output if any arise from feature calculation
warnings.simplefilter('ignore', RuntimeWarning) # For issues like mean of empty slice

def extract_statistical_features(X):
    """
    从一组时间序列中提取基本的统计特征。
    假设 X 是一个 2D numpy 数组，其中每行是一个时间序列 (n_samples, sequence_length)。
    """
    n_samples, sequence_length = X.shape
    features = []
    for i in range(n_samples):
        ts = X[i, :]
        # 处理潜在的全 NaN 切片
        if np.all(np.isnan(ts)):
            features.append(np.zeros(6)) # 对缺失序列附加零或根据策略处理
            continue

        # 过滤 NaN 以进行稳健的统计计算
        ts_clean = ts[~np.isnan(ts)]
        if ts_clean.size == 0: # 如果所有值都是 NaN
             features.append(np.zeros(6))
             continue

        _mean = np.mean(ts_clean)
        _std = np.std(ts_clean)
        _min = np.min(ts_clean)
        _max = np.max(ts_clean)
        _skew = skew(ts_clean)
        _kurt = kurtosis(ts_clean)
        features.append([_mean, _std, _min, _max, _skew, _kurt])
    return np.array(features)

def run_rf_baseline_for_dataset(X_train, y_train, X_test, y_test, dataset_name, class_names=None, n_estimators=100, random_state=42):
    """
    在提取的统计特征上训练和评估随机森林分类器。
    X_train, X_test: (n_samples, sequence_length) 或 (n_samples, 1, sequence_length)
    返回一个包含评估结果的字典。
    """
    print(f"运行随机森林分类器基线 for {dataset_name}...")

    # 确保 X_train 和 X_test 是 2D 用于特征提取
    if X_train.ndim == 3 and X_train.shape[1] == 1:
        X_train_2d = X_train.squeeze(axis=1)
    elif X_train.ndim == 2:
        X_train_2d = X_train
    else:
        raise ValueError(f"X_train 的维度不正确: {X_train.ndim}. 期望是 2 或 3 (单通道).")

    if X_test.ndim == 3 and X_test.shape[1] == 1:
        X_test_2d = X_test.squeeze(axis=1)
    elif X_test.ndim == 2:
        X_test_2d = X_test
    else:
        raise ValueError(f"X_test 的维度不正确: {X_test.ndim}. 期望是 2 或 3 (单通道).")

    print(f"为随机森林提取特征 for {dataset_name}...")
    X_train_features = extract_statistical_features(X_train_2d)
    X_test_features = extract_statistical_features(X_test_2d)

    # 处理特征提取可能产生的 NaN (例如，来自全 NaN 序列)
    X_train_features = np.nan_to_num(X_train_features, nan=0.0, posinf=0.0, neginf=0.0)
    X_test_features = np.nan_to_num(X_test_features, nan=0.0, posinf=0.0, neginf=0.0)

    model = RandomForestClassifier(n_estimators=n_estimators, random_state=random_state, n_jobs=-1)

    print(f"训练随机森林模型 for {dataset_name}...")
    try:
        model.fit(X_train_features, y_train)
        y_pred = model.predict(X_test_features)
        accuracy = accuracy_score(y_test, y_pred)
        # report_str = classification_report(y_test, y_pred, target_names=class_names, zero_division=0)
        print(f"随机森林分类器 ({dataset_name}) - 测试准确率: {accuracy:.4f}")

        # 修正 Classes 的计算逻辑
        num_classes = len(class_names) if class_names is not None and class_names.size > 0 else len(np.unique(y_train))

        return {
            'Dataset': dataset_name,
            'Model': 'RandomForest',
            'Test Accuracy': accuracy,
            'Test Loss': np.nan,
            'Classes': num_classes, # 使用修正后的值
            'Training Samples': len(X_train),
            'Testing Samples': len(X_test)
        }
    except Exception as e:
        print(f"RandomForest 基线 for {dataset_name} 失败: {e}")
        import traceback # 导入 traceback
        traceback.print_exc() # 打印详细的 traceback
        # 修正 Classes 的计算逻辑 (错误情况)
        num_classes_err = len(class_names) if class_names is not None and class_names.size > 0 else (len(np.unique(y_train)) if y_train is not None and y_train.size > 0 else np.nan)
        return {
            'Dataset': dataset_name,
            'Model': 'RandomForest',
            'Test Accuracy': np.nan,
            'Test Loss': np.nan,
            'Classes': num_classes_err, # 使用修正后的值
            'Training Samples': len(X_train) if X_train is not None else 0,
            'Testing Samples': len(X_test) if X_test is not None else 0,
            'Error': str(e)
        }

# 移除了 if __name__ == '__main__': 部分