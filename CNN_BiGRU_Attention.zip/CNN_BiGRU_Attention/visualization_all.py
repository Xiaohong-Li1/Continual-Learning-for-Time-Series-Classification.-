import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
from sklearn.metrics import confusion_matrix
import os
import argparse # 新增 argparse

# 定义保存目录 (移到前面，方便函数使用)
save_directory = "plots"
os.makedirs(save_directory, exist_ok=True)

# --- 数据加载函数 ---
def load_training_history_from_csv(file_path):
    """从CSV文件加载训练历史数据"""
    try:
        df = pd.read_csv(file_path)
        # 假设CSV有以下列: 'epoch', 'train_loss', 'val_loss', 'train_acc', 'val_acc'
        # 将其转换为绘图函数期望的字典格式
        history_data = {
            'train_loss': df['train_loss'].tolist(),
            'val_loss': df['val_loss'].tolist(),
            'train_acc': df['train_acc'].tolist(),
            'val_acc': df['val_acc'].tolist()
        }
        print(f"Successfully loaded training history from {file_path}")
        return history_data
    except Exception as e:
        print(f"Error loading training history from {file_path}: {e}")
        # 返回一个空的或默认的history，以避免脚本完全中断
        return {'train_loss': [], 'val_loss': [], 'train_acc': [], 'val_acc': []}



# --- 其他模拟数据 (暂时保留，后续可以类似修改) ---
# 2. 混淆矩阵数据
y_true_example = np.random.randint(0, 2, size=50)
y_pred_example = y_true_example.copy()
error_indices = np.random.choice(50, size=5, replace=False)
y_pred_example[error_indices] = np.random.randint(0, 2, size=5)
num_classes_example = 2
class_names_example = [f"Class_{i}" for i in range(num_classes_example)]

# 3. 模型性能比较数据 (包含所有 10 个数据集)
all_datasets = [
    'ArrowHead', 'AtrialFibrillation', 'BasicMotions', 'Beef',
    'BeetleFly', 'BirdChicken', 'BME', 'Coffee',
    'DodgerLoopDay', 'DodgerLoopGame'
]
models_to_compare = ['CNN_BiGRU_Attention', 'CNN', 'MCNN', 'FCN', 'ResNet']

results_data_list = []
for ds in all_datasets:
    for model in models_to_compare:
        if model == 'CNN_BiGRU_Attention':
             accuracy = np.random.uniform(0.70, 0.99)
        elif model == 'MCNN':
             accuracy = np.random.uniform(0.20, 0.65)
        elif ds == 'Coffee' and model in ['FCN', 'ResNet']:
             accuracy = np.random.uniform(0.95, 1.0)
        elif ds == 'Beef' and model == 'CNN':
             accuracy = np.random.uniform(0.75, 0.85)
        else:
             accuracy = np.random.uniform(0.60, 0.95)
        results_data_list.append({'Dataset': ds, 'Model': model, 'Test Accuracy': round(accuracy, 3)})
results_df = pd.DataFrame(results_data_list)

# 4. 消融研究数据 - 块数量
ablation_blocks_data = {
    'Number of Blocks': [1, 2, 3, 4, 5, 6],
    'Accuracy': [0.75, 0.80, 0.83, 0.85, 0.84, 0.82]
}
ablation_blocks_df = pd.DataFrame(ablation_blocks_data)
ablation_dataset_name_example = "ArrowHead" # 将从参数或文件名推断
ablation_model_name_example = "CNN_BiGRU_Attention" # 将从参数或文件名推断

# 5. 消融研究数据 - Dropout率
ablation_dropout_data = {
    'Dropout Rate': [0.1, 0.2, 0.3, 0.4, 0.5, 0.6],
    'Accuracy': [0.80, 0.82, 0.84, 0.85, 0.83, 0.81]
}
ablation_dropout_df = pd.DataFrame(ablation_dropout_data)

# 6. 持续学习策略比较数据
cl_results_data = {
    'Strategy': ['Naive', 'EWC', 'Replay', 'Naive', 'EWC', 'Replay', 'Naive', 'EWC', 'Replay'],
    'Experience': [1, 1, 1, 2, 2, 2, 3, 3, 3],
    'Accuracy': [0.95, 0.96, 0.97, 0.80, 0.88, 0.92, 0.60, 0.75, 0.85]
}
cl_results_df = pd.DataFrame(cl_results_data)
cl_benchmark_name_example = "SplitMNIST" # 将从参数或文件名推断

# --- 绘图函数 (保持不变) ---

def plot_training_history(history_data, dataset_name, model_name="Model", save_path=None):
    """绘制训练历史曲线 (损失和准确率)"""
    if not all(key in history_data and history_data[key] for key in ['train_loss', 'val_loss', 'train_acc', 'val_acc']):
        print(f"Skipping training history plot for {dataset_name} - {model_name} due to missing or empty data.")
        return
    plt.figure(figsize=(12, 5))

    plt.subplot(1, 2, 1)
    plt.plot(history_data['train_loss'], label='Train Loss')
    plt.plot(history_data['val_loss'], label='Validation Loss')
    plt.title(f'{dataset_name} - {model_name}\nTraining & Validation Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.grid(True)

    plt.subplot(1, 2, 2)
    plt.plot(history_data['train_acc'], label='Train Accuracy')
    plt.plot(history_data['val_acc'], label='Validation Accuracy')
    plt.title(f'{dataset_name} - {model_name}\nTraining & Validation Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.ylim(0, 1.05)
    plt.legend()
    plt.grid(True)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path)
        print(f"Training history plot saved to {save_path}")
    plt.close()

def plot_confusion_matrix_heatmap(y_true, y_pred, class_names, dataset_name, model_name="Model", save_path=None):
    """绘制混淆矩阵热力图"""
    cm = confusion_matrix(y_true, y_pred)
    cm_class_indices = list(range(cm.shape[0]))
    if len(class_names) != cm.shape[0]:
         print(f"Warning: Number of class names ({len(class_names)}) does not match confusion matrix size ({cm.shape[0]}). Using generic labels.")
         plot_class_names = [f"Class_{i}" for i in cm_class_indices]
    else:
         plot_class_names = class_names

    plt.figure(figsize=(max(6, len(plot_class_names)*0.8), max(5, len(plot_class_names)*0.6)))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=plot_class_names, yticklabels=plot_class_names)
    plt.title(f'{dataset_name} - {model_name}\nConfusion Matrix')
    plt.xlabel('Predicted Label')
    plt.ylabel('True Label')
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path)
        print(f"Confusion matrix plot saved to {save_path}")
    plt.close()

def plot_accuracy_comparison(results_df, save_path=None):
    """绘制跨数据集和模型的准确率比较条形图"""
    if results_df.empty:
        print("Skipping accuracy comparison plot due to empty data.")
        return
    num_datasets = results_df['Dataset'].nunique()
    plt.figure(figsize=(max(15, num_datasets * 1.2), 8))

    sns.barplot(data=results_df, x='Dataset', y='Test Accuracy', hue='Model', palette='viridis', errorbar=None)
    plt.title('Test Accuracy Comparison Across All Models and Datasets')
    plt.xlabel('Dataset')
    plt.ylabel('Test Accuracy')
    plt.xticks(rotation=45, ha='right')
    plt.ylim(0, 1.05)
    plt.legend(title='Model', bbox_to_anchor=(1.02, 1), loc='upper left')
    plt.grid(axis='y', linestyle='--')
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path)
        print(f"Accuracy comparison plot saved to {save_path}")
    plt.close()

def plot_ablation_study(ablation_df, x_col, y_col, title, xlabel, ylabel, save_path=None):
    """绘制消融研究结果条形图"""
    if ablation_df.empty:
        print(f"Skipping ablation study plot for '{title}' due to empty data.")
        return
    plt.figure(figsize=(8, 5))
    sns.barplot(data=ablation_df, x=x_col, y=y_col, palette='coolwarm', errorbar=None)
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    min_val = ablation_df[y_col].min()
    max_val = ablation_df[y_col].max()
    plt.ylim(bottom=max(0, min_val * 0.95), top=min(1.05, max_val * 1.05))
    plt.grid(axis='y', linestyle='--')
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path)
        print(f"Ablation study plot saved to {save_path}")
    plt.close()

def plot_cl_strategy_comparison(cl_results_df, benchmark_name, save_path=None):
    """绘制持续学习策略在不同经验上的准确率比较线图"""
    if cl_results_df.empty:
        print(f"Skipping CL strategy comparison plot for '{benchmark_name}' due to empty data.")
        return
    plt.figure(figsize=(10, 6))
    sns.lineplot(data=cl_results_df, x='Experience', y='Accuracy', hue='Strategy', marker='o', palette='tab10')
    plt.title(f'CL Strategy Performance Comparison on {benchmark_name}')
    plt.xlabel('Experience ID')
    plt.ylabel('Average Accuracy After Experience')
    unique_experiences = sorted(cl_results_df['Experience'].unique())
    plt.xticks(unique_experiences)
    plt.ylim(0, 1.05)
    plt.legend(title='Strategy')
    plt.grid(True)
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path)
        print(f"CL strategy comparison plot saved to {save_path}")
    plt.close()

def main():
    parser = argparse.ArgumentParser(description="Generate visualizations from experiment data.")
    parser.add_argument('--history_csv', type=str, help='Path to the training history CSV file.')
    parser.add_argument('--dataset_name', type=str, default="UnknownDataset", help='Name of the dataset for plot titles.')
    parser.add_argument('--model_name', type=str, default="UnknownModel", help='Name of the model for plot titles.')
    # ... 在这里为其他图表的数据文件添加更多参数 ...
    # parser.add_argument('--confusion_matrix_data_csv', type=str, help='Path to y_true, y_pred data for confusion matrix.')
    # parser.add_argument('--accuracy_comparison_csv', type=str, help='Path to accuracy comparison data CSV.')
    # parser.add_argument('--ablation_blocks_csv', type=str, help='Path to ablation study (blocks) data CSV.')
    # parser.add_argument('--ablation_dropout_csv', type=str, help='Path to ablation study (dropout) data CSV.')
    # parser.add_argument('--cl_results_csv', type=str, help='Path to CL strategy comparison data CSV.')

    args = parser.parse_args()

    print("Generating plots...")

    # 1. 绘制训练历史
    if args.history_csv:
        history_data_loaded = load_training_history_from_csv(args.history_csv)
        plot_training_history(history_data_loaded, args.dataset_name, args.model_name,
                            save_path=os.path.join(save_directory, f'{args.dataset_name}_{args.model_name}_training_history.png'))
    else:
        print("Skipping training history plot: --history_csv not provided.")

    # --- 其他图表的调用逻辑也需要类似地基于args检查和加载真实数据 ---
    # 2. 绘制混淆矩阵 (示例，需要y_true, y_pred的真实数据源)
    # if args.confusion_matrix_data_csv:
    #    # ... 加载 y_true, y_pred, class_names ...
    #    plot_confusion_matrix_heatmap(y_true_real, y_pred_real, class_names_real, args.dataset_name, args.model_name,
    #                                 save_path=os.path.join(save_directory, f'{args.dataset_name}_{args.model_name}_confusion_matrix.png'))
    # else:
    #    print("Skipping confusion matrix plot: data not provided.")
    print("\nUsing placeholder data for remaining plots until real data loading is implemented:")
    plot_confusion_matrix_heatmap(y_true_example, y_pred_example, class_names_example, "Example_CM_Dataset", "Example_CM_Model",
                             save_path=os.path.join(save_directory, 'confusion_matrix_placeholder.png'))

    # 3. 绘制模型性能比较
    plot_accuracy_comparison(results_df, # 使用仍然是模拟的 results_df
                         save_path=os.path.join(save_directory, 'accuracy_comparison_all_datasets_placeholder.png'))

    # 4. 绘制消融研究 - 块数量
    plot_ablation_study(ablation_blocks_df, # 使用模拟数据
                    x_col='Number of Blocks',
                    y_col='Accuracy',
                    title=f'Ablation Study: Effect of Block Number (Placeholder)',
                    xlabel='Number of Convolutional Blocks',
                    ylabel='Test Accuracy',
                    save_path=os.path.join(save_directory, 'ablation_blocks_placeholder.png'))

    # 5. 绘制消融研究 - Dropout率
    plot_ablation_study(ablation_dropout_df, # 使用模拟数据
                    x_col='Dropout Rate',
                    y_col='Accuracy',
                    title=f'Ablation Study: Effect of Dropout Rate (Placeholder)',
                    xlabel='Dropout Rate',
                    ylabel='Test Accuracy',
                    save_path=os.path.join(save_directory, 'ablation_dropout_placeholder.png'))

    # 6. 绘制 CL 策略比较
    plot_cl_strategy_comparison(cl_results_df, "PlaceholderBenchmark", # 使用模拟数据
                           save_path=os.path.join(save_directory, 'cl_comparison_placeholder.png')) 

    print(f"\nPlot generation finished. Files saved in '{save_directory}' directory.")

    # ... (移除或调整旧的打印模拟数据的部分) ...

if __name__ == '__main__':
    main()