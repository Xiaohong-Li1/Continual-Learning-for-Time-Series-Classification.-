# -*- coding: utf-8 -*-
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset
import numpy as np
from sklearn.preprocessing import StandardScaler # Removed LabelEncoder
from model import CNN_BiGRU_Attention, MultiHeadMLP
import os
import argparse
from torch.nn.utils.rnn import pad_sequence
from tqdm import tqdm # 导入 tqdm
import matplotlib
matplotlib.use('Agg') # Use a non-interactive backend for saving plots
import matplotlib.pyplot as plt
import json # Added for saving results
import sys # Added for checking sys.argv

# Avalanche 导入
from avalanche.benchmarks.classic import SplitMNIST
from avalanche.benchmarks.scenarios.dataset_scenario import benchmark_from_datasets
from avalanche.benchmarks.utils.data import AvalancheDataset
from avalanche.benchmarks.utils.data_attribute import DataAttribute
from avalanche.benchmarks import with_classes_timeline
from load_timeseries_data import load_ucr_dataset 

# 正确导入 Naive 策略
from avalanche.training.supervised import Naive, Cumulative, EWC, GEM, AGEM, Replay, ER_ACE, LFL, SynapticIntelligence
from avalanche.training.plugins import EarlyStoppingPlugin, LRSchedulerPlugin, ReplayPlugin, EWCPlugin
from torch.optim.lr_scheduler import ReduceLROnPlateau
from model import CNN_BiGRU_Attention # 确保导入模型

# 从 storage_policy 子模块导入正确的存储策略类
from avalanche.training.storage_policy import ExperienceBalancedBuffer

from avalanche.evaluation.metrics import accuracy_metrics, loss_metrics, forgetting_metrics, cpu_usage_metrics, timing_metrics, ram_usage_metrics
from avalanche.logging import InteractiveLogger, TextLogger, TensorboardLogger
from avalanche.training.plugins import EvaluationPlugin
from torchvision import transforms

# --- 新增：定义插件 ---
from avalanche.core import SupervisedPlugin
torch.backends.cudnn.enabled = False
# 自定义插件，用于在每个经验开始时设置模型的 task_id
class SetTaskLabelPlugin(SupervisedPlugin):
    def _get_task_id_from_experience(self, experience):
        # 尝试直接获取 task_label (由 with_classes_timeline 添加)
        if hasattr(experience, 'task_label'):
            return experience.task_label
        elif hasattr(experience, 'dataset') and hasattr(experience.dataset, 'targets_task_labels'):
            task_labels_attr = experience.dataset.targets_task_labels
            if isinstance(task_labels_attr, DataAttribute) and hasattr(task_labels_attr, 'data') and task_labels_attr.data:
                return task_labels_attr.data[0] 
            elif isinstance(task_labels_attr, (list, tuple)) and len(task_labels_attr) > 0:
                return task_labels_attr[0]
        elif hasattr(experience, 'dataset') and hasattr(experience.dataset, 'task_labels'):
            task_labels_attr_fallback = experience.dataset.task_labels
            if isinstance(task_labels_attr_fallback, DataAttribute) and hasattr(task_labels_attr_fallback, 'data') and task_labels_attr_fallback.data:
                return task_labels_attr_fallback.data[0]
            elif isinstance(task_labels_attr_fallback, (list, tuple)) and len(task_labels_attr_fallback) > 0:
                return task_labels_attr_fallback[0]
        return 0 

    def before_training_exp(self, strategy: 'BaseStrategy', **kwargs):
        current_exp_id = strategy.experience.current_experience
        task_id = self._get_task_id_from_experience(strategy.experience)
        if hasattr(strategy.model, 'current_task_id'):
            strategy.model.current_task_id = task_id
        # print(f"[PLUGIN] Set strategy.model.current_task_id to: {task_id} for Exp {current_exp_id}")

    def before_eval_exp(self, strategy: 'BaseStrategy', **kwargs):
        current_exp_id = strategy.experience.current_experience
        task_id = self._get_task_id_from_experience(strategy.experience)
        if hasattr(strategy.model, 'current_task_id'):
            strategy.model.current_task_id = task_id
        # print(f"[PLUGIN-EVAL] Set strategy.model.current_task_id to: {task_id} for Exp {current_exp_id}")

# --- 新增：自定义 Collate Function ---
def pad_collate_fn(batch):
    # batch: a list of tuples -> [(feature_tensor_1, label_tensor_1, task_label_1), ...]
    # feature_tensor shape: (C, L_i), where L_i can vary
    # label_tensor shape: () (scalar tensor)
    # task_label shape: () (scalar tensor or int)

    features = [item[0] for item in batch]
    labels = [item[1] for item in batch]
    task_ids = [item[2] for item in batch] # Extract task_ids

    # Check if features have channel dimension C=1. Expected shape (1, L)
    # pad_sequence expects (L, *) or (L, B, *) if batch_first=False
    # We need (B, C, L_max). Let's pad the sequence dim L.
    # Permute features to (L, C) first if C is the first dim
    features_permuted = [f.permute(1, 0) for f in features] # Now list of (L_i, C)

    # Pad the sequence dimension (L)
    features_padded = pad_sequence(features_permuted, batch_first=True, padding_value=0.0) # -> (B, L_max, C)

    # Permute back to (B, C, L_max)
    features_padded = features_padded.permute(0, 2, 1)

    labels = torch.stack(labels, dim=0)
    task_ids = torch.tensor(task_ids, dtype=torch.long) # Stack task_ids into a tensor

    return features_padded, labels, task_ids # Return task_ids as the third element
# --- Collate Function 定义结束 ---

# UCR 数据集列表
UCR_DATASET_NAMES = [
    "ArrowHead", "AtrialFibrillation", "BasicMotions", "Beef", "BeetleFly",
    "BirdChicken", "BME", "Coffee", "DodgerLoopDay", "DodgerLoopGame"
]

def create_benchmark(benchmark_name="ucr_timeseries", n_experiences_mnist=5, seed=42, data_dir='dataset'):
    """
    创建持续学习基准。
    :param benchmark_name: 要创建的基准名称 ('ucr_timeseries' 或 'split_mnist')。
    :param seed: 随机种子。
    :param data_dir: UCR 数据集所在的目录。
    :return: (benchmark, input_channels, sequence_length, n_initial_classes)
    """
    if benchmark_name == "split_mnist":
        print("准备 SplitMNIST 基准...")
        # 定义 MNIST 的转换
        mnist_transform = transforms.Compose([
            transforms.ToTensor(), # 首先转换为张量
            transforms.Lambda(lambda x: x.float()),
            transforms.Lambda(lambda x: x.squeeze(0)), # 移除通道维度
            transforms.Lambda(lambda x: x.view(28*28))   # 展平为1D序列 (28x28=784)
        ])
        
        benchmark = SplitMNIST(
            n_experiences=n_experiences_mnist,
            seed=seed,
            return_task_id=True, # 对多头很重要
            train_transform=mnist_transform,
            eval_transform=mnist_transform,
            class_ids_from_zero_in_each_exp=True # 每个经验中的类别从0开始编号
        )
        # 对于 MNIST，通道为1，序列长度为 28x28=784 (展平后)
        # 如果不展平，sequence_length 可能是 28 (行数)，input_channels 可能是 28 (列数)
        # 但我们的模型 MQCCAF_TimeSeries 期望 (batch, features, seq_len) 或 (batch, seq_len, features)
        # 根据原始模型设计，它接受 (batch, input_channels, sequence_length)
        # 如果 MNIST 图像是 (1, 28, 28), 展平后是 (784), 
        # 如果模型将 784 视为 sequence_length，则 input_channels = 1
        # 如果模型将 28 视为 sequence_length，则 input_channels = 28 (这更像图像)
        # 从模型来看，input_channels 是特征维度，sequence_length 是时间步数。
        # 对于展平的 MNIST，sequence_length=784, input_channels=1
        input_channels = 1
        sequence_length = 784 
        n_initial_classes = len(benchmark.train_stream[0].dataset.targets.unique())
        print(f"SplitMNIST: input_channels={input_channels}, sequence_length={sequence_length}, n_initial_classes={n_initial_classes}")
        return benchmark, input_channels, sequence_length, n_initial_classes

    elif benchmark_name == "ucr_timeseries":
        print(f"准备 UCR 时间序列基准，包含以下数据集: {UCR_DATASET_NAMES}")
        train_datasets = []
        test_datasets = []
        first_dataset = True
        input_channels = -1 # Reverted name
        sequence_length = -1 # Reverted name
        n_initial_classes = -1 # Reverted name

        for i, dataset_name in enumerate(UCR_DATASET_NAMES):
            print(f"加载 UCR 数据集: {dataset_name} (任务 {i})")
            try:
                X_train, y_train, X_test, y_test, classes = load_ucr_dataset(dataset_name, data_dir=data_dir)
            except Exception as e:
                print(f"错误：无法加载数据集 {dataset_name}。跳过。错误信息: {e}")
                continue

            if X_train.ndim == 2:
                X_train = np.expand_dims(X_train, axis=1)
                X_test = np.expand_dims(X_test, axis=1)

            current_n_features = X_train.shape[1]
            current_seq_len = X_train.shape[2]
            num_classes_in_task = len(classes)

            print(f"数据集 {dataset_name}: X_train shape {X_train.shape}, y_train shape {y_train.shape}, n_classes {num_classes_in_task}")

            if first_dataset:
                input_channels = current_n_features
                sequence_length = current_seq_len
                n_initial_classes = num_classes_in_task
                first_dataset = False
            else:
                if current_n_features != input_channels:
                    print(f"警告: 数据集 {dataset_name} 的特征数 ({current_n_features}) 与第一个数据集 ({input_channels}) 不同。这可能导致问题。")
                if current_seq_len != sequence_length:
                    print(f"警告: 数据集 {dataset_name} 的序列长度 ({current_seq_len}) 与第一个数据集 ({sequence_length}) 不同。这可能导致问题。")

            X_train_tensor = torch.FloatTensor(X_train)
            y_train_tensor = torch.LongTensor(y_train)
            X_test_tensor = torch.FloatTensor(X_test)
            y_test_tensor = torch.LongTensor(y_test)

            # 1. Create PyTorch TensorDataset
            pytorch_train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
            pytorch_test_dataset = TensorDataset(X_test_tensor, y_test_tensor)

            # 2. Use make_classification_dataset following the doc example
            # train_task_dataset = make_classification_dataset(pytorch_train_dataset, task_labels=i)
            # test_task_dataset = make_classification_dataset(pytorch_test_dataset, task_labels=i)

            # 修改：使用 AvalancheDataset 和 DataAttribute
            train_task_dataset = AvalancheDataset(
                [pytorch_train_dataset], # Pass as a list of datasets
                data_attributes=[
                    DataAttribute(y_train_tensor.tolist(), name='targets'),
                    DataAttribute([i] * len(y_train_tensor), name='targets_task_labels', use_in_getitem=True)
                ]
            )
            test_task_dataset = AvalancheDataset(
                [pytorch_test_dataset], # Pass as a list of datasets
                data_attributes=[
                    DataAttribute(y_test_tensor.tolist(), name='targets'),
                    DataAttribute([i] * len(y_test_tensor), name='targets_task_labels', use_in_getitem=True)
                ]
            )

            # --- 新增：将自定义 collate_fn 附加到数据集 ---
            train_task_dataset.collate_fn = pad_collate_fn
            test_task_dataset.collate_fn = pad_collate_fn
            # ----------------------------------------------

            train_datasets.append(train_task_dataset)
            test_datasets.append(test_task_dataset)

        if not train_datasets:
            raise ValueError("未能加载任何UCR数据集，无法创建基准。")

        # MODIFIED: Correctly call benchmark_from_datasets
        benchmark = benchmark_from_datasets(
            train_stream=train_datasets, # Use 'train_stream' as the keyword
            test_stream=test_datasets   # Use 'test_stream' as the keyword
        )
        # 应用装饰器以添加分类相关的属性到经验中
        benchmark = with_classes_timeline(benchmark)

        print(f"UCR基准创建完成。Input channels: {input_channels}, Sequence length: {sequence_length}, Initial classes: {n_initial_classes}")
        return benchmark, input_channels, sequence_length, n_initial_classes
    
    else:
        raise ValueError(f"未知的基准名称: {benchmark_name}")

# Avalanche strategies dictionary
avalanche_strategies = {
    "Naive": Naive,
    "Cumulative": Cumulative,
    "EWC": EWC,
    "GEM": GEM,
    "AGEM": AGEM,
    "Replay": Replay,
    "ER_ACE": ER_ACE,
    "LFL": LFL,
    "SI": SynapticIntelligence
}

class PatchedCumulative(Cumulative):
    def __init__(self, model_ref, **kwargs):
        super().__init__(**kwargs)
        self.model_ref = model_ref # Store a reference to the model

    def criterion(self):
        """
        Only compute loss for samples belonging to the current task.
        """
        if not hasattr(self.model_ref, 'current_task_id') or self.model_ref.current_task_id is None:
            # Fallback to default behavior if current_task_id is not set
            return super().criterion()

        try:
            # Ensure mb_task_id is a tensor and on the same device as mb_y
            # self.mb_task_id is populated by _unpack_minibatch if available in self.mbatch[2]
            # It should be a tensor of task IDs for each sample in the batch.
            if not isinstance(self.mb_task_id, torch.Tensor):
                # This case should ideally not happen if data is prepared correctly by Avalanche
                # Or if the replay buffer correctly stores and yields task IDs.
                # If mb_task_id is not a tensor, we cannot reliably filter.
                # print("[PatchedCumulative CRITERION] mb_task_id is not a tensor. Falling back to super().criterion()")
                return super().criterion()

            # Ensure model_ref.current_task_id is an int for comparison
            current_task_id_val = int(self.model_ref.current_task_id)
            
            # Create a boolean mask for samples belonging to the current task
            # Ensure mb_task_id is on the same device as mb_y for comparison and masking
            mask = (self.mb_task_id.to(self.mb_y.device) == current_task_id_val)

            if not mask.any():
                # No samples for the current task in this batch (e.g., batch is purely replay from other tasks)
                # In this case, loss should be zero as current head is not trained.
                return torch.tensor(0.0, device=self.device, requires_grad=True)

            masked_mb_output = self.mb_output[mask]
            masked_mb_y = self.mb_y[mask]

            if masked_mb_output.size(0) == 0:
                # This should be caught by 'not mask.any()' but as a safeguard.
                return torch.tensor(0.0, device=self.device, requires_grad=True)
            
            # print(f"[PatchedCumulative CRITERION] Current task: {current_task_id_val}, "
            #       f"Original batch size: {self.mb_y.size(0)}, "
            #       f"Masked batch size: {masked_mb_y.size(0)}")
            # print(f"mb_task_id unique: {torch.unique(self.mb_task_id)}")
            # print(f"mb_y unique before mask: {torch.unique(self.mb_y)}")
            # if masked_mb_y.numel() > 0:
            #    print(f"masked_mb_y unique: {torch.unique(masked_mb_y)}")


            return self._criterion(masked_mb_output, masked_mb_y)
        
        except Exception as e:
            # print(f"[PatchedCumulative CRITERION] Error during patched criterion: {e}. Falling back.")
            # import traceback
            # traceback.print_exc()
            return super().criterion()

class PatchedNaiveForReplay(Naive): # 新增：为 Replay 打补丁的 Naive 版本
    def __init__(self, model_ref, **kwargs):
        super().__init__(**kwargs)
        self.model_ref = model_ref

    def criterion(self):
        if not hasattr(self.model_ref, 'current_task_id') or self.model_ref.current_task_id is None:
            return super().criterion()
        try:
            if not isinstance(self.mb_task_id, torch.Tensor):
                return super().criterion()
            current_task_id_val = int(self.model_ref.current_task_id)
            mask = (self.mb_task_id.to(self.mb_y.device) == current_task_id_val)
            if not mask.any():
                return torch.tensor(0.0, device=self.device, requires_grad=True)
            masked_mb_output = self.mb_output[mask]
            masked_mb_y = self.mb_y[mask]
            if masked_mb_output.size(0) == 0:
                return torch.tensor(0.0, device=self.device, requires_grad=True)
            return self._criterion(masked_mb_output, masked_mb_y)
        except Exception as e:
            return super().criterion()

# --- 新增：自定义 EWC 插件 ---
class CustomEWCPlugin(EWCPlugin):
    def after_training_exp(self, strategy: 'BaseStrategy', **kwargs):
        # 保存模型当前的状态 (train 还是 eval)
        was_training = strategy.model.training
        # 在计算重要性之前，强制设置为 train 模式
        strategy.model.train()
        # print("[CustomEWCPlugin] Set model to TRAIN mode before computing importances.")

        # 保存 cuDNN 的原始状态并在计算重要性期间禁用它
        cudnn_enabled_before = torch.backends.cudnn.enabled
        torch.backends.cudnn.enabled = False
        # print("[CustomEWCPlugin] Temporarily disabled cuDNN for EWC importance calculation.")
        
        try:
            # 调用父类的 after_training_exp 来执行实际的重要性计算
            super().after_training_exp(strategy, **kwargs)
        finally:
            # 确保 cuDNN 状态总是被恢复，即使上面发生错误
            torch.backends.cudnn.enabled = cudnn_enabled_before
            # print(f"[CustomEWCPlugin] Restored cuDNN enabled state to: {cudnn_enabled_before}.")

            # 恢复模型之前的状态
            if not was_training:
                strategy.model.eval()
                # print("[CustomEWCPlugin] Restored model to EVAL mode after computing importances.")
            # else:
                # print("[CustomEWCPlugin] Model was already in TRAIN mode, kept it that way.")
# --- 自定义 EWC 插件结束 ---

def run_experiment(strategy_name, benchmark, model, optimizer, criterion, device, args):
    """使用指定策略运行 CL 实验"""
    loggers = [InteractiveLogger()]
    if args.log_text:
        loggers.append(TextLogger(open(f'{strategy_name}_log.txt', 'a', encoding='utf-8')))
    if args.log_tb:
        loggers.append(TensorboardLogger(tb_log_dir=f'tb_logs/{strategy_name}'))

    eval_plugin = EvaluationPlugin(
        accuracy_metrics(minibatch=False, epoch=True, experience=True, stream=True),
        loss_metrics(minibatch=False, epoch=True, experience=True, stream=True),
        forgetting_metrics(experience=True, stream=True),
        cpu_usage_metrics(experience=True),
        timing_metrics(epoch=True, experience=True),
        ram_usage_metrics(experience=True),
        loggers=loggers
    )

    # 实例化插件并添加到基础列表
    task_label_plugin = SetTaskLabelPlugin()
    base_plugins = [task_label_plugin]

    cl_strategy = None

    if strategy_name == 'Naive':
        current_plugins = base_plugins
        cl_strategy = Naive(
            model=model,
            optimizer=optimizer,
            criterion=criterion,
            train_mb_size=args.batch_size,
            train_epochs=args.epochs,
            eval_mb_size=args.batch_size,
            device=device,
            evaluator=eval_plugin,
            plugins=current_plugins # 传递插件
        )
    elif strategy_name == 'EWC':
        current_plugins = base_plugins + [CustomEWCPlugin(ewc_lambda=args.ewc_lambda)]
        cl_strategy = Naive( # EWC 通常也是在 Naive 基础上加插件
            model=model,
            optimizer=optimizer,
            criterion=criterion,
            train_mb_size=args.batch_size,
            train_epochs=args.epochs,
            eval_mb_size=args.batch_size,
            device=device,
            evaluator=eval_plugin,
            plugins=current_plugins # 传递插件
        )
    elif strategy_name == 'Replay':
        print("Using PatchedNaiveForReplay strategy for 'Replay' to handle replay loss.") # 修改日志
        storage_policy = ExperienceBalancedBuffer(max_size=args.memory_size)
        current_plugins = base_plugins + [ReplayPlugin(mem_size=args.memory_size, storage_policy=storage_policy)]
        cl_strategy = PatchedNaiveForReplay( # 使用 PatchedNaiveForReplay
            model_ref=model,        # 传递 model_ref
            model=model,
            optimizer=optimizer,
            criterion=criterion,
            train_mb_size=args.batch_size,
            train_epochs=args.epochs,
            eval_mb_size=args.batch_size,
            device=device,
            evaluator=eval_plugin,
            plugins=current_plugins
        )
    elif strategy_name == 'Cumulative':
        print("Using PatchedCumulative strategy for 'Cumulative' to handle replay loss.")
        # Ensure all necessary parameters for Cumulative are passed.
        # Cumulative might take specific args like `repla_mem_size`.
        # Check Avalanche's Cumulative signature.
        # From Avalanche: Cumulative(model, optimizer, criterion, train_mb_size=1, train_epochs=1, eval_mb_size=None, device=None, plugins=None, evaluator=None, eval_every=-1, **base_kwargs)
        cl_strategy = PatchedCumulative(
            model_ref=model, # Pass the model reference for the patch
            model=model, 
            optimizer=optimizer, 
            criterion=criterion, 
            train_mb_size=args.batch_size, 
            train_epochs=args.epochs, 
            device=device, 
            plugins=base_plugins,
            evaluator=eval_plugin, # Assuming evaluation_plugin() is defined
            eval_every=1 # Evaluate after each experience
        )
    else:
        raise ValueError(f"未知策略: {strategy_name}")

    print(f"\n--- 开始训练: {strategy_name} ---")
    results = []

    for experience in benchmark.streams['train_stream']:
        print(f">>> 经验开始: {experience.current_experience} <<<")
        print(f"当前经验中的类: {experience.classes_in_this_experience}")

        # 动态添加分类器头 - 直接从当前经验获取 task_id
        current_exp_task_id = -1 # 初始化以防万一
        if hasattr(experience, 'task_label'): # 应由 with_classes_timeline 设置
            current_exp_task_id = experience.task_label
        elif hasattr(experience, 'dataset') and hasattr(experience.dataset, 'targets_task_labels'):
            task_labels_attr = experience.dataset.targets_task_labels
            # 确保 task_labels_attr 是 DataAttribute 并且其 .data 属性不为空
            if isinstance(task_labels_attr, DataAttribute) and hasattr(task_labels_attr, 'data') and task_labels_attr.data:
                current_exp_task_id = task_labels_attr.data[0] # 访问 .data 属性的第一个元素
                print(f"[RUN_EXPERIMENT] Info: Used fallback to experience.dataset.targets_task_labels.data[0] to get task_id: {current_exp_task_id} for exp {experience.current_experience}")
            else:
                print(f"[RUN_EXPERIMENT] CRITICAL WARNING: 'targets_task_labels' found but not a valid/non-empty DataAttribute for exp {experience.current_experience}. Defaulting to 0.")
                current_exp_task_id = 0 
        else:
            # 这个情况理论上不应该发生，因为我们创建UCR基准时明确赋予了task_labels，并且应用了with_classes_timeline
            print(f"[RUN_EXPERIMENT] CRITICAL WARNING: Could not determine task_id for exp {experience.current_experience}. Defaulting to 0. This may lead to errors.")
            current_exp_task_id = 0 

        print(f"[RUN_EXPERIMENT] Before head check for training exp {experience.current_experience}: model has {len(model.task_classifiers)} heads. Determined task_id for this exp: {current_exp_task_id}")

        # 检查是否需要为当前任务ID添加新头
        if current_exp_task_id >= len(model.task_classifiers): 
            num_classes_in_task = len(experience.classes_in_this_experience)
            if current_exp_task_id == len(model.task_classifiers):
                print(f"[RUN_EXPERIMENT] Adding new head for task {current_exp_task_id} with {num_classes_in_task} classes, as model has {len(model.task_classifiers)} heads.")
                model.add_task_classifier(num_classes_in_task, device)
                print(f"[RUN_EXPERIMENT] Added head for task {current_exp_task_id}. Model now has {len(model.task_classifiers)} heads.")
                print("[RUN_EXPERIMENT] Re-creating optimizer for the strategy to include new head parameters.")
                optimizer = optim.Adam(model.parameters(), lr=args.lr) 
                cl_strategy.optimizer = optimizer 
            else:
                print(f"[RUN_EXPERIMENT] Warning/Error: Task ID {current_exp_task_id} seems to be out of sequence or head already exists. Current heads: {len(model.task_classifiers)}.")

        # SetTaskLabelPlugin 将在 cl_strategy.train() 内部的 before_training_exp 回调中
        # 使用 experience.task_label (或回退逻辑) 来设置 model.current_task_id
        # 这个 model.current_task_id 会被 model.forward() 使用
        print(f"-- >> Training on exp {experience.current_experience} for task {current_exp_task_id} (model.current_task_id will be set by plugin inside strategy.train) << --")
        cl_strategy.train(experience)
        print(f"<<< 经验结束: {experience.current_experience} >>>")

    print(f"--- 所有训练经验完成: {strategy_name} ---")

    # 在所有训练经验完成后，进行一次最终评估
    print(f"--- 开始对策略 {strategy_name} 进行最终评估 (在所有训练经验之后) ---")
    final_evaluation_results = cl_strategy.eval(benchmark.streams['test_stream'])
    
    # --- 新增：打印详细的最终评估结果 --- 
    print(f"--- [DEBUG] Detailed final evaluation results for strategy: {strategy_name} ---")
    import pprint
    pp = pprint.PrettyPrinter(indent=2)
    pp.pprint(final_evaluation_results)
    print(f"--- [END DEBUG] Detailed final evaluation results for strategy: {strategy_name} ---")
    # -------------------------------------

    # results 列表现在只包含这一次最终评估的结果
    # 如果需要每次经验后的评估，需要采用不同的结构
    results.append(final_evaluation_results) 

    # --- 新增：打印最终指标摘要 --- (这部分逻辑现在基于results中的最后一个（也是唯一一个）元素)
    if results:
        print(f"\n--- Final Summary for Strategy: {strategy_name} ---")
        final_metrics = results[-1] # 获取最后一次评估的指标

        # 1. 准确性和遗忘度
        print("\n  Performance Metrics:") 
        # 尝试匹配日志中的实际键名
        final_avg_acc_metric_key_actual = 'Top1_Acc_Stream/eval_phase/test_stream_stream' 
        if final_avg_acc_metric_key_actual in final_metrics:
            print(f"  Final Average Accuracy (all tasks): {final_metrics[final_avg_acc_metric_key_actual]:.4f}")
        else:
            # 如果上面的键没有找到，再尝试之前代码中的键（以防万一配置或版本变化）
            original_acc_key = 'Top1_Acc_Stream/eval_phase/test_stream/'
            if original_acc_key in final_metrics:
                print(f"  Final Average Accuracy (all tasks): {final_metrics[original_acc_key]:.4f}")
            else:
                print(f"  Final Average Accuracy (all tasks): Metric not found (checked {final_avg_acc_metric_key_actual} and {original_acc_key})")

        # 平均遗忘度 (BWT)
        # 尝试匹配日志中的实际键名
        avg_forgetting_metric_key_actual = 'StreamForgetting/eval_phase/test_stream_stream' 
        if avg_forgetting_metric_key_actual in final_metrics:
            print(f"  Average Forgetting (BWT): {final_metrics[avg_forgetting_metric_key_actual]:.4f}")
        else:
            original_forgetting_key = 'StreamForgetting/eval_phase/test_stream' # Avalanche 0.5+
            compat_forgetting_key_old = 'Forgetting_Stream/eval_phase/test_stream/'
            if original_forgetting_key in final_metrics:
                 print(f"  Average Forgetting (BWT): {final_metrics[original_forgetting_key]:.4f}")
            elif compat_forgetting_key_old in final_metrics:
                print(f"  Average Forgetting (BWT): {final_metrics[compat_forgetting_key_old]:.4f}")
            else:
                print(f"  Average Forgetting (BWT): Metric not found (checked {avg_forgetting_metric_key_actual}, {original_forgetting_key}, {compat_forgetting_key_old})")

        print("  Final Per-Task Accuracies (after all experiences):")
        num_experiences = len(benchmark.streams['train_stream']) # MODIFIED HERE
        for task_id in range(num_experiences):
            # Metric key for per-task accuracy after all experiences
            # The last ExpXXX in the key refers to the evaluation point (after which training experience)
            # Since we evaluate once after all training, it should be num_experiences - 1
            # Example: Task000/Exp009 if there are 10 experiences (0-9)
            metric_name = f'Top1_Acc_Exp/eval_phase/test_stream_stream/Task{task_id:03d}/Exp{num_experiences-1:03d}'
            if metric_name in final_metrics:
                print(f"    Task {task_id} Accuracy: {final_metrics[metric_name]:.4f}")
            else:
                print(f"    Task {task_id} Accuracy: Metric not found ({metric_name})")
        
        # 2. 计算效率指标
        print("\n  Efficiency Metrics:")
        num_experiences = len(benchmark.streams['train_stream']) # MODIFIED HERE

        # CPU 使用率
        # Avalanche v0.5+ 通常使用 'CPUUsage_Experience/eval_phase/test_stream' 
        # 当 EvaluationPlugin 中的 metric 设置为 experience=True (stream=True 也是常见组合)
        cpu_usage_key = 'CPUUsage_Experience/eval_phase/test_stream' 
        if cpu_usage_key in final_metrics:
            print(f"  CPU Usage (at final evaluation): {final_metrics[cpu_usage_key]}%")
        else:
            # 备用键，以防metric名称略有不同或来自旧版
            alt_cpu_key = f'CPUUsage_Exp/eval_phase/test_stream/Exp{num_experiences-1:03d}'
            if alt_cpu_key in final_metrics:
                print(f"  CPU Usage (at final evaluation): {final_metrics[alt_cpu_key]}%")
            else:
                print(f"  CPU Usage (at final evaluation): Metric not found (e.g., {cpu_usage_key} or {alt_cpu_key})")

        # RAM 使用率
        ram_usage_key = 'RAMUsage_Experience/eval_phase/test_stream'
        if ram_usage_key in final_metrics:
            print(f"  RAM Usage (at final evaluation): {final_metrics[ram_usage_key]} MB")
        else:
            alt_ram_key = f'RAMUsage_Exp/eval_phase/test_stream/Exp{num_experiences-1:03d}'
            if alt_ram_key in final_metrics:
                 print(f"  RAM Usage (at final evaluation): {final_metrics[alt_ram_key]} MB")
            else:
                print(f"  RAM Usage (at final evaluation): Metric not found (e.g., {ram_usage_key} or {alt_ram_key})")
        
        print("  (Detailed timing, CPU, and RAM usage metrics over all experiences are available in the log files and TensorBoard.)")
        print("--- End of Summary ---\n")
    # --- 摘要结束 ---
    
    return results

def main(args):
    # 设置种子
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(args.seed)

    # 设置设备
    device = torch.device(f"cuda:{args.cuda}" if torch.cuda.is_available() and args.cuda >= 0 else "cpu")
    print(f"使用设备: {device}")

    # 创建基准
    # 修改这里以允许选择基准并在创建时获取维度
    print(f"准备 {args.benchmark_name} 基准...")
    benchmark, input_channels, sequence_length, n_initial_classes = create_benchmark(
        benchmark_name=args.benchmark_name, 
        n_experiences_mnist=args.mnist_experiences, # 需要添加这个argparse参数
        seed=args.seed,
        data_dir=args.data_dir # 需要添加这个argparse参数
    )
    print("基准准备完毕。")
    
    # n_initial_classes 已经从 create_benchmark 返回
    print(f"从基准获取的初始类别数: {n_initial_classes}")
    print(f"从基准获取的Input channels: {input_channels}")
    print(f"从基准获取的Sequence length: {sequence_length}")

    # Removed the Non-CL Baseline Computation Loop
    # baseline_accuracies_map is no longer computed here
    baseline_accuracies_map = {} # Keep empty map for plot function compatibility, but it won't be filled
    task_names_for_plotting = []

    # Determine task names based on benchmark type
    if args.benchmark_name == "ucr_timeseries":
        task_names_for_plotting = UCR_DATASET_NAMES[:len(benchmark.streams['train_stream'])]
    elif args.benchmark_name == "split_mnist":
        task_names_for_plotting = [f"MNIST Exp {i}" for i in range(len(benchmark.streams['train_stream']))]
    else:
        task_names_for_plotting = [f"Task {i}" for i in range(len(benchmark.streams['train_stream']))]

    all_cl_results = {}
    criterion = nn.CrossEntropyLoss()
    for strategy_name in args.strategies:
        print(f"\n重置模型和优化器以运行策略: {strategy_name}")
        # 每次策略运行时，都重新初始化模型，以确保状态纯净
        cl_model = CNN_BiGRU_Attention(
            input_channels=input_channels, 
            sequence_length=sequence_length, 
            num_classes_initial=n_initial_classes, # Use n_initial_classes from benchmark
            num_multiscale_paths=args.num_multiscale_paths,
            final_dropout_rate=args.final_dropout_rate,
            gru_hidden_size=args.gru_hidden_size,
            num_gru_layers=args.num_gru_layers,
            adaptive_pool_output_size=args.adaptive_pool_output_size
        ).to(device)
        cl_optimizer = optim.Adam(cl_model.parameters(), lr=args.lr)
        results = run_experiment(strategy_name, benchmark, cl_model, cl_optimizer, criterion, device, args)
        all_cl_results[strategy_name] = results

    print("\n--- All CL experiments finished ---")

    # --- 保存所有策略的最终结果 ---
    os.makedirs(args.results_log_dir, exist_ok=True)
    cl_results_file = os.path.join(args.results_log_dir, "cl_strategies_summary.json")
    try:
        with open(cl_results_file, 'w', encoding='utf-8') as f:
            json.dump(all_cl_results, f, indent=4)
        print(f"所有持续学习策略的摘要结果已保存到: {cl_results_file}")
    except Exception as e:
        print(f"错误：无法保存持续学习结果到 '{cl_results_file}': {e}")

    # --- 加载基线结果并绘制比较图 ---
    num_experiences_in_benchmark = len(benchmark.streams['train_stream'])

    if not all_cl_results:
        print("No CL results to plot.")
    else:
        print(f"准备为 {len(all_cl_results)} 个策略绘制比较图表。图表将保存到: {args.plots_output_dir}")
        plot_comparison_results(
            all_cl_results, 
            num_experiences_in_benchmark, 
            task_names_for_plotting,
            baseline_accuracies_map, # Pass the empty map
            args.plots_output_dir
        )

    print("\n--- 脚本执行完毕 ---")

def train_model(model, X_train, y_train, X_val=None, y_val=None, batch_size=32, num_epochs=100, learning_rate=0.001):
    """训练模型并返回训练历史，使用tqdm显示进度"""
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)
    X_train_tensor = torch.FloatTensor(X_train)
    y_train_tensor = torch.LongTensor(y_train)
    train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
    train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    criterion = nn.CrossEntropyLoss()
    history = {'train_loss': [], 'train_acc': [], 'val_loss': [], 'val_acc': []}
    
    epoch_pbar = tqdm(range(num_epochs), desc="Epochs", leave=True) # Simplified desc
    for epoch in epoch_pbar:
        model.train()
        running_loss = 0.0; correct_predictions = 0; total_samples = 0
        train_pbar = tqdm(train_loader, desc=f"Epoch {epoch+1}/{num_epochs} [Train]", leave=False) # Simplified desc
        for batch_X, batch_y in train_pbar:
            batch_X, batch_y = batch_X.to(device), batch_y.to(device)
            optimizer.zero_grad()
            # Simplified model call - assumes model handles single/multi-head internally or is only used in non-CL context here
            outputs = model(batch_X) 
            loss = criterion(outputs, batch_y)
            loss.backward(); optimizer.step()
            running_loss += loss.item() * batch_X.size(0)
            _, predicted = torch.max(outputs.data, 1)
            total_samples += batch_y.size(0)
            correct_predictions += (predicted == batch_y).sum().item()
            train_pbar.set_postfix({'loss': f'{running_loss / total_samples:.4f}', 'acc': f'{correct_predictions / total_samples:.4f}'})
        epoch_train_loss = running_loss / total_samples
        epoch_train_acc = correct_predictions / total_samples
        history['train_loss'].append(epoch_train_loss); history['train_acc'].append(epoch_train_acc)

        if X_val is not None and y_val is not None:
            X_val_tensor = torch.FloatTensor(X_val)
            y_val_tensor = torch.LongTensor(y_val)
            val_dataset = TensorDataset(X_val_tensor, y_val_tensor)
            val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=batch_size)
            model.eval(); val_loss = 0.0; val_correct = 0; val_total = 0
            val_pbar = tqdm(val_loader, desc=f"Epoch {epoch+1}/{num_epochs} [Val]", leave=False) # Simplified desc
            with torch.no_grad():
                for batch_X_val, batch_y_val in val_pbar:
                    batch_X_val, batch_y_val = batch_X_val.to(device), batch_y_val.to(device)
                    # Simplified model call
                    outputs_val = model(batch_X_val)
                    loss_val = criterion(outputs_val, batch_y_val)
                    val_loss += loss_val.item() * batch_X_val.size(0)
                    _, predicted_val = torch.max(outputs_val.data, 1)
                    val_total += batch_y_val.size(0)
                    val_correct += (predicted_val == batch_y_val).sum().item()
                    val_pbar.set_postfix({'val_loss': f'{val_loss / val_total:.4f}', 'val_acc': f'{val_correct / val_total:.4f}'})
            epoch_val_loss = val_loss / val_total; epoch_val_acc = val_correct / val_total
            history['val_loss'].append(epoch_val_loss); history['val_acc'].append(epoch_val_acc)
            epoch_pbar.set_postfix({'Train Loss': f'{epoch_train_loss:.4f}', 'Train Acc': f'{epoch_train_acc:.4f}', 'Val Loss': f'{epoch_val_loss:.4f}', 'Val Acc': f'{epoch_val_acc:.4f}'})
        else: 
            epoch_pbar.set_postfix({'Train Loss': f'{epoch_train_loss:.4f}', 'Train Acc': f'{epoch_train_acc:.4f}'})
            history['val_loss'].append(None) 
            history['val_acc'].append(None)
    return history

def evaluate_model(model, X_test, y_test, batch_size=32):
    """评估模型并返回测试损失、准确率和预测结果，使用tqdm显示进度"""
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device); model.eval()
    X_test_tensor = torch.FloatTensor(X_test); y_test_tensor = torch.LongTensor(y_test)
    test_dataset = TensorDataset(X_test_tensor, y_test_tensor)
    test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=batch_size)
    criterion = nn.CrossEntropyLoss()
    test_loss = 0.0; test_correct = 0; test_total = 0; all_predictions = []
    eval_pbar = tqdm(test_loader, desc="Evaluating", leave=False) # Simplified desc
    with torch.no_grad():
        for batch_X, batch_y in eval_pbar:
            batch_X, batch_y = batch_X.to(device), batch_y.to(device)
            # Simplified model call
            outputs = model(batch_X)
            loss = criterion(outputs, batch_y)
            test_loss += loss.item() * batch_X.size(0)
            _, predicted = torch.max(outputs.data, 1)
            test_total += batch_y.size(0)
            test_correct += (predicted == batch_y).sum().item()
            all_predictions.extend(predicted.cpu().numpy())
            eval_pbar.set_postfix({'loss': f'{test_loss / test_total:.4f}', 'acc': f'{test_correct / test_total:.4f}'})
    final_test_loss = test_loss / test_total
    final_test_acc = test_correct / test_total
    return final_test_loss, final_test_acc, all_predictions

# Modified plot_comparison_results to remove baseline plotting
def plot_comparison_results(cl_results_dict, num_tasks_in_benchmark, task_names_for_x_axis, 
                             baseline_task_accuracies_map, # Still accepts map, but won't use it if empty
                             output_plot_dir):
    os.makedirs(output_plot_dir, exist_ok=True)
    strategies = list(cl_results_dict.keys())
    
    # --- 1. Plot Average Accuracy (CL Strategies Only) ---
    avg_accuracies_cl = []
    valid_strategies_avg = []
    for strategy in strategies:
        if not cl_results_dict[strategy]: continue
        metrics = cl_results_dict[strategy][0]
        key1 = 'Top1_Acc_Stream/eval_phase/test_stream_stream'
        key2 = 'Top1_Acc_Stream/eval_phase/test_stream/'
        if key1 in metrics: avg_accuracies_cl.append(metrics[key1]); valid_strategies_avg.append(strategy)
        elif key2 in metrics: avg_accuracies_cl.append(metrics[key2]); valid_strategies_avg.append(strategy)
        # else: Skip strategy if average accuracy key not found
    
    if not valid_strategies_avg: 
        print("No average accuracy data found for any CL strategy to plot.")
        return # Exit plotting if no data
        
    plt.figure(figsize=(max(6, len(valid_strategies_avg) * 1.5), 5))
    bars = plt.bar(valid_strategies_avg, avg_accuracies_cl, color=['skyblue', 'lightgreen', 'salmon', 'gold', 'lightcoral'][:len(valid_strategies_avg)])
    plt.ylabel('Average Accuracy'); plt.title('Average Accuracy Comparison (CL Strategies)')
    plt.ylim(0, 1.05)
    for bar in bars: yval = bar.get_height(); plt.text(bar.get_x() + bar.get_width()/2.0, yval + 0.01, f'{yval:.3f}', ha='center', va='bottom')
    plt.xticks(rotation=15, ha="right"); plt.tight_layout()
    avg_plot_path = os.path.join(output_plot_dir, 'average_accuracy_comparison_cl_only.png') # Changed filename
    plt.savefig(avg_plot_path)
    print(f"Average CL accuracy comparison plot saved to: {avg_plot_path}"); plt.close()

    # --- 2. Plot Per-Task Accuracy (CL Strategies Only) ---
    per_task_accuracies_cl = {strategy: [] for strategy in strategies}
    has_per_task_data = False
    for task_idx in range(num_tasks_in_benchmark):
        for strategy in strategies:
            if not cl_results_dict[strategy]: 
                 per_task_accuracies_cl.setdefault(strategy, []).append(0.0)
                 continue
            metrics = cl_results_dict[strategy][0]
            metric_name = f'Top1_Acc_Exp/eval_phase/test_stream_stream/Exp{task_idx:03d}'
            if metric_name in metrics:
                per_task_accuracies_cl.setdefault(strategy, []).append(metrics[metric_name])
                if metrics[metric_name] > 0: has_per_task_data = True # Mark if we found any data > 0
            else: 
                per_task_accuracies_cl.setdefault(strategy, []).append(0.0)
    
    if not has_per_task_data:
        print("No per-task accuracy data > 0 found for any CL strategy to plot.")
        return # Don't plot if all values are 0

    x = np.arange(num_tasks_in_benchmark)
    num_groups = len(strategies) 
    width = 0.8 / num_groups if num_groups > 0 else 0.8 
    fig, ax = plt.subplots(figsize=(max(12, num_tasks_in_benchmark * 1.8), 7))
    rects_list = []; total_width_of_group = num_groups * width; start_offset = -total_width_of_group / 2 + width / 2
    for i, strategy in enumerate(strategies):
        offset = start_offset + i * width
        # Ensure list has correct length, padding with 0 if necessary (shouldn't be needed now)
        acc_list = per_task_accuracies_cl.get(strategy, [0.0]*num_tasks_in_benchmark)
        rects = ax.bar(x + offset, acc_list[:num_tasks_in_benchmark], width, label=strategy); rects_list.append(rects)
    
    ax.set_ylabel('Accuracy'); ax.set_title('Per-Task Accuracy Comparison (CL Strategies)')
    ax.set_xticks(x); ax.set_xticklabels([name[:20] for name in task_names_for_x_axis[:num_tasks_in_benchmark]], rotation=45, ha="right")
    ax.legend(loc='best', bbox_to_anchor=(1.05, 1), borderaxespad=0.); ax.set_ylim(0, 1.1)
    def autolabel(rects_group):
        for rect in rects_group:
            height = rect.get_height()
            if height > 0: # Only label non-zero bars
                ax.annotate(f'{height:.2f}', xy=(rect.get_x() + rect.get_width() / 2, height), xytext=(0, 3), textcoords="offset points", ha='center', va='bottom', fontsize=7, rotation=90)
    for r_list_item in rects_list: autolabel(r_list_item)
    fig.tight_layout(rect=[0, 0, 0.85, 1]); 
    per_task_plot_path = os.path.join(output_plot_dir, 'per_task_accuracy_comparison_cl_only.png') # Changed filename
    plt.savefig(per_task_plot_path)
    print(f"Per-task CL accuracy comparison plot saved to: {per_task_plot_path}"); plt.close()

if __name__ == "__main__":
    # --- 添加的第一个打印语句 ---
    print("--- Script execution started in __main__ block ---")

    parser = argparse.ArgumentParser(description='持续学习时间序列（或演示）实验')

    # 实验参数
    parser.add_argument('--benchmark_name', type=str, default='ucr_timeseries', 
                        choices=['ucr_timeseries', 'split_mnist'], help='要使用的基准名称')
    parser.add_argument('--data_dir', type=str, default='dataset', help='UCR数据集的根目录')
    parser.add_argument('--mnist_experiences', type=int, default=5, help='如果是SplitMNIST，则为经验数量')
    parser.add_argument('--strategies', nargs='+', type=str, default=['Naive', 'EWC', 'Replay'],  # LwF removed from default
                        choices=['Naive', 'EWC', 'Replay', 'Cumulative', 'GEM', 'AGEM', 'ER_ACE', 'LFL', 'SI'], # LwF removed from choices
                        help='要运行的持续学习策略列表')
    parser.add_argument('--log_text', action='store_true', help='将日志输出到文本文件')
    parser.add_argument('--log_tb', action='store_true', help='将日志输出到TensorBoard')
    parser.add_argument('--results_log_dir', type=str, default='experiment_results', help='保存JSON格式实验结果的目录')
    parser.add_argument('--plots_output_dir', type=str, default='plots_from_results', help='保存生成图表的目录')

    # 模型和训练参数
    parser.add_argument('--lr', type=float, default=0.001, help='学习率')
    parser.add_argument('--epochs', type=int, default=10, help='每个经验的训练轮数') # 根据需要调整
    parser.add_argument('--batch_size', type=int, default=32, help='批量大小')

    # 模型特定架构参数 (新增)
    parser.add_argument('--num_multiscale_paths', type=int, default=4, 
                        help='MultiScaleFeatureExtraction中的并行卷积路径数')
    parser.add_argument('--final_dropout_rate', type=float, default=0.4, 
                        help='最终分类器前的Dropout率 (根据报告建议0.4)')
    parser.add_argument('--gru_hidden_size', type=int, default=128, help='GRU的隐藏层大小')
    parser.add_argument('--num_gru_layers', type=int, default=2, help='GRU的层数')
    parser.add_argument('--adaptive_pool_output_size', type=int, default=50, help='AdaptiveAvgPool1d的输出大小')

    # CL 策略特定参数
    parser.add_argument('--ewc_lambda', type=float, default=0.4, help='EWC的lambda惩罚系数')
    parser.add_argument('--memory_size', type=int, default=200, help='Replay策略的缓冲区大小')

    # 其他
    parser.add_argument('--cuda', type=int, default=0, help='使用的CUDA设备ID (如果可用,否则使用CPU)')
    parser.add_argument('--seed', type=int, default=42, help='随机种子')

    # --- 添加的最后一个打印语句 ---
    print("--- Script execution finished __main__ block ---")

    # --- 定义硬编码的默认参数 ---
    # 当直接在 PyCharm 中点击运行时 (即没有命令行参数时)，将使用这些值。
    # 您可以根据需要在此处修改这些默认值。
    pycharm_default_params = {
        'benchmark_name': 'ucr_timeseries', 'data_dir': 'dataset', 'mnist_experiences': 5,
        'strategies': ['Naive', 'EWC', 'Replay'], 'log_text': False, 'log_tb': False,
        'results_log_dir': 'experiment_results', 'plots_output_dir': 'plots_from_results',
        'lr': 0.001, 'epochs': 10, 
        'batch_size': 32, 'num_multiscale_paths': 4,
        'final_dropout_rate': 0.4, 'gru_hidden_size': 128, 'num_gru_layers': 2,
        'adaptive_pool_output_size': 50, 'ewc_lambda': 0.4, 'memory_size': 200,
        'cuda': 0, 'seed': 42
    }

    # 如果没有通过命令行传递参数 (例如，在 PyCharm 中直接点击运行)
    # 则使用上面定义的 pycharm_default_params
    # 同时，确保 parser 中定义的任何具有 action='store_true'/'store_false' 的参数
    # 如果在 pycharm_default_params 中未明确设置，则采用其 argparse 默认值
    if len(sys.argv) == 1:
        print("--- No command-line arguments detected. Using PyCharm default parameters. ---")
        # 首先，获取 argparse 解析的默认值
        temp_args = parser.parse_args([]) # 解析一个空列表以获取默认值

        for key, value in pycharm_default_params.items():
            if hasattr(temp_args, key):
                setattr(temp_args, key, value)
            else:
                print(f"[Warning] PyCharm default parameter \'{key}\' not found in argparse definition.")
        
        # 对于 'store_true'/'store_false' 类型的参数，如果未在 pycharm_default_params 中设置，
        # 确保它们保留从 parser.parse_args([]) 中获得的默认值
        for action in parser._actions:
            if action.dest not in pycharm_default_params and (action.const is True or action.const is False):
                 # temp_args 已经有了这些的默认值
                 pass

        args = temp_args # 将修改后的 temp_args 赋给 args
        print(f"--- Using effective PyCharm default args: {args} ---")
    else:
        # 如果有命令行参数，则正常解析它们
        args = parser.parse_args()
        print(f"--- Parsed command-line arguments: {args} ---")


    # --- 调用主函数 ---
    # print("--- Calling main function ---") # 可以取消注释这行来进一步跟踪
    main(args)

    # --- 添加的最后一个打印语句 ---
    print("--- Script execution finished __main__ block ---")