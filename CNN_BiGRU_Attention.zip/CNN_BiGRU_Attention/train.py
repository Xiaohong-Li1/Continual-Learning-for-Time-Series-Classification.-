# -*- coding: utf-8 -*-
import torch
import torch.nn as nn
import torch.optim as optim
# 移除了 DataLoader, TensorDataset，因为 Avalanche 会处理数据集包装
# import numpy as np - 仍然需要
import numpy as np
# from sklearn.model_selection import train_test_split - 在 Avalanche 基准中不使用
from sklearn.preprocessing import StandardScaler # 保留用于可能的自定义数据
# 导入模型
from model import CNN_BiGRU_Attention, MultiHeadMLP # 假设 model.py 在同一目录下
import os
import argparse # 用于命令行参数

# Avalanche 导入
from avalanche.benchmarks.classic import SplitMNIST # 示例基准
# 修改导入路径以解决 ModuleNotFoundError
from avalanche.benchmarks.scenarios.dataset_scenario import benchmark_from_datasets
from avalanche.benchmarks.utils import AvalancheDataset
from load_timeseries_data import load_ucr_dataset # <--- 新增导入

# 正确导入 Naive 策略
from avalanche.training.supervised import Naive # 或者尝试 from avalanche.training import Naive

# 正确导入 EWC 和 Replay 插件
from avalanche.training.plugins import EWCPlugin, ReplayPlugin # Import plugins for strategies

# 从 storage_policy 子模块导入正确的存储策略类
from avalanche.training.storage_policy import ExperienceBalancedBuffer # Example storage policy for Replay

# 导入 LwF 策略 (新增)
from avalanche.training.supervised import LwF 

from avalanche.evaluation.metrics import accuracy_metrics, loss_metrics, forgetting_metrics, cpu_usage_metrics, timing_metrics, ram_usage_metrics
from avalanche.logging import InteractiveLogger, TextLogger, TensorboardLogger
from avalanche.training.plugins import EvaluationPlugin
from torchvision import transforms # 保留，以防仍需 SplitMNIST

# UCR 数据集列表
UCR_DATASET_NAMES = [
    "ArrowHead", "AtrialFibrillation", "BasicMotions", "Beef", "BeetleFly", 
    "BirdChicken", "BME", "Coffee", "DodgerLoopDay", "DodgerLoopGame"
]

def create_benchmark(benchmark_name="ucr_timeseries", n_experiences_mnist=5, seed=42, data_dir='dataset'):
    """
    创建持续学习基准。
    :param benchmark_name: 要创建的基准名称 ('ucr_timeseries' 或 'split_mnist')。
    :param n_experiences_mnist: 如果是 SplitMNIST，则为经验数量。
    :param seed: 随机种子。
    :param data_dir: UCR 数据集所在的目录。
    :return: (benchmark, input_channels, sequence_length, n_initial_classes)
    """
    if benchmark_name == "split_mnist":
        print("准备 SplitMNIST 基准...")
        # 定义 MNIST 的转换
        mnist_transform = transforms.Compose([
            transforms.ToTensor(), # 首先转换为张量
            transforms.Lambda(lambda x: x.float()),
            transforms.Lambda(lambda x: x.squeeze(0)), # 移除通道维度
            transforms.Lambda(lambda x: x.view(28*28))   # 展平为1D序列 (28x28=784)
        ])
        
        benchmark = SplitMNIST(
            n_experiences=n_experiences_mnist,
            seed=seed,
            return_task_id=True, # 对多头很重要
            train_transform=mnist_transform,
            eval_transform=mnist_transform,
            class_ids_from_zero_in_each_exp=True # 每个经验中的类别从0开始编号
        )
        # 对于 MNIST，通道为1，序列长度为 28x28=784 (展平后)
        # 如果不展平，sequence_length 可能是 28 (行数)，input_channels 可能是 28 (列数)
        # 但我们的模型 MQCCAF_TimeSeries 期望 (batch, features, seq_len) 或 (batch, seq_len, features)
        # 根据原始模型设计，它接受 (batch, input_channels, sequence_length)
        # 如果 MNIST 图像是 (1, 28, 28), 展平后是 (784), 
        # 如果模型将 784 视为 sequence_length，则 input_channels = 1
        # 如果模型将 28 视为 sequence_length，则 input_channels = 28 (这更像图像)
        # 从模型来看，input_channels 是特征维度，sequence_length 是时间步数。
        # 对于展平的 MNIST，sequence_length=784, input_channels=1
        input_channels = 1
        sequence_length = 784 
        n_initial_classes = len(benchmark.train_stream[0].dataset.targets.unique())
        print(f"SplitMNIST: input_channels={input_channels}, sequence_length={sequence_length}, n_initial_classes={n_initial_classes}")
        return benchmark, input_channels, sequence_length, n_initial_classes

    elif benchmark_name == "ucr_timeseries":
        print(f"准备 UCR 时间序列基准，包含以下数据集: {UCR_DATASET_NAMES}")
        train_datasets = []
        test_datasets = []
        task_labels_list = [] # 为每个经验（数据集）存储任务标签

        first_dataset = True
        input_channels = -1
        sequence_length = -1
        n_initial_classes = -1

        for i, dataset_name in enumerate(UCR_DATASET_NAMES):
            print(f"加载 UCR 数据集: {dataset_name} (任务 {i})")
            try:
                X_train, y_train, X_test, y_test, classes = load_ucr_dataset(dataset_name, data_dir=data_dir)
            except Exception as e:
                print(f"错误：无法加载数据集 {dataset_name}。跳过。错误信息: {e}")
                continue

            # 确保 X_train 和 X_test 是 3D: (n_samples, n_features, sequence_length)
            # load_ucr_dataset 返回的 X 已经是 (n_samples, sequence_length) 或 (n_samples, sequence_length, n_features)
            # 我们的模型期望 (batch, input_channels/n_features, sequence_length)
            
            if X_train.ndim == 2: # (n_samples, sequence_length) -> 单变量时间序列
                X_train = np.expand_dims(X_train, axis=1) # (n_samples, 1, sequence_length)
                X_test = np.expand_dims(X_test, axis=1)   # (n_samples, 1, sequence_length)
            
            current_n_features = X_train.shape[1]
            current_seq_len = X_train.shape[2]
            num_classes_in_task = len(classes)

            print(f"数据集 {dataset_name}: X_train shape {X_train.shape}, y_train shape {y_train.shape}, n_classes {num_classes_in_task}")

            if first_dataset:
                input_channels = current_n_features
                sequence_length = current_seq_len # 使用第一个数据集的序列长度作为基准
                n_initial_classes = num_classes_in_task
                first_dataset = False
            else:
                # 重要：处理不同序列长度和特征维度的数据集
                # 方案1：报错或警告。当前模型架构可能不支持可变的 seq_len 或 input_channels 跨任务。
                # 方案2：对齐数据 (填充/截断)。这需要在 load_ucr_dataset 或此处实现。
                # 目前，我们假设模型在创建时使用第一个任务的维度，后续任务如果维度不同，需要模型能适应或数据被预处理。
                # 我们的 MQCCAF_TimeSeries 通常期望固定的 input_channels 和 sequence_length。
                # 如果后续数据集的 sequence_length 不同，这会是一个问题。
                # 报告中没有明确提到如何处理不同长度的序列。暂时假设它们需要被统一。
                # 简单起见，这里我们先使用第一个数据集的维度，并打印警告。
                if current_n_features != input_channels:
                    print(f"警告: 数据集 {dataset_name} 的特征数 ({current_n_features}) 与第一个数据集 ({input_channels}) 不同。这可能导致问题。")
                if current_seq_len != sequence_length:
                    print(f"警告: 数据集 {dataset_name} 的序列长度 ({current_seq_len}) 与第一个数据集 ({sequence_length}) 不同。这可能导致问题。")
                    # 考虑是否在此处进行填充/截断以匹配 'sequence_length'
                    # 例如:
                    # if current_seq_len < sequence_length:
                    #     pad_width = ((0,0), (0,0), (0, sequence_length - current_seq_len))
                    #     X_train = np.pad(X_train, pad_width, mode='constant', constant_values=0)
                    #     X_test = np.pad(X_test, pad_width, mode='constant', constant_values=0)
                    # elif current_seq_len > sequence_length:
                    #     X_train = X_train[:, :, :sequence_length]
                    #     X_test = X_test[:, :, :sequence_length]
                    # print(f"调整后 {dataset_name}: X_train shape {X_train.shape}")


            # 将 NumPy 数组转换为 PyTorch 张量
            X_train_tensor = torch.FloatTensor(X_train)
            y_train_tensor = torch.LongTensor(y_train) # load_ucr_dataset 应该已经做了标签编码
            X_test_tensor = torch.FloatTensor(X_test)
            y_test_tensor = torch.LongTensor(y_test)

            # 创建 AvalancheTensorDataset
            # 注意：AvalancheDataset 通常期望目标 (y) 是一维的。
            # 任务标签需要明确提供给 AvalancheDataset
            # class_ids_from_zero_in_each_exp 的行为需要模拟，确保每个任务的 y_train/y_test 是从0开始的。
            # load_ucr_dataset 中的 LabelEncoder 已经是针对每个数据集独立编码的，所以 y_train/y_test 已经是0-indexed
            
            train_task_dataset = AvalancheDataset(
                X_train_tensor, y_train_tensor, task_labels=torch.full((len(y_train_tensor),), i, dtype=torch.long)
            )
            test_task_dataset = AvalancheDataset(
                X_test_tensor, y_test_tensor, task_labels=torch.full((len(y_test_tensor),), i, dtype=torch.long)
            )
            
            train_datasets.append(train_task_dataset)
            test_datasets.append(test_task_dataset)
            task_labels_list.append(i) # 任务标签与索引 i 对应

        if not train_datasets:
            raise ValueError("未能加载任何UCR数据集，无法创建基准。")

        # 使用 create_generic_benchmark_from_list_of_datasets 创建基准
        # 这个函数期望一个 train_datasets 列表和 test_datasets 列表
        # 它会自动处理 task_labels，如果 AvalancheTensorDataset 中已提供
        # 或者，我们可以使用更底层的 GenericCLScenario
        benchmark = benchmark_from_datasets(
            train_datasets=train_datasets,
            test_datasets=test_datasets,
            task_labels=task_labels_list, # 提供每个数据集/经验的任务标签列表
            complete_test_set_only=False # 每个经验后在对应的测试集上评估
        )
        
        print(f"UCR基准创建完成。Input channels: {input_channels}, Sequence length: {sequence_length}, Initial classes: {n_initial_classes}")
        return benchmark, input_channels, sequence_length, n_initial_classes
    
    else:
        raise ValueError(f"未知的基准名称: {benchmark_name}")

def run_experiment(strategy_name, benchmark, model, optimizer, criterion, device, args):
    """使用指定策略运行 CL 实验"""
    loggers = [InteractiveLogger()]
    if args.log_text:
        loggers.append(TextLogger(open(f'{strategy_name}_log.txt', 'a', encoding='utf-8')))
    if args.log_tb:
        loggers.append(TensorboardLogger(tb_log_dir=f'tb_logs/{strategy_name}'))

    eval_plugin = EvaluationPlugin(
        accuracy_metrics(minibatch=False, epoch=True, experience=True, stream=True),
        loss_metrics(minibatch=False, epoch=True, experience=True, stream=True),
        forgetting_metrics(experience=True, stream=True),
        cpu_usage_metrics(experience=True),
        timing_metrics(epoch=True, experience=True),
        ram_usage_metrics(experience=True),
        loggers=loggers
    )

    plugins = []
    cl_strategy = None

    if strategy_name == 'Naive':
        cl_strategy = Naive(
            model=model,
            optimizer=optimizer,
            criterion=criterion,
            train_mb_size=args.batch_size,
            train_epochs=args.epochs,
            eval_mb_size=args.batch_size,
            device=device,
            evaluator=eval_plugin,
            plugins=plugins
        )
    elif strategy_name == 'EWC':
        plugins.append(EWCPlugin(ewc_lambda=args.ewc_lambda))
        cl_strategy = Naive(
            model=model,
            optimizer=optimizer,
            criterion=criterion,
            train_mb_size=args.batch_size,
            train_epochs=args.epochs,
            eval_mb_size=args.batch_size,
            device=device,
            evaluator=eval_plugin,
            plugins=plugins
        )
    elif strategy_name == 'Replay':
        storage_policy = ExperienceBalancedBuffer(max_size=args.memory_size)
        plugins.append(ReplayPlugin(mem_size=args.memory_size, storage_policy=storage_policy))
        cl_strategy = Naive(
            model=model,
            optimizer=optimizer,
            criterion=criterion,
            train_mb_size=args.batch_size,
            train_epochs=args.epochs,
            eval_mb_size=args.batch_size,
            device=device,
            evaluator=eval_plugin,
            plugins=plugins
        )
    elif strategy_name == 'LwF': # 新增 LwF 策略
        cl_strategy = LwF(
            model=model,
            optimizer=optimizer,
            criterion=criterion, # LwF 内部会处理组合损失
            alpha=args.lwf_alpha, 
            temperature=args.lwf_temperature,
            train_mb_size=args.batch_size,
            train_epochs=args.epochs,
            eval_mb_size=args.batch_size,
            device=device,
            evaluator=eval_plugin,
            plugins=plugins # 通常为空，除非有其他与LwF兼容的插件
        )
    else:
        raise ValueError(f"未知策略: {strategy_name}")

    print(f"\n--- 开始训练: {strategy_name} ---")
    results = []

    for experience in benchmark.train_stream:
        print(f">>> 经验开始: {experience.current_experience} <<<")
        print(f"当前经验中的类: {experience.classes_in_this_experience}")
        task_label = experience.task_label
        print(f"任务标签: {task_label}")

        # 动态添加分类器头
        if task_label > 0 and task_label >= len(model.task_classifiers):
            num_classes_in_task = len(experience.classes_in_this_experience)
            if task_label == len(model.task_classifiers):
                model.add_task_classifier(num_classes_in_task, device)
                print("为新头重新创建优化器...")
                optimizer = optim.Adam(model.parameters(), lr=args.lr)
                cl_strategy.optimizer = optimizer

        cl_strategy.train(experience)
        print(f"<<< 经验结束: {experience.current_experience} >>>")

        print("--- 开始在测试流上评估 ---")
        res = cl_strategy.eval(benchmark.test_stream)
        results.append(res)

    print(f"--- 训练完成: {strategy_name} ---")
    
    # --- 新增：打印最终指标摘要 ---
    if results:
        print(f"\n--- Final Summary for Strategy: {strategy_name} ---")
        final_metrics = results[-1] # 获取最后一次评估的指标

        # 1. 准确性和遗忘度
        print("\n  Performance Metrics:") # 分点标题前加换行
        final_avg_acc_metric_key = 'Top1_Acc_Stream/eval_phase/test_stream/'
        if final_avg_acc_metric_key in final_metrics:
            print(f"  Final Average Accuracy (all tasks): {final_metrics[final_avg_acc_metric_key]:.4f}")
        else:
            print(f"  Final Average Accuracy (all tasks): Metric not found ({final_avg_acc_metric_key})")

        # 平均遗忘度 (BWT)
        avg_forgetting_metric_key = 'StreamForgetting/eval_phase/test_stream'
        if avg_forgetting_metric_key in final_metrics:
            print(f"  Average Forgetting (BWT): {final_metrics[avg_forgetting_metric_key]:.4f}")
        else:
            compat_forgetting_key = 'Forgetting_Stream/eval_phase/test_stream/'
            if compat_forgetting_key in final_metrics:
                 print(f"  Average Forgetting (BWT): {final_metrics[compat_forgetting_key]:.4f}")
            else:
                print(f"  Average Forgetting (BWT): Metric not found ({avg_forgetting_metric_key} or {compat_forgetting_key})")

        print("  Final Per-Task Accuracies (after all experiences):")
        num_experiences = benchmark.n_experiences
        for task_id in range(num_experiences):
            metric_name = f'Acc_Exp/eval_phase/test_stream/Task{task_id:03d}/Exp{num_experiences-1:03d}'
            if metric_name in final_metrics:
                print(f"    Task {task_id} Accuracy: {final_metrics[metric_name]:.4f}")
            else:
                print(f"    Task {task_id} Accuracy: Metric not found ({metric_name})")
        
        # 2. 计算效率指标
        print("\n  Efficiency Metrics:")
        num_experiences = benchmark.n_experiences # 确保 num_experiences 已定义

        # CPU 使用率
        # Avalanche v0.5+ 通常使用 'CPUUsage_Experience/eval_phase/test_stream' 
        # 当 EvaluationPlugin 中的 metric 设置为 experience=True (stream=True 也是常见组合)
        cpu_usage_key = 'CPUUsage_Experience/eval_phase/test_stream' 
        if cpu_usage_key in final_metrics:
            print(f"  CPU Usage (at final evaluation): {final_metrics[cpu_usage_key]}%")
        else:
            # 备用键，以防metric名称略有不同或来自旧版
            alt_cpu_key = f'CPUUsage_Exp/eval_phase/test_stream/Exp{num_experiences-1:03d}'
            if alt_cpu_key in final_metrics:
                print(f"  CPU Usage (at final evaluation): {final_metrics[alt_cpu_key]}%")
            else:
                print(f"  CPU Usage (at final evaluation): Metric not found (e.g., {cpu_usage_key} or {alt_cpu_key})")

        # RAM 使用率
        ram_usage_key = 'RAMUsage_Experience/eval_phase/test_stream'
        if ram_usage_key in final_metrics:
            print(f"  RAM Usage (at final evaluation): {final_metrics[ram_usage_key]} MB")
        else:
            alt_ram_key = f'RAMUsage_Exp/eval_phase/test_stream/Exp{num_experiences-1:03d}'
            if alt_ram_key in final_metrics:
                 print(f"  RAM Usage (at final evaluation): {final_metrics[alt_ram_key]} MB")
            else:
                print(f"  RAM Usage (at final evaluation): Metric not found (e.g., {ram_usage_key} or {alt_ram_key})")
        
        print("  (Detailed timing, CPU, and RAM usage metrics over all experiences are available in the log files and TensorBoard.)")
        print("--- End of Summary ---\n")
    # --- 摘要结束 ---
    
    return results

def main(args):
    # 设置种子
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(args.seed)

    # 设置设备
    device = torch.device(f"cuda:{args.cuda}" if torch.cuda.is_available() and args.cuda >= 0 else "cpu")
    print(f"使用设备: {device}")

    # 创建基准
    # 修改这里以允许选择基准并在创建时获取维度
    print(f"准备 {args.benchmark_name} 基准...")
    benchmark, input_channels, sequence_length, n_initial_classes = create_benchmark(
        benchmark_name=args.benchmark_name, 
        n_experiences_mnist=args.mnist_experiences, # 需要添加这个argparse参数
        seed=args.seed,
        data_dir=args.data_dir # 需要添加这个argparse参数
    )
    print("基准准备完毕。")
    
    # n_initial_classes 已经从 create_benchmark 返回
    print(f"从基准获取的初始类别数: {n_initial_classes}")
    print(f"从基准获取的Input channels: {input_channels}")
    print(f"从基准获取的Sequence length: {sequence_length}")


    # 创建模型
    print("初始化 CNN_BiGRU_Attention 模型...")
    # 使用从基准获取的维度，并加入新的可配置模型参数
    print(f"模型参数: input_channels={input_channels}, sequence_length={sequence_length}, n_initial_classes={n_initial_classes}, "
          f"num_multiscale_paths={args.num_multiscale_paths}, final_dropout_rate={args.final_dropout_rate}, "
          f"gru_hidden_size={args.gru_hidden_size}, num_gru_layers={args.num_gru_layers}, adaptive_pool_output_size={args.adaptive_pool_output_size}")
    
    model = CNN_BiGRU_Attention(input_channels=input_channels, 
                              sequence_length=sequence_length, 
                              num_classes_initial=n_initial_classes,
                              num_multiscale_paths=args.num_multiscale_paths, # 新增
                              final_dropout_rate=args.final_dropout_rate,   # 新增
                              gru_hidden_size=args.gru_hidden_size,           # 新增
                              num_gru_layers=args.num_gru_layers,             # 新增
                              adaptive_pool_output_size=args.adaptive_pool_output_size # 新增
                              ).to(device)
    print(f"使用了 CNN_BiGRU_Attention 模型。")

    # 创建优化器和损失函数
    optimizer = optim.Adam(model.parameters(), lr=args.lr)
    criterion = nn.CrossEntropyLoss()

    # 运行实验
    all_results = {}
    for strategy_name in args.strategies:
        print(f"\n重置模型和优化器以运行策略: {strategy_name}")
        # 每次策略运行时，都重新初始化模型，以确保状态纯净
        current_model = CNN_BiGRU_Attention(input_channels=input_channels, 
                                          sequence_length=sequence_length, 
                                          num_classes_initial=n_initial_classes,
                                          num_multiscale_paths=args.num_multiscale_paths, # 新增
                                          final_dropout_rate=args.final_dropout_rate,   # 新增
                                          gru_hidden_size=args.gru_hidden_size,           # 新增
                                          num_gru_layers=args.num_gru_layers,             # 新增
                                          adaptive_pool_output_size=args.adaptive_pool_output_size # 新增
                                          ).to(device)
        current_optimizer = optim.Adam(current_model.parameters(), lr=args.lr)

        results = run_experiment(strategy_name, benchmark, current_model, current_optimizer, criterion, device, args)
        all_results[strategy_name] = results

    print("\n--- 所有实验完成 ---")

def train_model(model, X_train, y_train, X_val, y_val, batch_size=32, num_epochs=100, learning_rate=0.001):
    """训练模型并返回训练历史"""
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)
    
    # 转换数据为PyTorch张量
    X_train = torch.FloatTensor(X_train)
    y_train = torch.LongTensor(y_train)
    X_val = torch.FloatTensor(X_val)
    y_val = torch.LongTensor(y_val)
    
    # 创建数据加载器
    train_dataset = torch.utils.data.TensorDataset(X_train, y_train)
    val_dataset = torch.utils.data.TensorDataset(X_val, y_val)
    train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=batch_size)
    
    # 定义优化器和损失函数
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    criterion = torch.nn.CrossEntropyLoss()
    
    # 初始化训练历史
    history = {
        'train_loss': [],
        'train_acc': [],
        'val_loss': [],
        'val_acc': []
    }
    
    # 训练循环
    for epoch in range(num_epochs):
        model.train()
        train_loss = 0
        train_correct = 0
        train_total = 0
        
        for batch_X, batch_y in train_loader:
            batch_X, batch_y = batch_X.to(device), batch_y.to(device)
            
            optimizer.zero_grad()
            outputs = model(batch_X)
            loss = criterion(outputs, batch_y)
            loss.backward()
            optimizer.step()
            
            train_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            train_total += batch_y.size(0)
            train_correct += (predicted == batch_y).sum().item()
        
        # 计算训练指标
        train_loss = train_loss / len(train_loader)
        train_acc = train_correct / train_total
        
        # 验证
        model.eval()
        val_loss = 0
        val_correct = 0
        val_total = 0
        
        with torch.no_grad():
            for batch_X, batch_y in val_loader:
                batch_X, batch_y = batch_X.to(device), batch_y.to(device)
                outputs = model(batch_X)
                loss = criterion(outputs, batch_y)
                
                val_loss += loss.item()
                _, predicted = torch.max(outputs.data, 1)
                val_total += batch_y.size(0)
                val_correct += (predicted == batch_y).sum().item()
        
        # 计算验证指标
        val_loss = val_loss / len(val_loader)
        val_acc = val_correct / val_total
        
        # 更新历史记录
        history['train_loss'].append(train_loss)
        history['train_acc'].append(train_acc)
        history['val_loss'].append(val_loss)
        history['val_acc'].append(val_acc)
        
        if (epoch + 1) % 10 == 0:
            print(f'Epoch [{epoch+1}/{num_epochs}], '
                  f'Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.4f}, '
                  f'Val Loss: {val_loss:.4f}, Val Acc: {val_acc:.4f}')
    
    return history

def evaluate_model(model, X_test, y_test, batch_size=32):
    """评估模型并返回测试损失、准确率和预测结果"""
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)
    model.eval()
    
    # 转换数据为PyTorch张量
    X_test = torch.FloatTensor(X_test)
    y_test = torch.LongTensor(y_test)
    
    # 创建数据加载器
    test_dataset = torch.utils.data.TensorDataset(X_test, y_test)
    test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=batch_size)
    
    # 定义损失函数
    criterion = torch.nn.CrossEntropyLoss()
    
    # 初始化评估指标
    test_loss = 0
    test_correct = 0
    test_total = 0
    all_predictions = []
    
    with torch.no_grad():
        for batch_X, batch_y in test_loader:
            batch_X, batch_y = batch_X.to(device), batch_y.to(device)
            outputs = model(batch_X)
            loss = criterion(outputs, batch_y)
            
            test_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            test_total += batch_y.size(0)
            test_correct += (predicted == batch_y).sum().item()
            all_predictions.extend(predicted.cpu().numpy())
    
    # 计算最终指标
    test_loss = test_loss / len(test_loader)
    test_acc = test_correct / test_total
    
    return test_loss, test_acc, all_predictions

if __name__ == "__main__":
    # --- 添加的第一个打印语句 ---
    print("--- Script execution started in __main__ block ---")

    parser = argparse.ArgumentParser(description='持续学习时间序列（或演示）实验')

    # 实验参数
    parser.add_argument('--benchmark_name', type=str, default='ucr_timeseries', 
                        choices=['ucr_timeseries', 'split_mnist'], help='要使用的基准名称')
    parser.add_argument('--data_dir', type=str, default='dataset', help='UCR数据集的根目录')
    parser.add_argument('--mnist_experiences', type=int, default=5, help='如果是SplitMNIST，则为经验数量')
    parser.add_argument('--strategies', nargs='+', type=str, default=['Naive', 'EWC', 'Replay', 'LwF'],  # 新增LwF到默认列表
                        choices=['Naive', 'EWC', 'Replay', 'LwF'], # 新增LwF到选项
                        help='要运行的持续学习策略列表')
    parser.add_argument('--log_text', action='store_true', help='将日志输出到文本文件')
    parser.add_argument('--log_tb', action='store_true', help='将日志输出到TensorBoard')

    # 模型和训练参数
    parser.add_argument('--lr', type=float, default=0.001, help='学习率')
    parser.add_argument('--epochs', type=int, default=10, help='每个经验的训练轮数') # 根据需要调整
    parser.add_argument('--batch_size', type=int, default=32, help='批量大小')
    
    # 模型特定架构参数 (新增)
    parser.add_argument('--num_multiscale_paths', type=int, default=4, 
                        help='MultiScaleFeatureExtraction中的并行卷积路径数')
    parser.add_argument('--final_dropout_rate', type=float, default=0.4, 
                        help='最终分类器前的Dropout率 (根据报告建议0.4)')
    parser.add_argument('--gru_hidden_size', type=int, default=128, help='GRU的隐藏层大小')
    parser.add_argument('--num_gru_layers', type=int, default=2, help='GRU的层数')
    parser.add_argument('--adaptive_pool_output_size', type=int, default=50, help='AdaptiveAvgPool1d的输出大小')

    # CL 策略特定参数
    parser.add_argument('--ewc_lambda', type=float, default=0.4, help='EWC的lambda惩罚系数')
    parser.add_argument('--memory_size', type=int, default=200, help='Replay策略的缓冲区大小')
    parser.add_argument('--lwf_alpha', type=float, default=1.0, help='LwF策略的alpha超参数 (平衡当前任务损失和蒸馏损失)') # 新增
    parser.add_argument('--lwf_temperature', type=float, default=2.0, help='LwF策略的蒸馏温度') # 新增

    # 其他
    parser.add_argument('--cuda', type=int, default=0, help='使用的CUDA设备ID (如果可用,否则使用CPU)')
    parser.add_argument('--seed', type=int, default=42, help='随机种子')

    args = parser.parse_args()

    # --- 添加的第二个打印语句，显示解析后的参数 ---
    print(f"--- Parsed arguments: {args} ---")

    # --- 调用主函数 ---
    # print("--- Calling main function ---") # 可以取消注释这行来进一步跟踪
    main(args)

    # --- 添加的最后一个打印语句 ---
    print("--- Script execution finished __main__ block ---")