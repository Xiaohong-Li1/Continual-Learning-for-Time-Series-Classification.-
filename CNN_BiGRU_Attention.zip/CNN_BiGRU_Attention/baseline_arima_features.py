# baseline_arima_features.py

import numpy as np
from sklearn.linear_model import LogisticRegression
# 或者，如果您想用随机森林分类ARIMA特征：
# from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tools.sm_exceptions import ConvergenceWarning, ValueWarning
import warnings
import traceback

# from load_timeseries_data import load_ucr_dataset # 不再由此文件直接加载，由调用方传入数据
# import os # 不再需要

# 抑制 ARIMA 拟合过程中的警告，以获得更清晰的批量处理输出
warnings.simplefilter('ignore', ConvergenceWarning)
warnings.simplefilter('ignore', ValueWarning)
warnings.simplefilter('ignore', UserWarning) # 通常来自 statsmodels 关于频率的警告
warnings.simplefilter('ignore', RuntimeWarning) # 例如，来自残差统计计算的警告

def extract_arima_residual_features(X, arima_order=(1,1,0)):
    """
    从一组时间序列的 ARIMA 模型残差中提取特征。
    对于每个时间序列，拟合一个 ARIMA 模型并计算残差的均值/标准差。
    假设 X 是一个 2D numpy 数组 (n_samples, sequence_length)。
    """
    n_samples = X.shape[0]
    arima_features = []
    min_len_for_arima = np.sum(arima_order) + 3 # ARIMA 拟合所需的最小长度（启发式）

    for i in range(n_samples):
        ts = X[i, :]
        ts_clean = ts[~np.isnan(ts)] # 移除 NaN

        if ts_clean.size < min_len_for_arima:
            # print(f"跳过序列 {i} 的 ARIMA，因为 NaN 或长度不足。")
            arima_features.append([0.0, 1.0]) # 默认特征 (例如，均值 0，标准差 1)
            continue

        try:
            # 强制使用简单阶数。为获得更好结果，需要 auto_arima 或阶数选择。
            model = ARIMA(ts_clean, order=arima_order, enforce_stationarity=False, enforce_invertibility=False)
            model_fit = model.fit()
            residuals = model_fit.resid

            if residuals.size == 0 or np.all(np.isnan(residuals)):
                res_mean = 0.0
                res_std = 1.0
            else:
                res_mean = np.mean(residuals[~np.isnan(residuals)])
                res_std = np.std(residuals[~np.isnan(residuals)])
                if np.isnan(res_std) or res_std == 0: # 如果标准差为 0 或 NaN (例如常数残差)
                    res_std = 1.0 # 避免除以零或无效标准差

            arima_features.append([res_mean, res_std])
        except Exception as e:
            # print(f"警告：序列 {i} 的 ARIMA 拟合失败。错误: {e}。使用默认特征。")
            arima_features.append([0.0, 1.0]) # 错误时的默认特征

    return np.array(arima_features)

def run_arima_baseline_for_dataset(X_train, y_train, X_test, y_test, dataset_name, class_names=None, arima_order=(1,1,0), random_state=42):
    """
    在 ARIMA 残差特征上训练和评估逻辑回归分类器。
    X_train, X_test: (n_samples, sequence_length) 或 (n_samples, 1, sequence_length)
    返回一个包含评估结果的字典。
    """
    print(f"运行 ARIMA 特征 + 分类器基线 for {dataset_name}...")

    if X_train.ndim == 3 and X_train.shape[1] == 1:
        X_train_2d = X_train.squeeze(axis=1)
    elif X_train.ndim == 2:
        X_train_2d = X_train
    else:
        raise ValueError(f"X_train 的维度不正确: {X_train.ndim}. 期望是 2 或 3 (单通道).")

    if X_test.ndim == 3 and X_test.shape[1] == 1:
        X_test_2d = X_test.squeeze(axis=1)
    elif X_test.ndim == 2:
        X_test_2d = X_test
    else:
        raise ValueError(f"X_test 的维度不正确: {X_test.ndim}. 期望是 2 或 3 (单通道).")

    # 检查序列长度
    min_len_for_arima_check = np.sum(arima_order) + 5
    if X_train_2d.shape[1] < min_len_for_arima_check:
        print(f"数据集 {dataset_name} 的序列长度 ({X_train_2d.shape[1]}) 对于 ARIMA 阶数 {arima_order} 可能太短。跳过 ARIMA 基线。")
        return {
            'Dataset': dataset_name,
            'Model': 'ARIMA',
            'Test Accuracy': np.nan, # 或者 0.0, 或 None
            'Test Loss': np.nan, # ARIMA 通常不直接优化损失函数
            'Classes': len(class_names) if class_names else len(np.unique(y_train)),
            'Training Samples': len(X_train),
            'Testing Samples': len(X_test),
            'Error': 'Sequence too short'
        }

    print(f"提取 ARIMA (阶数 {arima_order}) 残差特征 for {dataset_name}...")
    X_train_arima_features = extract_arima_residual_features(X_train_2d, arima_order=arima_order)
    X_test_arima_features = extract_arima_residual_features(X_test_2d, arima_order=arima_order)

    X_train_arima_features = np.nan_to_num(X_train_arima_features, nan=0.0, posinf=0.0, neginf=0.0)
    X_test_arima_features = np.nan_to_num(X_test_arima_features, nan=0.0, posinf=0.0, neginf=0.0)

    classifier = LogisticRegression(random_state=random_state, solver='liblinear', max_iter=200)

    print(f"在 ARIMA 特征上训练分类器 for {dataset_name}...")
    try:
        classifier.fit(X_train_arima_features, y_train)
        y_pred = classifier.predict(X_test_arima_features)
        accuracy = accuracy_score(y_test, y_pred)
        # report_str = classification_report(y_test, y_pred, target_names=class_names, zero_division=0) # 报告可以不在这里打印
        print(f"ARIMA 特征 + 分类器 ({dataset_name}) - 测试准确率: {accuracy:.4f}")
        
        # 修正 Classes 的计算逻辑
        num_classes = len(class_names) if class_names is not None and class_names.size > 0 else len(np.unique(y_train))

        return {
            'Dataset': dataset_name,
            'Model': 'ARIMA',
            'Test Accuracy': accuracy,
            'Test Loss': np.nan, 
            'Classes': num_classes, # 使用修正后的值
            'Training Samples': len(X_train),
            'Testing Samples': len(X_test)
        }
    except Exception as e:
        print(f"ARIMA 基线 for {dataset_name} 失败: {e}")
        traceback.print_exc()
        # 修正 Classes 的计算逻辑 (错误情况)
        num_classes_err = len(class_names) if class_names is not None and class_names.size > 0 else (len(np.unique(y_train)) if y_train is not None and y_train.size > 0 else np.nan)
        return {
            'Dataset': dataset_name,
            'Model': 'ARIMA',
            'Test Accuracy': np.nan,
            'Test Loss': np.nan,
            'Classes': num_classes_err, # 使用修正后的值
            'Training Samples': len(X_train) if X_train is not None else 0,
            'Testing Samples': len(X_test) if X_test is not None else 0,
            'Error': str(e)
        }