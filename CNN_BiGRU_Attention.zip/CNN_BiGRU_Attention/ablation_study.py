import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
import numpy as np
import os
import argparse
from tqdm import tqdm
import matplotlib.pyplot as plt
import csv

# Assuming model.py and load_timeseries_data.py are in the same directory or accessible
from model import CNN_BiGRU_Attention 
from load_timeseries_data import load_ucr_dataset
from sklearn.preprocessing import LabelEncoder

# --- Default Hyperparameters (can be overridden by argparse) ---
DEFAULT_LR = 0.001
DEFAULT_BATCH_SIZE = 16 # Default batch size (can be adjusted per dataset if needed)
DEFAULT_EPOCHS = 100    # Default epochs (can be adjusted per dataset if needed)
DEFAULT_DATA_DIR = 'dataset'
DEFAULT_RESULTS_DIR = 'ablation_results'
DEFAULT_DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# List of UCR datasets to run ablation on
UCR_DATASET_NAMES = [
    "ArrowHead", "AtrialFibrillation", "BasicMotions", "Beef", "BeetleFly",
    "BirdChicken", "BME", "Coffee", "DodgerLoopDay", "DodgerLoopGame"
]

# --- Model Training and Evaluation Functions (adapted from train.py) ---
def train_single_model(model, X_train, y_train, X_val, y_val, batch_size, num_epochs, learning_rate, device, silent=False):
    model = model.to(device)
    
    X_train_tensor = torch.FloatTensor(X_train)
    y_train_tensor = torch.LongTensor(y_train)
    
    train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    
    val_loader = None
    if X_val is not None and y_val is not None:
        X_val_tensor = torch.FloatTensor(X_val)
        y_val_tensor = torch.LongTensor(y_val)
        val_dataset = TensorDataset(X_val_tensor, y_val_tensor)
        val_loader = DataLoader(val_dataset, batch_size=batch_size)
        
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)
    criterion = nn.CrossEntropyLoss()
    
    best_val_acc = 0.0
    
    for epoch in range(num_epochs):
        model.train()
        running_loss = 0.0
        correct_predictions = 0
        total_samples = 0
        
        epoch_pbar = tqdm(train_loader, desc=f"Epoch {epoch+1}/{num_epochs} [Train]", leave=False, disable=silent)
        for batch_X, batch_y in epoch_pbar:
            batch_X, batch_y = batch_X.to(device), batch_y.to(device)
            optimizer.zero_grad()
            outputs = model(batch_X) # Assuming single head for ablation on one dataset
            loss = criterion(outputs, batch_y)
            loss.backward()
            optimizer.step()
            
            running_loss += loss.item() * batch_X.size(0)
            _, predicted = torch.max(outputs.data, 1)
            total_samples += batch_y.size(0)
            correct_predictions += (predicted == batch_y).sum().item()
            if not silent:
                epoch_pbar.set_postfix({'loss': f'{running_loss/total_samples:.4f}', 'acc': f'{correct_predictions/total_samples:.4f}'})
        
        epoch_train_acc = correct_predictions/total_samples
        
        if val_loader and not silent:
            model.eval()
            val_loss = 0.0
            val_correct = 0
            val_total = 0
            val_pbar = tqdm(val_loader, desc=f"Epoch {epoch+1}/{num_epochs} [Val]", leave=False, disable=silent)
            with torch.no_grad():
                for batch_X_val, batch_y_val in val_pbar:
                    batch_X_val, batch_y_val = batch_X_val.to(device), batch_y_val.to(device)
                    outputs_val = model(batch_X_val)
                    loss_val = criterion(outputs_val, batch_y_val)
                    val_loss += loss_val.item() * batch_X_val.size(0)
                    _, predicted_val = torch.max(outputs_val.data, 1)
                    val_total += batch_y_val.size(0)
                    val_correct += (predicted_val == batch_y_val).sum().item()
                    if not silent:
                         val_pbar.set_postfix({'val_loss': f'{val_loss/val_total:.4f}', 'val_acc': f'{val_correct/val_total:.4f}'})
            epoch_val_acc = val_correct/val_total
            if epoch_val_acc > best_val_acc:
                best_val_acc = epoch_val_acc
            if not silent:
                 tqdm.write(f"Epoch {epoch+1}: Train Acc: {epoch_train_acc:.4f}, Val Acc: {epoch_val_acc:.4f}")
        elif not silent:
             tqdm.write(f"Epoch {epoch+1}: Train Acc: {epoch_train_acc:.4f}")
    # For simplicity in ablation, we are not doing early stopping or model saving based on val_acc here.
    # The final model state after all epochs is used for evaluation.
    return model

def evaluate_single_model(model, X_test, y_test, batch_size, device, silent=False):
    model.eval()
    model = model.to(device)
    
    X_test_tensor = torch.FloatTensor(X_test)
    y_test_tensor = torch.LongTensor(y_test)
    
    test_dataset = TensorDataset(X_test_tensor, y_test_tensor)
    test_loader = DataLoader(test_dataset, batch_size=batch_size)
    
    criterion = nn.CrossEntropyLoss()
    test_loss = 0.0
    test_correct = 0
    test_total = 0
    
    eval_pbar = tqdm(test_loader, desc="Evaluating", leave=False, disable=silent)
    with torch.no_grad():
        for batch_X, batch_y in eval_pbar:
            batch_X, batch_y = batch_X.to(device), batch_y.to(device)
            outputs = model(batch_X) # Assuming single head
            loss = criterion(outputs, batch_y)
            test_loss += loss.item() * batch_X.size(0)
            _, predicted = torch.max(outputs.data, 1)
            test_total += batch_y.size(0)
            test_correct += (predicted == batch_y).sum().item()
            if not silent:
                eval_pbar.set_postfix({'loss': f'{test_loss/test_total:.4f}', 'acc': f'{test_correct/test_total:.4f}'})
                
    final_test_loss = test_loss / test_total
    final_test_acc = test_correct / test_total
    return final_test_loss, final_test_acc

def run_ablation_conv_blocks(args, dataset_names):
    print("\n--- Ablation Study: Number of Parallel Convolutional Blocks (Avg across datasets) ---")
    results = []
    conv_blocks_range = range(1, 7) # 1 to 6 blocks

    for num_blocks in conv_blocks_range:
        print(f"\n  Testing with {num_blocks} convolutional block(s) across {len(dataset_names)} datasets...")
        current_setting_accuracies = []
        
        for dataset_name in dataset_names:
            print(f"    Processing dataset: {dataset_name}...")
            try:
                # Load data for the current dataset
                X_train, y_train, X_test, y_test, _ = load_ucr_dataset(dataset_name, data_dir=args.data_dir)
                
                # Preprocess labels
                le = LabelEncoder()
                y_train = le.fit_transform(y_train)
                y_test = le.transform(y_test)
                num_classes = len(le.classes_)

                # Preprocess data dimensions
                if X_train.ndim == 2: X_train = np.expand_dims(X_train, axis=1)
                if X_test.ndim == 2: X_test = np.expand_dims(X_test, axis=1)
                input_channels = X_train.shape[1]
                sequence_length = X_train.shape[2]

                # Create model with current num_blocks and dataset specs
                model = CNN_BiGRU_Attention(
                    input_channels=input_channels,
                    sequence_length=sequence_length,
                    num_classes_initial=num_classes, 
                    num_multiscale_paths=num_blocks, # Ablation parameter
                    final_dropout_rate=args.final_dropout_rate_fixed, # Fixed parameter
                    gru_hidden_size=args.gru_hidden_size,
                    num_gru_layers=args.num_gru_layers,
                    adaptive_pool_output_size=args.adaptive_pool_output_size
                )
                
                # Train model
                model = train_single_model(model, X_train, y_train, None, None, 
                                           args.batch_size, args.epochs, args.lr, args.device, silent=args.silent)
                
                # Evaluate model
                _, test_acc = evaluate_single_model(model, X_test, y_test, args.batch_size, args.device, silent=args.silent)
                print(f"      {dataset_name} Test Accuracy: {test_acc:.4f}")
                current_setting_accuracies.append(test_acc)
            
            except Exception as e:
                print(f"      ERROR processing dataset {dataset_name}: {e}. Skipping this dataset for this setting.")

        # Calculate average accuracy for this setting
        if current_setting_accuracies:
            avg_acc = np.mean(current_setting_accuracies)
            print(f"  Average Test Accuracy with {num_blocks} block(s) across {len(current_setting_accuracies)} datasets: {avg_acc:.4f}")
            results.append({'num_conv_blocks': num_blocks, 'average_test_accuracy': avg_acc})
        else:
            print(f"  No successful runs for {num_blocks} block(s). Skipping.")

    # Save results to CSV
    csv_path = os.path.join(args.results_dir, 'ablation_results_conv_blocks_avg.csv')
    os.makedirs(args.results_dir, exist_ok=True)
    if results:
        with open(csv_path, 'w', newline='') as csvfile:
            fieldnames = ['num_conv_blocks', 'average_test_accuracy']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(results)
        print(f"Average results for convolutional blocks ablation saved to {csv_path}")

        # Plot results
        block_counts = [r['num_conv_blocks'] for r in results]
        avg_accuracies = [r['average_test_accuracy'] for r in results]
        plt.figure(figsize=(8, 5))
        plt.bar([str(bc) for bc in block_counts], avg_accuracies, color='skyblue')
        plt.xlabel("Number of Parallel Convolutional Blocks")
        plt.ylabel(f"Average Test Accuracy ({len(dataset_names)} UCR Datasets)")
        plt.title("Impact of Conv Blocks on Average Accuracy")
        plt.ylim(0, 1.05)
        for i, acc in enumerate(avg_accuracies):
            plt.text(i, acc + 0.01, f"{acc:.3f}", ha='center')
        plot_path = os.path.join(args.results_dir, 'ablation_plot_conv_blocks_avg.png')
        plt.savefig(plot_path)
        print(f"Plot for convolutional blocks ablation saved to {plot_path}")
        plt.close()
    else:
        print("No results generated for convolutional blocks ablation.")

def run_ablation_dropout_rate(args, dataset_names):
    print("\n--- Ablation Study: Final Dropout Rate (Avg across datasets) ---")
    results = []
    dropout_rates_range = [round(r * 0.1, 1) for r in range(1, 7)] # 0.1 to 0.6

    for rate in dropout_rates_range:
        print(f"\n  Testing with final dropout rate {rate:.1f} across {len(dataset_names)} datasets...")
        current_setting_accuracies = []
        
        for dataset_name in dataset_names:
            print(f"    Processing dataset: {dataset_name}...")
            try:
                # Load data
                X_train, y_train, X_test, y_test, _ = load_ucr_dataset(dataset_name, data_dir=args.data_dir)
                
                # Preprocess
                le = LabelEncoder()
                y_train = le.fit_transform(y_train)
                y_test = le.transform(y_test)
                num_classes = len(le.classes_)
                if X_train.ndim == 2: X_train = np.expand_dims(X_train, axis=1)
                if X_test.ndim == 2: X_test = np.expand_dims(X_test, axis=1)
                input_channels = X_train.shape[1]
                sequence_length = X_train.shape[2]

                # Create model
                model = CNN_BiGRU_Attention(
                    input_channels=input_channels,
                    sequence_length=sequence_length,
                    num_classes_initial=num_classes,
                    num_multiscale_paths=args.num_multiscale_paths_fixed, # Fixed parameter
                    final_dropout_rate=rate, # Ablation parameter
                    gru_hidden_size=args.gru_hidden_size,
                    num_gru_layers=args.num_gru_layers,
                    adaptive_pool_output_size=args.adaptive_pool_output_size
                )
                
                # Train
                model = train_single_model(model, X_train, y_train, None, None,
                                           args.batch_size, args.epochs, args.lr, args.device, silent=args.silent)
                
                # Evaluate
                _, test_acc = evaluate_single_model(model, X_test, y_test, args.batch_size, args.device, silent=args.silent)
                print(f"      {dataset_name} Test Accuracy: {test_acc:.4f}")
                current_setting_accuracies.append(test_acc)

            except Exception as e:
                print(f"      ERROR processing dataset {dataset_name}: {e}. Skipping this dataset for this setting.")

        # Calculate average accuracy
        if current_setting_accuracies:
            avg_acc = np.mean(current_setting_accuracies)
            print(f"  Average Test Accuracy with dropout {rate:.1f} across {len(current_setting_accuracies)} datasets: {avg_acc:.4f}")
            results.append({'dropout_rate': rate, 'average_test_accuracy': avg_acc})
        else:
            print(f"  No successful runs for dropout rate {rate:.1f}. Skipping.")

    # Save results to CSV
    csv_path = os.path.join(args.results_dir, 'ablation_results_dropout_avg.csv')
    os.makedirs(args.results_dir, exist_ok=True)
    if results:
        with open(csv_path, 'w', newline='') as csvfile:
            fieldnames = ['dropout_rate', 'average_test_accuracy']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(results)
        print(f"Average results for dropout rate ablation saved to {csv_path}")

        # Plot results
        rates = [r['dropout_rate'] for r in results]
        avg_accuracies = [r['average_test_accuracy'] for r in results]
        plt.figure(figsize=(8, 5))
        plt.bar([f"{r:.1f}" for r in rates], avg_accuracies, color='lightcoral')
        plt.xlabel("Final Dropout Rate")
        plt.ylabel(f"Average Test Accuracy ({len(dataset_names)} UCR Datasets)")
        plt.title("Impact of Final Dropout Rate on Average Accuracy")
        plt.ylim(0, 1.05)
        for i, acc in enumerate(avg_accuracies):
            plt.text(i, acc + 0.01, f"{acc:.3f}", ha='center')
        plot_path = os.path.join(args.results_dir, 'ablation_plot_dropout_avg.png')
        plt.savefig(plot_path)
        print(f"Plot for dropout rate ablation saved to {plot_path}")
        plt.close()
    else:
        print("No results generated for dropout rate ablation.")

def main():
    parser = argparse.ArgumentParser(description="Ablation Study for CNN-BiGRU-Attention across UCR Datasets")
    parser.add_argument('--data_dir', type=str, default=DEFAULT_DATA_DIR, help="Directory for UCR datasets")
    parser.add_argument('--results_dir', type=str, default=DEFAULT_RESULTS_DIR, help="Directory to save ablation results and plots")
    parser.add_argument('--lr', type=float, default=DEFAULT_LR, help="Learning rate")
    parser.add_argument('--batch_size', type=int, default=DEFAULT_BATCH_SIZE, help="Batch size")
    parser.add_argument('--epochs', type=int, default=DEFAULT_EPOCHS, help="Number of training epochs")
    parser.add_argument('--device', type=str, default=str(DEFAULT_DEVICE), choices=['cuda', 'cpu'], help="Device to use ('cuda' or 'cpu')")
    parser.add_argument('--seed', type=int, default=42, help="Random seed for reproducibility")
    parser.add_argument('--num_multiscale_paths_fixed', type=int, default=4, help="Fixed num_multiscale_paths for dropout ablation")
    parser.add_argument('--final_dropout_rate_fixed', type=float, default=0.4, help="Fixed final_dropout_rate for conv blocks ablation")
    parser.add_argument('--gru_hidden_size', type=int, default=128, help="GRU hidden size")
    parser.add_argument('--num_gru_layers', type=int, default=2, help="Number of GRU layers")
    parser.add_argument('--adaptive_pool_output_size', type=int, default=50, help="AdaptiveAvgPool1d output size")
    parser.add_argument('--silent', action='store_true', help="Run in silent mode (less tqdm output)")

    args = parser.parse_args()
    args.device = torch.device(args.device)

    # Set seed
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    if args.device.type == 'cuda':
        torch.cuda.manual_seed_all(args.seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        
    print(f"Starting Ablation Study on {len(UCR_DATASET_NAMES)} UCR datasets.")
    print(f"Using device: {args.device}")
    print(f"Results will be saved in: {args.results_dir}")

    # Run Ablation for Convolutional Blocks
    run_ablation_conv_blocks(args, UCR_DATASET_NAMES)

    # Run Ablation for Dropout Rate
    run_ablation_dropout_rate(args, UCR_DATASET_NAMES)

    print("\n--- Ablation Study Completed ---")

if __name__ == '__main__':
    main() 